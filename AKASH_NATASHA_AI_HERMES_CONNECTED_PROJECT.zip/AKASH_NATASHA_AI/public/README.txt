AKASH AI + NATASHA AI mobile assistant.
Build APK through GitHub Actions workflow: .github/workflows/build-apk.yml
Read README_HINDI.md for Hindi instructions and current feature limitations.
