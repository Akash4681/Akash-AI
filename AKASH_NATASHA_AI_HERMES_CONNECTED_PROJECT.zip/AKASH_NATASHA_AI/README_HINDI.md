# AKASH AI + NATASHA AI — Android starter project

यह GitHub Actions से Android APK बनाने के लिए React + Capacitor प्रोजेक्ट है। इसे Termux में चलाने की आवश्यकता नहीं है।

## APK कैसे बनाएँ (फोन से GitHub वेबसाइट पर)

1. GitHub पर नया repository बनाएँ, उदाहरण: `akash-natasha-ai`.
2. इस ZIP को extract करें और इसकी **अंदर की सभी फाइलें** repository में upload करें। `.github/workflows/build-apk.yml` भी ज़रूर शामिल हो।
3. Repository में **Actions** टैब खोलें। यदि workflow disabled हो तो enable करें।
4. `Build AKASH AI Android APK` चुनें और **Run workflow** दबाएँ। `main` branch चुनें।
5. Build पूरा होने पर उसी run के नीचे **Artifacts** में `AKASH-NATASHA-AI-debug-apk` डाउनलोड करें।
6. ZIP artifact को extract करके `app-debug.apk` इंस्टॉल करें। Android में ज़रूरत पड़ने पर “Install unknown apps” अनुमति दें।

## Claude API जोड़ना

ऐप के Settings में अपनी Claude API key और model भरें। उदाहरण model: `claude-3-5-haiku-latest` या अपने Anthropic Console में उपलब्ध current model ID. Model IDs बदल सकते हैं। API key को किसी public repository, screenshot या message में न डालें।

**सुरक्षा सीमा:** यह शुरुआती संस्करण key को इस डिवाइस के browser/app local storage में रखता है और फोन से API call करता है। यह production-grade secure vault या सुरक्षित backend का विकल्प नहीं है; ऐप की फ़ाइलों/डिवाइस तक पहुँच रखने वाला व्यक्ति key निकाल सकता है। निजी इस्तेमाल के लिए ही परीक्षण करें। सार्वजनिक वितरण से पहले server-side proxy, rate limits, authentication और encrypted native storage लगाएँ।

## अभी क्या काम करता है

- AKASH / NATASHA persona switch
- Claude Messages API chat (API key + model सेट करने पर)
- बातचीत का local history, notes, session search
- browser link खोलना, file picker, speech-to-text और text-to-speech (डिवाइस/ब्राउज़र समर्थन पर निर्भर)
- Agent panel में user-confirmed action queue, stop/terminate, awareness toggle
- मोबाइल नियंत्रण की सीमा और अनुमति-आधारित UI scaffold

## क्या अभी पूर्ण रूप से लागू नहीं है

यह Stonic AI का clone या audited full agent नहीं है। Android Accessibility service, background wake-word, Gemini Live realtime audio, camera gesture pipeline, autonomous browser control, Agent Town multiplayer simulation, scheduled jobs, external messaging gateway, automatic in-app updates और native approval/checkpoint runtime अभी implemented नहीं हैं। इन्हें एक single build में भरोसेमंद ढंग से लागू करने के लिए अलग native modules, API credentials और device testing चाहिए। इस प्रोजेक्ट में इनके लिए UI/scaffolding और आगे बढ़ाने योग्य structure है; इन्हें तैयार सुविधा समझकर न चलाएँ।

## GitHub सुरक्षा

- API key को GitHub repository में commit न करें।
- GitHub Actions workflow debug APK बनाता है, release-signed APK नहीं।
- पहले build में कोई error आए तो Actions run के logs से error message लेकर सुधारना होगा।


## Hermes Agent कनेक्शन (नया)

Settings → AI Engine → Hermes Agent backend चुनकर official Hermes API server से जुड़ सकते हैं। विवरण `docs/HERMES_AGENT_REAL_INTEGRATION_HINDI.md` में है। Hermes का पूरा Python runtime APK के अंदर नहीं है; backend अलग से install/configure करना होगा। फीचर-वार स्थिति `docs/FEATURE_PARITY_MASTER_HINDI.md` में रखी गई है।
