# इस ZIP में क्या है और क्या नहीं

इस ZIP में AKASH AI + NATASHA AI का mobile project, GitHub Actions APK build workflow, वर्तमान UI/बेसिक चैट/नोट्स/लोकल इतिहास, और Stonic AI के विश्लेषण से बने feature map तथा native Android integration specifications शामिल हैं। कोई फीचर चुपचाप सूची से हटाया नहीं गया है।

**ज़रूरी स्पष्टता:** Stonic AI का मूल source code, private backend, credentials और proprietary assets उपलब्ध नहीं हैं, इसलिए उन्हें सीधे transfer करने का दावा नहीं किया जा सकता। सभी feature names और implementation requirements सूचीबद्ध हैं; कई advanced features के लिए वास्तविक native Android modules, provider credentials और device testing अभी बाकी हैं। इस package को “सभी advanced features पहले से पूरी तरह operational हैं” न समझें।

फोन से build: ZIP extract करके सभी files GitHub repository root में upload करें; `.github/workflows/build-apk.yml` रखें; Actions → Build AKASH AI Android APK → Run workflow; सफल होने पर artifact `AKASH-NATASHA-AI-debug-apk` डाउनलोड करें।
