# Android Native Integration Scaffold (Hindi)

यह फ़ोल्डर उन सुविधाओं की native implementation checklist रखता है जिन्हें केवल React/वेब UI से पूरा नहीं किया जा सकता। इन सुविधाओं को active बताना गलत होगा जब तक Android Kotlin code, permissions और वास्तविक फोन पर परीक्षण न हो जाए।

## Accessibility / मोबाइल ऐप कंट्रोल
1. Capacitor Android project बनने के बाद Kotlin में `AccessibilityService` जोड़ें।
2. AndroidManifest में service declaration और `BIND_ACCESSIBILITY_SERVICE` permission जोड़ें।
3. ऐप में स्पष्ट स्क्रीन दें कि service क्या देख/कर सकती है; user को Android Settings में स्वयं enable करना होगा।
4. Allowlisted actions (जैसे tap/type/back) पर ही काम करें; payments, messages भेजना, deletion या login जैसे संवेदनशील काम से पहले हर बार confirmation लें।
5. Stop/Terminate को running task cancellation से जोड़ें। केवल UI button पर्याप्त नहीं है।

## Camera / Gesture
- CameraX foreground flow, visible camera indicator और permission prompt रखें।
- Gesture recognition on-device करें जहाँ संभव हो; बिना सहमति background recording न करें।

## Wake word / Realtime voice
- Microphone permission, foreground service notification और battery behavior आवश्यक हैं।
- Gemini Live/अन्य provider की API key को APK में hardcode न करें; secure backend या short-lived token flow उपयोग करें।

## Calling / Messaging
- पहले Android dialer/SMS composer intents जैसे user-confirmed flows अपनाएँ।
- Direct SMS/call permissions संवेदनशील हैं; Android/Google Play policy और user consent के अनुसार implement करें।

## Background jobs / notifications
- Scheduled tasks के लिए WorkManager; continuous mic/voice के लिए Android नियमों के अनुसार foreground service.
- Notification permission और per-task opt-in दें।

## Release checklist
- Physical Android device tests, permission denial paths, offline/error states, accessibility review, API-key security, signed release build, privacy policy.
