import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'ai.akash.natasha',
  appName: 'AKASH AI',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' },
  android: { allowMixedContent: false }
};
export default config;
