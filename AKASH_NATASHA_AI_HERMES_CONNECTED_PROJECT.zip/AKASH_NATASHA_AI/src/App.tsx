import { useEffect, useMemo, useRef, useState } from 'react';
import { Activity, AudioLines, Bot, Brain, Check, ChevronDown, CircleStop, Clock3, FileText, Globe, Headphones, KeyRound, Menu, MessageCircle, Mic, MicOff, MonitorSmartphone, Plus, Send, Settings, ShieldCheck, Sparkles, Volume2, VolumeX, X } from 'lucide-react';
import { Browser } from '@capacitor/browser';
import { Filesystem, Directory } from '@capacitor/filesystem';

type Msg = { role: 'user' | 'assistant'; content: string; time: number };
type Note = { id: number; title: string; body: string; time: number };
const DEFAULT_MODEL = 'claude-3-5-haiku-latest';
const starter: Msg[] = [{ role: 'assistant', content: 'नमस्ते! मैं AKASH हूँ। मैं तुम्हारी मदद के लिए तैयार हूँ। Settings में अपनी Claude API key डालकर AI बातचीत शुरू करो।', time: Date.now() }];

function read<T>(key: string, fallback: T): T {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) as T : fallback; } catch { return fallback; }
}
function App() {
  const [persona, setPersona] = useState<'AKASH'|'NATASHA'>(() => read('an-persona', 'AKASH'));
  const [tab, setTab] = useState('Voice');
  const [messages, setMessages] = useState<Msg[]>(() => read('an-messages', starter));
  const [input, setInput] = useState('');
  const [apiKey, setApiKey] = useState(() => read('an-key', ''));
  const [model, setModel] = useState(() => read('an-model', DEFAULT_MODEL));
  const [baseUrl, setBaseUrl] = useState('https://api.anthropic.com/v1/messages');
  // Hermes runs as a real backend service; the Android app is its mobile frontend.
  const [engineMode, setEngineMode] = useState<'anthropic'|'hermes'>(() => read('an-engine-mode', 'anthropic'));
  const [hermesBaseUrl, setHermesBaseUrl] = useState(() => read('an-hermes-url', ''));
  const [hermesApiKey, setHermesApiKey] = useState(() => read('an-hermes-key', ''));
  const [hermesModel, setHermesModel] = useState(() => read('an-hermes-model', 'hermes-agent'));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [awareness, setAwareness] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [listening, setListening] = useState(false);
  const [notes, setNotes] = useState<Note[]>(() => read('an-notes', []));
  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [query, setQuery] = useState('');
  const [agentLog, setAgentLog] = useState<string[]>(['Agent ready. Actions require your confirmation.']);
  const [confirmAction, setConfirmAction] = useState('');
  const [webUrl, setWebUrl] = useState('https://');
  const bottomRef = useRef<HTMLDivElement>(null);
  const personaName = persona === 'AKASH' ? 'AKASH' : 'NATASHA';
  const filteredMessages = useMemo(() => messages.filter(m => m.content.toLowerCase().includes(query.toLowerCase())), [messages, query]);

  useEffect(() => { localStorage.setItem('an-persona', JSON.stringify(persona)); }, [persona]);
  useEffect(() => { localStorage.setItem('an-messages', JSON.stringify(messages)); bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);
  useEffect(() => { localStorage.setItem('an-key', JSON.stringify(apiKey)); }, [apiKey]);
  useEffect(() => { localStorage.setItem('an-model', JSON.stringify(model)); }, [model]);
  useEffect(() => { localStorage.setItem('an-engine-mode', JSON.stringify(engineMode)); }, [engineMode]);
  useEffect(() => { localStorage.setItem('an-hermes-url', JSON.stringify(hermesBaseUrl)); }, [hermesBaseUrl]);
  useEffect(() => { localStorage.setItem('an-hermes-key', JSON.stringify(hermesApiKey)); }, [hermesApiKey]);
  useEffect(() => { localStorage.setItem('an-hermes-model', JSON.stringify(hermesModel)); }, [hermesModel]);
  useEffect(() => { localStorage.setItem('an-notes', JSON.stringify(notes)); }, [notes]);

  function speak(text: string) {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = /[\u0900-\u097F]/.test(text) ? 'hi-IN' : 'en-US';
    u.rate = 1; window.speechSynthesis.speak(u);
  }
  async function sendMessage() {
    const text = input.trim();
    if (!text || busy) return;
    setInput(''); setError('');
    const next: Msg[] = [...messages, { role: 'user', content: text, time: Date.now() }];
    setMessages(next); setBusy(true);
    if (engineMode === 'hermes' && (!hermesBaseUrl.trim() || !hermesApiKey.trim())) {
      setMessages([...next, { role: 'assistant', content: 'Hermes Agent चलाने के लिए Settings में HTTPS Hermes API Server URL और API Server Key भरो। मोबाइल ऐप अकेले Hermes runtime नहीं है; उसे असली Hermes backend से जुड़ना होगा।', time: Date.now() }]);
      setBusy(false); setShowSettings(true); return;
    }
    if (engineMode === 'anthropic' && !apiKey.trim()) {
      setMessages([...next, { role: 'assistant', content: 'पहले Settings में Claude API key डालो। या Hermes Agent mode चुनकर अपने Hermes server से जुड़ो।', time: Date.now() }]);
      setBusy(false); setShowSettings(true); return;
    }
    try {
      let answer = '';
      if (engineMode === 'hermes') {
        const endpoint = `${hermesBaseUrl.trim().replace(/\/+$/, '')}/chat/completions`;
        const response = await fetch(endpoint, {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'authorization': `Bearer ${hermesApiKey.trim()}`
          },
          body: JSON.stringify({
            model: hermesModel.trim() || 'hermes-agent',
            messages: [
              { role: 'system', content: `You are ${personaName}, the mobile persona inside AKASH AI + NATASHA AI. Use the configured Hermes Agent backend and its enabled tools. Never claim a phone action happened unless a connected Android tool confirms it. Ask for confirmation before destructive, external, or privacy-sensitive actions.` },
              ...next.filter(m => m.role === 'user' || m.role === 'assistant').slice(-20).map(m => ({ role: m.role, content: m.content }))
            ],
            stream: false
          })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data?.error?.message || data?.message || `Hermes API request failed (${response.status})`);
        answer = data?.choices?.[0]?.message?.content || data?.output_text || '';
      } else {
        const response = await fetch(baseUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': apiKey.trim(), 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
          body: JSON.stringify({
            model: model.trim() || DEFAULT_MODEL, max_tokens: 1200,
            system: `You are ${personaName}, a helpful mobile AI assistant. Reply naturally in the language the user uses. You are running in an Android app. Never claim you performed phone actions unless the app actually did them. Ask for confirmation before external or destructive actions.`,
            messages: next.filter(m => m.role === 'user' || m.role === 'assistant').slice(-20).map(m => ({ role: m.role, content: m.content }))
          })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data?.error?.message || `API request failed (${response.status})`);
        answer = (data.content || []).filter((p: {type:string}) => p.type === 'text').map((p: {text:string}) => p.text).join('\n').trim();
      }
      answer = (answer || '').trim() || 'मुझे इस बार टेक्स्ट जवाब नहीं मिला।';
      setMessages([...next, { role: 'assistant', content: answer, time: Date.now() }]); speak(answer);
    } catch (e) {
      const message = e instanceof Error ? e.message : 'Unknown network error';
      setError(message);
      setMessages([...next, { role: 'assistant', content: `API से जवाब नहीं मिला: ${message}\nSettings में API key, model, इंटरनेट और API billing जाँचो।`, time: Date.now() }]);
    } finally { setBusy(false); }
  }
  function startListening() {
    const w = window as Window & { SpeechRecognition?: new () => any; webkitSpeechRecognition?: new () => any };
    const SR = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SR) { setError('इस डिवाइस/WebView में speech recognition उपलब्ध नहीं है। कीबोर्ड से लिखो या Google voice typing इस्तेमाल करो।'); return; }
    const rec = new SR(); rec.lang = 'hi-IN'; rec.interimResults = false; rec.maxAlternatives = 1;
    rec.onresult = (e: any) => { setInput((old) => `${old}${old ? ' ' : ''}${e.results[0][0].transcript}`); setListening(false); };
    rec.onerror = () => setListening(false); rec.onend = () => setListening(false);
    setListening(true); rec.start();
  }
  async function openWeb() {
    try {
      const u = new URL(webUrl.startsWith('http') ? webUrl : `https://${webUrl}`);
      if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only http/https links are allowed.');
      await Browser.open({ url: u.toString() });
    } catch { setError('वेबसाइट का सही URL डालो, जैसे https://example.com'); }
  }
  async function exportNotes() {
    const data = notes.map(n => `# ${n.title}\n${n.body}\n`).join('\n');
    try { await Filesystem.writeFile({ path: 'AKASH-NATASHA-notes.txt', data, directory: Directory.Documents, recursive: true }); setAgentLog(l => [...l, 'Notes exported to Documents (if permission/platform allows).']); }
    catch { const blob = new Blob([data], { type: 'text/plain' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'AKASH-NATASHA-notes.txt'; a.click(); URL.revokeObjectURL(a.href); }
  }
  function saveNote() {
    if (!noteTitle.trim() && !noteBody.trim()) return;
    setNotes([{ id: Date.now(), title: noteTitle.trim() || 'Untitled note', body: noteBody.trim(), time: Date.now() }, ...notes]);
    setNoteTitle(''); setNoteBody('');
  }
  function runConfirmedAction() {
    if (!confirmAction) return;
    setAgentLog(l => [...l, `Confirmed request: ${confirmAction}`, 'Safety note: this starter does not execute arbitrary Android control actions yet.']);
    setConfirmAction('');
  }
  const nav = [
    { name: 'Voice', icon: AudioLines }, { name: 'Agent', icon: Bot }, { name: 'Notes', icon: FileText },
    { name: 'Memory', icon: Brain }, { name: 'Skills', icon: Sparkles }, { name: 'Voices', icon: Headphones }
  ];
  return <div className="app-shell">
    <aside className={`sidebar ${showMenu ? 'open' : ''}`}>
      <div className="brand"><div className="brand-mark"><Sparkles size={21}/></div><div><b>AKASH <span>AI</span></b><small>MOBILE INTELLIGENCE</small></div><button className="icon-btn close-menu" onClick={() => setShowMenu(false)}><X/></button></div>
      <div className="persona-switch"><button className={persona === 'AKASH' ? 'active' : ''} onClick={() => setPersona('AKASH')}><span className="avatar male">A</span><span><b>AKASH</b><small>Core assistant</small></span><span className="radio">{persona === 'AKASH' ? '●' : '○'}</span></button><button className={persona === 'NATASHA' ? 'active' : ''} onClick={() => setPersona('NATASHA')}><span className="avatar female">N</span><span><b>NATASHA</b><small>Companion assistant</small></span><span className="radio">{persona === 'NATASHA' ? '●' : '○'}</span></button></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.map(({name, icon: Icon}) => <button key={name} className={`nav-item ${tab === name ? 'selected' : ''}`} onClick={() => { setTab(name); setShowMenu(false); }}><Icon size={18}/><span>{name}</span>{name === 'Memory' && <span className="nav-count">{messages.length}</span>}</button>)}</nav>
      <div className="nav-label">SYSTEM</div>
      <button className={`nav-item ${tab === 'Visual hub' ? 'selected' : ''}`} onClick={() => setTab('Visual hub')}><MonitorSmartphone size={18}/>Visual hub</button>
      <button className={`nav-item ${tab === 'Browser' ? 'selected' : ''}`} onClick={() => setTab('Browser')}><Globe size={18}/>Browser</button>
      <button className="nav-item" onClick={() => setShowSettings(true)}><Settings size={18}/>Settings <span className={`status-dot ${apiKey ? 'good' : ''}`}/></button>
      <div className="sidebar-bottom"><div className="connection"><span className={`pulse ${(engineMode === 'hermes' ? (hermesBaseUrl && hermesApiKey) : apiKey) ? 'green' : ''}`}/><span><b>{(engineMode === 'hermes' ? (hermesBaseUrl && hermesApiKey) : apiKey) ? (engineMode === 'hermes' ? 'Hermes connected config' : 'API configured') : 'Setup required'}</b><small>{engineMode === 'hermes' ? (hermesBaseUrl || 'Set Hermes server URL') : (apiKey ? model : 'Add Claude API key')}</small></span></div><div className="version">AKASH AI · MOBILE BUILD 1.0</div></div>
    </aside>
    {showMenu && <div className="scrim" onClick={() => setShowMenu(false)}/>}
    <main className="main">
      <header className="topbar"><div className="top-left"><button className="icon-btn mobile-menu" onClick={() => setShowMenu(true)}><Menu/></button><div className="crumb">Workspace <span>/</span> <b>{tab}</b></div></div><div className="top-actions"><div className="live-pill"><span className="pulse green"/> SYSTEM ONLINE</div><button className="icon-btn" title="Settings" onClick={() => setShowSettings(true)}><Settings size={19}/></button><div className={`top-avatar ${persona === 'AKASH' ? 'male' : 'female'}`}>{persona[0]}</div></div></header>
      <section className="content">
        {tab === 'Voice' && <><div className="welcome-row"><div><div className="eyebrow"><span/> PERSONAL AI COMPANION</div><h1>Good to see you<span className="accent">.</span></h1><p className="subhead">Your mobile intelligence is ready. What shall we work on?</p></div><div className="clock-chip"><Activity size={16}/> <span>LIVE SESSION</span></div></div>
          <div className="hero-card"><div className="hero-grid"/><div className="hero-copy"><div className="hero-status"><span className="pulse green"/> {personaName} IS LISTENING</div><h2>{persona === 'AKASH' ? 'Hello, I’m Akash.' : 'Hello, I’m Natasha.'}<br/><span>{persona === 'AKASH' ? 'How can I help you today?' : 'I’m here whenever you need me.'}</span></h2><p>Ask a question, share an idea, or tell me what you want to get done.</p><div className="hero-buttons"><button className="primary-btn" onClick={() => document.getElementById('chat-input')?.focus()}><MessageCircle size={17}/> Start a conversation</button><button className="ghost-btn" onClick={() => setShowSettings(true)}><KeyRound size={16}/> Configure AI</button></div></div><div className={`orb ${persona === 'NATASHA' ? 'orb-pink' : ''}`}><div className="orb-ring ring1"/><div className="orb-ring ring2"/><div className="orb-ring ring3"/><div className="orb-core"><Sparkles size={35}/></div><span className="orb-label">{personaName} CORE</span></div><div className="hero-foot"><span><ShieldCheck size={14}/> Permission-aware actions</span><span><Brain size={14}/> Local conversation history</span><span><Activity size={14}/> Claude API</span></div></div>
          <div className="section-heading"><div><h3>Conversation</h3><p>Your recent messages with {personaName}</p></div><button className="subtle-btn" onClick={() => setMessages(starter)}>New chat <Plus size={15}/></button></div>
          <div className="chat-card"><div className="chat-messages">{messages.slice(-12).map((m,i) => <div className={`message ${m.role}`} key={`${m.time}-${i}`}><div className={`message-avatar ${m.role === 'user' ? 'user-avatar' : persona === 'AKASH' ? 'male' : 'female'}`}>{m.role === 'user' ? 'Y' : persona[0]}</div><div className="message-body"><div className="message-meta"><b>{m.role === 'user' ? 'YOU' : personaName}</b><span>{new Date(m.time).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>{m.role === 'assistant' && <button className="tiny-icon" onClick={() => speak(m.content)} title="Read aloud"><Volume2 size={13}/></button>}</div><p>{m.content}</p></div></div>)}{busy && <div className="typing"><span/><span/><span/> {personaName} is thinking…</div>}<div ref={bottomRef}/></div>{error && <div className="inline-error">{error}<button onClick={() => setError('')}><X size={14}/></button></div>}<form className="chat-compose" onSubmit={e => {e.preventDefault(); void sendMessage();}}><button type="button" className={`compose-icon ${listening ? 'listening' : ''}`} title="Voice input" onClick={() => listening ? setListening(false) : startListening()}>{listening ? <MicOff size={19}/> : <Mic size={19}/>}</button><input id="chat-input" value={input} onChange={e => setInput(e.target.value)} placeholder={`Message ${personaName}…`} /><button type="button" className="compose-icon" title={voiceEnabled ? 'Mute voice responses' : 'Enable voice responses'} onClick={() => setVoiceEnabled(!voiceEnabled)}>{voiceEnabled ? <Volume2 size={18}/> : <VolumeX size={18}/>}</button><button className="send-btn" disabled={!input.trim() || busy}><Send size={17}/></button></form><div className="compose-hint">AI can make mistakes. Confirm important information and actions.</div></div>
          <div className="feature-grid"><Feature icon={<Brain/>} title="Persistent memory" desc="Conversation history stays on this device." onClick={() => setTab('Memory')}/><Feature icon={<Globe/>} title="Browser tools" desc="Open web links and research destinations." onClick={() => setTab('Browser')}/><Feature icon={<ShieldCheck/>} title="Safe actions" desc="Review requests before acting on your phone." onClick={() => setTab('Agent')}/></div>
        </>}
        {tab === 'Agent' && <><PageTitle eyebrow="MOBILE AUTOMATION" title="Agent control" sub="Review proposed actions before continuing."/><div className="agent-banner"><div className="agent-icon"><Bot size={28}/></div><div><b>Mobile Agent Runtime</b><p>Action proposals are logged. This starter does not yet control other apps automatically.</p></div><button className="danger-btn" onClick={() => {setConfirmAction(''); setAgentLog(l => [...l, 'TERMINATED by user.']);}}> <CircleStop size={16}/> TERMINATE</button></div><div className="panel"><div className="panel-title"><h3><Activity size={17}/> Awareness</h3><span className={`toggle ${awareness ? 'on' : ''}`} onClick={() => setAwareness(!awareness)} role="switch" aria-checked={awareness}/></div><p className="muted">{awareness ? 'Awareness enabled in this interface. Camera/screen sensing is not active in this build.' : 'Off — no camera or screen monitoring is running.'}</p></div><div className="panel"><div className="panel-title"><h3>Propose a mobile action</h3><span className="tag">CONFIRM REQUIRED</span></div><textarea className="field textarea" placeholder="Describe what you want the agent to do on your phone…" value={confirmAction} onChange={e => setConfirmAction(e.target.value)}/><button className="primary-btn" disabled={!confirmAction.trim()} onClick={runConfirmedAction}><Check size={16}/> Confirm proposal</button></div><div className="panel"><div className="panel-title"><h3>Agent activity</h3><button className="subtle-btn" onClick={() => setAgentLog([])}>Clear log</button></div>{agentLog.map((line,i) => <div className="log-line" key={i}><span className="log-dot"/><span>{line}</span></div>)}</div></>}
        {tab === 'Notes' && <><PageTitle eyebrow="PERSONAL KNOWLEDGE" title="Notes" sub="Capture thoughts and keep them on this device."/><div className="panel note-editor"><input className="field" value={noteTitle} onChange={e => setNoteTitle(e.target.value)} placeholder="Note title"/><textarea className="field textarea" value={noteBody} onChange={e => setNoteBody(e.target.value)} placeholder="Write your note…"/><div className="row-end"><button className="ghost-btn" onClick={() => void exportNotes()}><FileText size={16}/> Export notes</button><button className="primary-btn" onClick={saveNote}><Plus size={16}/> Save note</button></div></div><div className="notes-grid">{notes.map(n => <article className="note-card" key={n.id}><div className="note-top"><FileText size={17}/><button className="tiny-icon" onClick={() => setNotes(notes.filter(x => x.id !== n.id))}><X size={15}/></button></div><h3>{n.title}</h3><p>{n.body}</p><small><Clock3 size={12}/> {new Date(n.time).toLocaleString()}</small></article>)}</div>{!notes.length && <Empty title="No notes yet" text="Your saved notes will appear here."/>}</>}
        {tab === 'Memory' && <><PageTitle eyebrow="LONG-TERM CONTEXT" title="Memory & history" sub="Search the conversation history stored locally on this device."/><div className="search-box"><Brain size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search messages…"/></div><div className="panel">{filteredMessages.map((m,i) => <div className="history-item" key={`${m.time}-${i}`}><div className={`mini-avatar ${m.role}`}>{m.role === 'user' ? 'Y' : persona[0]}</div><div><div className="history-meta"><b>{m.role === 'user' ? 'You' : personaName}</b><small>{new Date(m.time).toLocaleString()}</small></div><p>{m.content}</p></div></div>)}{!filteredMessages.length && <Empty title="No matches" text="Try a different search term."/>}<button className="danger-outline" onClick={() => {if(confirm('Delete all local conversation history?')) setMessages(starter);}}>Clear conversation history</button></div></>}
        {tab === 'Skills' && <><PageTitle eyebrow="CAPABILITY LIBRARY" title="Skills" sub="Available tools and planned mobile integrations."/><div className="skills-grid"><Skill icon={<MessageCircle/>} name="AI conversation" status="Ready with API key" text="Claude Messages API chat."/><Skill icon={<Volume2/>} name="Speech output" status="Device support" text="Uses the device's speech synthesis."/><Skill icon={<Mic/>} name="Speech input" status="Device support" text="Uses Web Speech when available; otherwise use keyboard voice typing."/><Skill icon={<Globe/>} name="Browser launcher" status="Available" text="Opens an HTTPS or HTTP destination in the system browser."/><Skill icon={<FileText/>} name="Notes & documents" status="Basic" text="Local notes and text export."/><Skill icon={<MonitorSmartphone/>} name="Android accessibility" status="Not implemented" text="Native accessibility service is required for app-to-app actions."/><Skill icon={<Headphones/>} name="Wake word / live audio" status="Not implemented" text="Porcupine and Gemini Live need native integration and credentials."/><Skill icon={<Activity/>} name="Camera / gesture awareness" status="Not implemented" text="No camera stream or gesture inference is active in this starter."/><Skill icon={<Clock3/>} name="Scheduled jobs" status="Planned" text="Background scheduling needs Android native work and permissions."/><Skill icon={<ShieldCheck/>} name="Approvals & stop" status="Basic" text="UI confirmation and a terminate log; not a native automation sandbox yet."/><Skill icon={<Brain/>} name="Session search" status="Basic" text="Searches locally stored messages."/><Skill icon={<Sparkles/>} name="Agent Town / 3D HUD" status="Visual scaffold" text="This build uses a responsive sci-fi dashboard, not the original 3D office." /></div></>}
        {tab === 'Voices' && <><PageTitle eyebrow="VOICE STUDIO" title="Voices" sub="Choose the persona and test your device voice."/><div className="voice-cards"><div className={`voice-card ${persona==='AKASH'?'chosen':''}`}><div className="voice-avatar male">A</div><div><h3>AKASH</h3><p>Calm, helpful assistant persona</p><span className="tag">MALE PERSONA</span></div><button className="primary-btn" onClick={() => {setPersona('AKASH'); speak('नमस्ते, मैं आकाश हूँ।');}}>Select & test</button></div><div className={`voice-card ${persona==='NATASHA'?'chosen':''}`}><div className="voice-avatar female">N</div><div><h3>NATASHA</h3><p>Warm, friendly companion persona</p><span className="tag pink">FEMALE PERSONA</span></div><button className="primary-btn" onClick={() => {setPersona('NATASHA'); speak('नमस्ते, मैं नताशा हूँ।');}}>Select & test</button></div></div><div className="panel"><div className="panel-title"><h3>Speech output</h3><button className={`toggle ${voiceEnabled ? 'on' : ''}`} onClick={() => setVoiceEnabled(!voiceEnabled)}/></div><p className="muted">The actual voice depends on the voices installed on your Android device. A distinct voice per persona is not guaranteed in this starter.</p></div></>}
        {tab === 'Visual hub' && <><PageTitle eyebrow="VISUAL INTERFACE" title="Visual hub" sub="Mobile-first command center for your AI personas."/><div className="visual-card"><div className={`big-orb ${persona==='NATASHA'?'orb-pink':''}`}><Sparkles size={50}/></div><h2>{personaName} CORE</h2><p>PERSONA ACTIVE · MOBILE MODE</p><div className="visual-actions"><button className="primary-btn" onClick={() => setTab('Voice')}>Open voice console</button><button className="ghost-btn" onClick={() => setTab('Agent')}>Agent controls</button></div></div><div className="skills-grid"><Skill icon={<Activity/>} name="Awareness" status={awareness?'Enabled':'Disabled'} text="Interface switch only; sensing is not active."/><Skill icon={<ShieldCheck/>} name="Safety layer" status="Enabled" text="Confirmations are shown for proposed actions."/><Skill icon={<Brain/>} name="Memory" status={`${messages.length} messages`} text="Conversation history stored locally."/><Skill icon={<Globe/>} name="Media link" status="Manual URL" text="Open a web destination from Browser tab."/></div></>}
        {tab === 'Browser' && <><PageTitle eyebrow="WEB TOOLS" title="Browser" sub="Open a website in your Android system browser."/><div className="panel browser-panel"><div className="browser-illustration"><Globe size={35}/></div><label>Website URL</label><div className="browser-input"><Globe size={18}/><input value={webUrl} onChange={e => setWebUrl(e.target.value)} onKeyDown={e => {if(e.key==='Enter') void openWeb();}} placeholder="https://example.com"/></div><button className="primary-btn" onClick={() => void openWeb()}>Open website <ChevronDown size={16}/></button><p className="muted">This launches the system browser. Automatic browsing, clicking and reading pages are not implemented in this starter.</p></div></>}
      </section>
      <footer className="footer"><span>AKASH AI <b>×</b> NATASHA AI</span><span>MADE FOR MOBILE <span className="footer-dot"/> {engineMode === 'hermes' ? 'HERMES MODE' : `API ${apiKey ? 'CONNECTED' : 'NOT CONFIGURED'}`}</span></footer>
    </main>
    {showSettings && <div className="modal-backdrop" onClick={() => setShowSettings(false)}><section className="settings-modal" onClick={e => e.stopPropagation()}><div className="modal-header"><div><div className="eyebrow"><span/> CONFIGURATION</div><h2>Settings</h2><p>Connect the AI engine and configure this device.</p></div><button className="icon-btn" onClick={() => setShowSettings(false)}><X/></button></div><label className="form-label">AI Engine</label><select className="field" value={engineMode} onChange={e => setEngineMode(e.target.value as 'anthropic'|'hermes')}><option value="anthropic">Anthropic Claude API (direct chat)</option><option value="hermes">Hermes Agent backend (tools + agent loop)</option></select>
{engineMode === 'hermes' && <><label className="form-label">Hermes API server URL</label><input className="field" value={hermesBaseUrl} onChange={e => setHermesBaseUrl(e.target.value)} placeholder="https://your-secure-hermes-server:8642/v1"/><label className="form-label">Hermes API Server Key</label><input className="field" type="password" autoComplete="off" value={hermesApiKey} onChange={e => setHermesApiKey(e.target.value)} placeholder="API_SERVER_KEY"/><label className="form-label">Hermes model alias</label><input className="field" value={hermesModel} onChange={e => setHermesModel(e.target.value)} placeholder="hermes-agent"/><p className="field-help">This connects to the official Hermes Agent API server. The server must be installed, configured and reachable over HTTPS. Do not expose an unauthenticated agent server to the internet.</p></>}
<label className="form-label">Claude API key</label><input className="field" type="password" autoComplete="off" value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="sk-ant-…"/><p className="field-help">Never upload this key to GitHub. This starter stores it in local app storage, which is not a secure vault.</p><label className="form-label">Model ID</label><input className="field" value={model} onChange={e => setModel(e.target.value)} placeholder={DEFAULT_MODEL}/><p className="field-help">Use a model ID available to your Anthropic account. The default may need updating.</p><label className="form-label">Anthropic API endpoint</label><input className="field" value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="https://api.anthropic.com/v1/messages"/><div className="settings-warning"><ShieldCheck size={17}/><p><b>Privacy & security</b><br/>For production, route API calls through a secure backend and use native encrypted storage. Do not share this APK with your API key inside it.</p></div><div className="modal-actions"><button className="ghost-btn" onClick={() => {setApiKey(''); localStorage.removeItem('an-key');}}>Clear key</button><button className="primary-btn" onClick={() => {localStorage.setItem('an-key', JSON.stringify(apiKey)); localStorage.setItem('an-model', JSON.stringify(model)); localStorage.setItem('an-engine-mode', JSON.stringify(engineMode)); localStorage.setItem('an-hermes-url', JSON.stringify(hermesBaseUrl)); localStorage.setItem('an-hermes-key', JSON.stringify(hermesApiKey)); localStorage.setItem('an-hermes-model', JSON.stringify(hermesModel)); setShowSettings(false);}}>Save settings <Check size={16}/></button></div></section></div>}
  </div>;
}
function Feature({icon,title,desc,onClick}:{icon:React.ReactNode,title:string,desc:string,onClick:()=>void}) { return <button className="feature-card" onClick={onClick}><div className="feature-icon">{icon}</div><div><b>{title}</b><p>{desc}</p></div><span className="feature-arrow">↗</span></button>; }
function PageTitle({eyebrow,title,sub}:{eyebrow:string,title:string,sub:string}) { return <div className="page-title"><div className="eyebrow"><span/>{eyebrow}</div><h1>{title}<span className="accent">.</span></h1><p>{sub}</p></div>; }
function Skill({icon,name,status,text}:{icon:React.ReactNode,name:string,status:string,text:string}) { return <div className="skill-card"><div className="skill-top"><div className="feature-icon">{icon}</div><span className="tag">{status}</span></div><h3>{name}</h3><p>{text}</p></div>; }
function Empty({title,text}:{title:string,text:string}) { return <div className="empty-state"><Brain size={25}/><b>{title}</b><p>{text}</p></div>; }
export default App;
