# AKASH AI + NATASHA AI — वास्तविक Hermes Agent कनेक्शन

## साफ़ स्थिति
इस प्रोजेक्ट में मोबाइल UI से **Hermes Agent के आधिकारिक OpenAI-compatible API server** को कॉल करने वाला कनेक्टर जोड़ा गया है। यह Hermes Agent का Python runtime APK के अंदर पैक नहीं करता। वास्तविक agent engine अलग Hermes backend पर चलता है; Android ऐप उसका मोबाइल frontend है। यह Hermes के tool loop, configured tools, memory और skills को backend पर इस्तेमाल करने देता है, बशर्ते backend में वे configured और enabled हों।

आधिकारिक स्रोत:
- Source: https://github.com/NousResearch/hermes-agent
- API Server docs: https://hermes-agent.nousresearch.com/docs/user-guide/features/api-server
- Android/Termux installation notes: https://hermes-agent.nousresearch.com/docs/getting-started/installation

## मोबाइल ऐप में सेटअप
1. GitHub Actions से APK build करके फोन में इंस्टॉल करें।
2. Settings खोलें।
3. AI Engine में `Hermes Agent backend` चुनें।
4. Hermes API server URL में secure server का base URL डालें, उदाहरण `https://your-domain.example/v1` (अंत में `/v1` रखें)।
5. API Server Key भरें। Model alias सामान्यतः `hermes-agent` होता है।
6. Save करके एक साधारण सवाल भेजें।

ऐप `/v1/chat/completions` पर OpenAI-compatible request भेजता है और `choices[0].message.content` पढ़ता है।

## Backend कैसे तैयार होता है
Hermes Agent को उस मशीन/क्लाउड पर इंस्टॉल और configure करना होगा जो Hermes की supported environment में चले। Official docs के अनुसार API server को `~/.hermes/.env` में सक्षम किया जाता है:

```env
API_SERVER_ENABLED=true
API_SERVER_HOST=0.0.0.0
API_SERVER_PORT=8642
API_SERVER_KEY=REPLACE_WITH_A_LONG_RANDOM_SECRET
```

इसके बाद आधिकारिक दस्तावेज़ के अनुसार Hermes gateway शुरू करें। API server को इंटरनेट पर बिना authentication के कभी न खोलें। HTTPS reverse proxy/firewall लगाएँ और `API_SERVER_CORS_ORIGINS` को केवल वास्तविक app origins तक सीमित रखें। सार्वजनिक server पर strong unique key आवश्यक है। `API_SERVER_KEY` को GitHub repository में commit न करें।

## Android की वास्तविक सीमा
Hermes backend का `terminal` tool server-side मशीन पर काम कर सकता है; इससे अपने-आप फोन की दूसरी apps पर नियंत्रण नहीं मिलता। दूसरे Android apps नियंत्रित करने के लिए अलग Android `AccessibilityService`, उपयोगकर्ता द्वारा Settings में अनुमति, सुरक्षित action allowlist और native tool bridge चाहिए। Camera, wake word और Gemini Live के लिए भी native Android modules/permissions और अलग provider credentials चाहिए। UI में कोई बटन दिखना इस बात का प्रमाण नहीं कि वह native capability सक्रिय है।

## सुरक्षा
- API server की key APK में रखना एक जोखिम है; यदि APK साझा होगा तो key निकाली जा सकती है। निजी, भरोसेमंद backend/proxy बेहतर है।
- HTTPS का उपयोग करें; सार्वजनिक plain HTTP न रखें।
- फोन पर चलने वाले destructive/external actions से पहले confirmation आवश्यक है।
- Hermes का toolset शक्तिशाली है; backend में अनावश्यक tools बंद रखें और अनुमतियों को सीमित रखें।
