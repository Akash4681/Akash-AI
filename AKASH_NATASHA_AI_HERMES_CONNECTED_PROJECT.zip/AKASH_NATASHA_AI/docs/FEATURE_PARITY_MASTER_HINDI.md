# Stonic AI → AKASH AI + NATASHA AI: मास्टर फीचर सूची

इस सूची में कोई फीचर चुपचाप हटाया नहीं गया है। Status का अर्थ: **Implemented** = इस कोड में कार्यरत; **Connected by backend** = Hermes backend में configure होने पर; **Native work required** = Android native implementation/permission और device test बाकी; **UI/spec only** = स्क्रीन/दस्तावेज़ मौजूद, runtime अभी नहीं।

| Stonic AI / user-provided analysis feature | Status in this project |
|---|---|
| Voice / Agent / Notes tabs | Implemented basic UI |
| AKASH / NATASHA persona | Implemented basic persona switch |
| AI chat | Anthropic direct or Hermes API server connector |
| Hermes Agent core + agent loop | Backend required; mobile app connects to official API server, does not bundle Python runtime |
| Hermes tool registry/toolsets | Backend configured toolsets; Skills/toolsets endpoint discovery still needs UI integration |
| Browser tools / CDP | Hermes backend tools if configured; phone browser auto-control is separate |
| File tools | Hermes backend tools if configured; Android phone storage requires native SAF bridge |
| Code execution / terminal | Backend tools if enabled; server-side, not Android phone shell |
| Delegate / subagents | Backend capability if enabled |
| Memory / session search | Local chat history basic; Hermes memory available via backend/session support |
| Skills / self-improvement | Hermes backend if enabled; local UI catalogue is not a skill executor |
| MCP tools | Hermes backend if configured |
| Cron jobs / scheduled automation | Hermes backend scheduler if configured; Android local schedules require WorkManager/native integration |
| Approval / checkpoints / interrupt / clarify | Basic UI proposal and stop log; full backend run approvals/cancel integration remains to wire |
| Gemini Live / Pipecat | Native/provider integration required |
| Porcupine wake word | Native microphone service + license/key + battery tests required |
| Camera / MediaPipe / face landmark / gestures | Android CameraX + vision model + permission/disclosure + tests required |
| Computer Use (Windows) | Replaced by Android mobile-use design; PC SendInput/UI Automation is not applicable on Android |
| Android Accessibility mobile control | Native AccessibilityService and explicit user enablement required; not active in this UI-only build |
| Agent Town (Alice/Bob/Carol/Dave) | Design requirement retained; full game/scene runtime still to implement |
| 3D globe / satellite stream / headlines | Visual requirements retained; live data requires data sources/provider |
| Awareness switch / terminate | UI surface present; native services/runtime cancellation still required |
| Calling / SMS / messaging gateways | Native intents / provider integrations and confirmation required |
| Supabase login/licensing | Not configured; credentials/backend required |
| Automatic updates | GitHub artifact build exists; secure signed release/update channel required |
| File reading: PDF/DOCX/XLSX | Native/document parser integration still required |
| Recharts/Mermaid/Markdown dashboard | UI/library integration work remains where absent |

## Important
The original Stonic AI private app code, backend and proprietary assets were not provided. The app is being recreated from the supplied analysis and visible behavior, not by copying Stonic's private code. This table is a feature-retention ledger, not a claim that every feature is already operational.
