# Stonic AI → AKASH AI + NATASHA AI: पूरा फीचर मैप

इस प्रोजेक्ट में किसी feature को चुपचाप हटाने के बजाय नीचे उसका status साफ़ रखा गया है। Stonic AI के proprietary source/backend के बिना उसका exact clone या उसका निजी code transfer नहीं किया जा सकता। यह feature map उपलब्ध screenshots और पहले किए गए analysis पर आधारित है। जहाँ Android native permissions, provider credentials या backend चाहिए, वहाँ केवल UI दिखाना उस feature के चालू होने के बराबर नहीं है।

## App identity और मुख्य interface
- AKASH और NATASHA persona switch
- Mobile-first dark sci-fi HUD; cyan/blue/purple styling
- Dashboard / Visual Hub, status panel, agent workspace
- Voice, Agent, Notes, Memory, Skills, Voices, Browser, Settings
- Chat history, search, notes export, API/model/endpoint configuration
- Agent action approval queue और Stop/Terminate control surface
- System/connection state display

## Stonic analysis से निकले फीचर — कोई नाम हटाया नहीं गया

| Feature | इस ZIP में स्थिति | वास्तविक आवश्यकता / टिप्पणी |
|---|---|---|
| AI chat / assistant | Basic implementation | Anthropic API key, supported model और network |
| AKASH + NATASHA personas | Basic implementation | अलग आवाज़ें device TTS पर निर्भर |
| Voice input / speech output | Browser/device-dependent | Native reliable audio के लिए Android audio integration |
| Gemini Live realtime voice | Integration scaffold/spec only | Google credentials, realtime audio transport और native audio pipeline |
| Wake word / always-listening | Not active; integration scaffold/spec | Native background service, microphone permission, battery policy; explicit opt-in |
| Memory / conversation history | Local basic implementation | Durable encrypted memory/sync के लिए native DB/backend |
| Notes / files / export | Basic notes and export | Broad file access के लिए Android Storage Access Framework |
| Skills / tool registry | UI/catalog | प्रत्येक skill के लिए वास्तविक tool adapter और permission checks |
| Research / web search agent | Catalog/scaffold | Search provider/API; results and citations adapter |
| Browser open | Basic external browser launch | Automated page reading/clicking requires WebView/browser agent and safety controls |
| Coding / content / media agents | Catalog/scaffold | Real execution or media provider integrations; not simulated as complete |
| Productivity / tasks / calendar | Catalog/scaffold | Calendar permissions and native task scheduler |
| Calling / phone actions | Not silently claimed active | Android dial intent; direct call needs permission/confirmation and device support |
| Messaging / SMS | Not silently claimed active | SMS composer intent; sending directly requires sensitive permission and policy review |
| Mobile app control / accessibility | Not active; native scaffold instructions | Android AccessibilityService, user manually enables it in system settings; secure allowlist required |
| Camera awareness / gesture recognition | Not active; integration spec | Camera permission, on-device vision model, foreground disclosure and user consent |
| Agent approvals / checkpoints | Basic confirmation UI | Native tool runner must enforce approvals before executing actions |
| Terminate / emergency stop | UI/log-level only | Native agent runtime must cancel running tasks and audio services |
| Agent Town / virtual office simulation | Visual concept/catalog only | Separate scene engine; original Stonic assets/code not included |
| System status / device awareness | UI status surface | Android APIs and permissions; CPU/RAM metrics may be restricted |
| Satellite/globe/feed visual | UI concept only | Real data needs a documented data provider; no live satellite access implied |
| Headlines / alerts | Concept/catalog | News/search provider, notification permission and source citations |
| Scheduled jobs / 24×7 operation | Not active; integration spec | WorkManager/foreground service; Android battery/background limits apply |
| Cloud sync / multi-device memory | Not active; architecture spec | Authenticated backend and database |
| Automatic app updates | Not active | Play Store or signed update distribution; APK self-updater needs secure signing/update channel |
| Reboot / reset | UI action concept only | App can reset its own state; it cannot reboot device without privileged/system access |
| Settings / keys / model endpoint | Basic implementation | Current provider model IDs only; local key storage is not production-secure |
| Skills / REBOOT / TERMINATE controls | Surface retained in design inventory | Only actions connected to implemented runtime should be treated as operational |

## मोबाइल कंट्रोल के बारे में
“Computer Use” को PC control के रूप में शामिल नहीं किया गया है। लक्ष्य Android mobile-use integration है। Android सुरक्षा के कारण app बिना user-granted Accessibility permission के दूसरे apps को मनमाने ढंग से control नहीं कर सकती। इस ZIP में permission architecture और implementation checklist है; native service को पूरा और tested मानकर न चलें।

## पूरा APK बनाना
GitHub Actions workflow debug APK बनाता है। यह release-signed production APK नहीं है। Build और device testing के बाद native modules को क्रमशः implement/test करना होगा। API keys GitHub में commit न करें।
