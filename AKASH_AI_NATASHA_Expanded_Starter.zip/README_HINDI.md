# AKASH AI + NATASHA AI — Expanded Starter

## इसमें क्या जोड़ा गया है
- Android WebView app और GitHub Actions debug APK workflow
- Dashboard, START/TERMINATE status, Memory, Soul, Skills, Tasks, Notes, Visual Hub, Logs, Sub Agents UI
- सामान्य OpenAI-compatible chat settings (provider/model/API key उपयोगकर्ता को स्वयं सेट करना होगा)
- वैकल्पिक Python backend: Gemini text chat, SQLite memory/tasks endpoints, Gemini Live WebSocket endpoint
- Gemini Live के लिए माइक्रोफोन स्ट्रीमिंग UI का शुरुआती implementation

## बहुत जरूरी सीमा
यह **पूरा Hermes Agent नहीं है** और अभी production-ready या end-to-end tested नहीं है। Hermes Agent एक अलग, वास्तविक agent framework है। इस पैकेज में केवल Hermes-जैसे modular UI और backend scaffold है; इसमें Hermes के सभी tools, learning loop, checkpoints, browser/file/code tools, cron, subagents, approvals या messaging gateway नहीं हैं।

Gemini Live endpoint भी API key, उपलब्ध Live model, HTTPS/WSS hosting, microphone permissions, quota और परीक्षण पर निर्भर है। इस ZIP को बनाने के दौरान Live API के साथ वास्तविक connection test नहीं किया गया है। Model IDs समय के साथ बदल सकते हैं; Google की official docs में उपलब्ध model जाँचें।

## APK बनाना
1. ZIP को डाउनलोड करके extract करें।
2. Extracted project की फाइलें GitHub repository के root में upload करें (ZIP file को अकेले upload करना पर्याप्त नहीं; पहले extract करें)।
3. `main` branch पर commit करें।
4. GitHub → Actions → “Build AKASH AI Android APK” खोलें।
5. सफल workflow के नीचे Artifacts में `AKASH-AI-NATASHA-debug-APK` डाउनलोड करें।

## Gemini Live backend (अलग से होस्ट करना होगा)
1. `backend/.env.example` की कॉपी `.env` नाम से बनाएँ।
2. उसमें `GEMINI_API_KEY` और उपलब्ध Live model का नाम भरें।
3. `backend/` में Python 3.11+ पर `pip install -r requirements.txt` चलाएँ।
4. `uvicorn main:app --host 0.0.0.0 --port 8000` चलाएँ।
5. मोबाइल app में Live page पर `wss://your-host/live` डालें। सार्वजनिक उपयोग के लिए HTTPS/WSS hosting और access control लगाएँ।
6. API key को APK, frontend या public GitHub repository में कभी न रखें।

## Security / limitations
- API keys and backend credentials are secrets. Do not commit real `.env` files.
- Backend sample has no user authentication/rate limiting yet. Do not expose it publicly until authentication, rate limits, HTTPS and abuse protections are added.
- The app's normal OpenAI-compatible chat and the optional Gemini backend are separate routes in this starter.
- Live microphone stream may require changes after testing on the target Android WebView/device.
- Camera preview, screen sharing, face/gesture recognition, live news/map, autonomous shell/file/browser actions, real Hermes integration and fully working multi-agent orchestration are not implemented.
- LocalStorage data stays in the app WebView storage; it is not automatically synced to backend.
