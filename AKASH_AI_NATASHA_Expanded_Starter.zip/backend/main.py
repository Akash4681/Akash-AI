import os, json, base64, sqlite3, time
from contextlib import closing
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY", "")
CHAT_MODEL = os.getenv("GEMINI_CHAT_MODEL", "gemini-2.5-flash")
LIVE_MODEL = os.getenv("GEMINI_LIVE_MODEL", "gemini-2.5-flash-native-audio-preview-12-2025")
app = FastAPI(title="AKASH AI / NATASHA AI Backend", version="0.2.0")
origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins or ["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])
DB = os.getenv("AKASH_DB", "akash_data.sqlite3")

def init_db():
    with closing(sqlite3.connect(DB)) as db:
        db.execute("CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY, text TEXT NOT NULL, created REAL NOT NULL)")
        db.execute("CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, text TEXT NOT NULL, done INTEGER DEFAULT 0, created REAL NOT NULL)")
        db.commit()
init_db()

class ChatRequest(BaseModel):
    message: str
    persona: str = "AKASH AI"
    soul: str = ""
    memories: list[str] = []

class MemoryRequest(BaseModel):
    text: str

class TaskRequest(BaseModel):
    text: str

def require_key():
    if not API_KEY:
        raise HTTPException(status_code=503, detail="Backend has no GEMINI_API_KEY. Configure it on the server.")

@app.get("/health")
def health():
    return {"ok": True, "service": "akash-ai-backend", "live_model_configured": bool(API_KEY), "chat_model": CHAT_MODEL}

@app.get("/api/memories")
def list_memories():
    with closing(sqlite3.connect(DB)) as db:
        rows = db.execute("SELECT id,text,created FROM memories ORDER BY id DESC LIMIT 100").fetchall()
    return [{"id": r[0], "text": r[1], "created": r[2]} for r in rows]

@app.post("/api/memories")
def save_memory(req: MemoryRequest):
    if not req.text.strip(): raise HTTPException(400, "Memory text is required")
    with closing(sqlite3.connect(DB)) as db:
        cur = db.execute("INSERT INTO memories(text,created) VALUES(?,?)", (req.text.strip(), time.time()))
        db.commit()
        return {"id": cur.lastrowid, "saved": True}

@app.get("/api/tasks")
def list_tasks():
    with closing(sqlite3.connect(DB)) as db:
        rows = db.execute("SELECT id,text,done,created FROM tasks ORDER BY id DESC LIMIT 200").fetchall()
    return [{"id": r[0], "text": r[1], "done": bool(r[2]), "created": r[3]} for r in rows]

@app.post("/api/tasks")
def save_task(req: TaskRequest):
    if not req.text.strip(): raise HTTPException(400, "Task text is required")
    with closing(sqlite3.connect(DB)) as db:
        cur = db.execute("INSERT INTO tasks(text,done,created) VALUES(?,0,?)", (req.text.strip(), time.time()))
        db.commit()
        return {"id": cur.lastrowid, "saved": True}

@app.post("/api/chat")
def chat(req: ChatRequest):
    require_key()
    client = genai.Client(api_key=API_KEY)
    system = f"You are {req.persona}. Personality: {req.soul or 'helpful, clear, respectful'}. Use only relevant memories: " + "\n".join(req.memories[:10])
    try:
        response = client.models.generate_content(model=CHAT_MODEL, contents=[system, req.message])
        return {"text": response.text or "(No text response)", "model": CHAT_MODEL}
    except Exception as e:
        raise HTTPException(502, detail=f"Gemini request failed: {type(e).__name__}: {e}")

@app.websocket("/live")
async def live(websocket: WebSocket):
    await websocket.accept()
    if not API_KEY:
        await websocket.send_json({"error": "Backend missing GEMINI_API_KEY. Set it in backend .env."})
        await websocket.close(code=1011)
        return
    client = genai.Client(api_key=API_KEY)
    try:
        config = {"response_modalities": ["AUDIO"], "system_instruction": "You are AKASH AI, a helpful, clear, respectful mobile voice assistant. Keep responses concise."}
        async with client.aio.live.connect(model=LIVE_MODEL, config=config) as session:
            await websocket.send_json({"text": f"Gemini Live session connected ({LIVE_MODEL})."})
            async def sender():
                while True:
                    raw = await websocket.receive_text()
                    event = json.loads(raw)
                    if event.get("type") == "audio":
                        data = base64.b64decode(event.get("data", ""))
                        await session.send_realtime_input(audio=types.Blob(data=data, mime_type=event.get("mime_type", "audio/pcm;rate=16000")))
                    elif event.get("type") == "text":
                        await session.send_realtime_input(text=str(event.get("text", "")))
                    elif event.get("type") == "end_audio":
                        try: await session.send_realtime_input(audio_stream_end=True)
                        except Exception: pass
            async def receiver():
                async for message in session.receive():
                    sc = getattr(message, "server_content", None)
                    if sc:
                        mt = getattr(sc, "model_turn", None)
                        if mt and getattr(mt, "parts", None):
                            for part in mt.parts:
                                inline = getattr(part, "inline_data", None)
                                if inline and getattr(inline, "data", None):
                                    data = inline.data
                                    if isinstance(data, bytes): data = base64.b64encode(data).decode("ascii")
                                    await websocket.send_json({"audio": data, "mime_type": getattr(inline, "mime_type", "audio/pcm;rate=24000")})
                                text = getattr(part, "text", None)
                                if text: await websocket.send_json({"text": text})
                        if getattr(sc, "turn_complete", False):
                            await websocket.send_json({"turn_complete": True})
            import asyncio
            tasks = [asyncio.create_task(sender()), asyncio.create_task(receiver())]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
            for task in pending: task.cancel()
            for task in done:
                exc = task.exception()
                if exc: raise exc
    except WebSocketDisconnect:
        return
    except Exception as e:
        try: await websocket.send_json({"error": f"Live session error: {type(e).__name__}: {e}"})
        except Exception: pass
        try: await websocket.close(code=1011)
        except Exception: pass
