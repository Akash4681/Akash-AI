# AKASH AI + NATASHA AI — combined Android source update

This package preserves the existing Capacitor web app and native PhoneControl sources, updates the dashboard for the requested red/black control-room layout, adds separate VOICE / AGENT / NOTES / CHAT tabs, and includes cropped reference artwork for the AKASH and NATASHA avatar panels.

## Build from GitHub

1. Upload the **contents** of this ZIP to the root of your GitHub repository (keep the `.github/workflows/build.yml` path intact).
2. Open **Actions** and run **Build AKASH AI + NATASHA AI APK**, or push a commit to `main`/`master`.
3. Download the `akash-natasha-full-apk` artifact after the workflow succeeds.

The workflow intentionally fails if the full Phone Control build fails; it will not silently substitute a basic APK and claim that Phone Control is present.

## Important feature notes

- The current app already has a JavaScript agent loop, provider calls, localStorage-based memory, voice recognition hooks, reminders, file tools, sub-task delegation, local task checkpoints, a configurable OpenAI-compatible endpoint, and a custom native PhoneControl plugin implementation.
- The new dashboard labels advanced tools as **Hermes-inspired**. This package does **not** include the upstream Hermes Agent engine itself; browser/file/sub-agent/checkpoint/scheduler capabilities must only be treated as functional where the underlying tool implementation exists and passes tests.
- Default model IDs are set to Claude Sonnet 5, Gemini 3.8 Flash, and Groq GPT-OSS 120B based on provider documentation checked during this update; availability still depends on your account and provider access. Use Settings to set a model ID supported by the provider and a valid API key. A custom OpenAI-compatible provider can be configured with its API key, base URL, and model ID; Settings can then prompt for a connection test.
- API keys are currently stored in the app's localStorage and provider calls originate from the app. This is convenient for a personal prototype but is not a secure production secret-storage design. Do not embed keys you cannot afford to expose.
- Android Accessibility must be enabled manually by the user in Android Settings. Phone actions can be limited by the target app, Android version, or protected screens. SMS can incur carrier charges and requires user permission.
- The avatar artwork is cropped from the reference images you supplied; it is a visual reference panel, not a live 3D animated human model.

## Main files

- `www/index.html` — dashboard, chat, voice UI, agent loop, settings and memory
- `native/PhoneControlPlugin.java` — Capacitor bridge to native Android functions
- `native/PhoneControlService.java` — Accessibility-based screen inspection and actions
- `native/patch_manifest.py` — idempotent manifest patch for full build
- `.github/workflows/build.yml` — GitHub Actions full APK build
