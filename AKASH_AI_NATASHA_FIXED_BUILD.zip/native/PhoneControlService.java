package com.akashnatasha.app;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

public class PhoneControlService extends AccessibilityService {
  static PhoneControlService inst;
  @Override protected void onServiceConnected() { inst = this; }
  @Override public boolean onUnbind(android.content.Intent i) { inst = null; return super.onUnbind(i); }
  @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
  @Override public void onInterrupt() {}

  static String dump() {
    if (inst == null) return "service off";
    AccessibilityNodeInfo root = inst.getRootInActiveWindow();
    if (root == null) return "(no window)";
    StringBuilder sb = new StringBuilder();
    walk(root, sb, new int[]{0});
    return sb.toString();
  }
  static void walk(AccessibilityNodeInfo nd, StringBuilder sb, int[] n) {
    if (nd == null || n[0] >= 150) return;
    CharSequence t = nd.getText(), d = nd.getContentDescription();
    if ((t != null && t.length() > 0) || (d != null && d.length() > 0) || nd.isClickable() || nd.isEditable()) {
      Rect r = new Rect();
      nd.getBoundsInScreen(r);
      sb.append(n[0]++).append(": ").append(t != null ? t : "").append(d != null ? " [" + d + "]" : "")
        .append(nd.isClickable() ? " (tap)" : "").append(nd.isEditable() ? " (input)" : "")
        .append(" @").append(r.centerX()).append(",").append(r.centerY()).append("\n");
    }
    for (int i = 0; i < nd.getChildCount(); i++) walk(nd.getChild(i), sb, n);
  }
  static boolean tapText(String s) {
    if (inst == null) return false;
    AccessibilityNodeInfo root = inst.getRootInActiveWindow();
    if (root == null) return false;
    List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(s);
    for (AccessibilityNodeInfo nd : l) {
      AccessibilityNodeInfo c = nd;
      while (c != null && !c.isClickable()) c = c.getParent();
      if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
    }
    return false;
  }
  static boolean tapXY(int x, int y) {
    if (inst == null) return false;
    Path p = new Path();
    p.moveTo(x, y);
    GestureDescription g = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build();
    return inst.dispatchGesture(g, null, null);
  }
  static boolean typeText(String s) {
    if (inst == null) return false;
    AccessibilityNodeInfo root = inst.getRootInActiveWindow();
    if (root == null) return false;
    AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    if (f == null) return false;
    Bundle b = new Bundle();
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s);
    return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
  }
  static boolean globalAct(String a) {
    if (inst == null) return false;
    int c;
    switch (a) {
      case "back": c = GLOBAL_ACTION_BACK; break;
      case "home": c = GLOBAL_ACTION_HOME; break;
      case "recents": c = GLOBAL_ACTION_RECENTS; break;
      case "notifications": c = GLOBAL_ACTION_NOTIFICATIONS; break;
      default: return false;
    }
    return inst.performGlobalAction(c);
  }
  static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n) {
    if (n == null) return null;
    if (n.isScrollable()) return n;
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo r = findScrollable(n.getChild(i));
      if (r != null) return r;
    }
    return null;
  }
  static boolean scroll(boolean down) {
    if (inst == null) return false;
    AccessibilityNodeInfo s = findScrollable(inst.getRootInActiveWindow());
    return s != null && s.performAction(down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
  }
}
