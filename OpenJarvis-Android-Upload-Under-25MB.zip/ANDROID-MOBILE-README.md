# OpenJarvis Mobile APK build (Android)

This is an Android WebView/Capacitor packaging path for the existing OpenJarvis frontend. It is **not** a port of the Python/Rust inference backend to Android.

## Build the APK using GitHub Actions (no PC or Termux required)

1. Create/open your GitHub repository and upload the **contents** of this ZIP (not the ZIP file itself).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build OpenJarvis Android APK** and press **Run workflow** (or wait for the workflow triggered by a push).
5. Open the successful run, find **Artifacts**, and download `OpenJarvis-Mobile-debug-APK`.
6. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from that browser/file manager.

## Important: backend connection

OpenJarvis's frontend normally talks to an OpenJarvis API backend at `http://127.0.0.1:8000` or to a configured API URL. On Android, `127.0.0.1` means the phone itself. The APK therefore builds the interface, but it will not provide a working AI backend by itself. To chat, configure a reachable OpenJarvis API server URL in the app's Settings (for example, a server you control and have secured). Do not expose an unauthenticated API server to the public internet.

The official project documentation describes the desktop/browser app as connecting to a separately running backend: https://github.com/open-jarvis/OpenJarvis/blob/main/docs/getting-started/installation.md

## Scope and caveats

- This is a **debug APK** intended for testing, not a signed Play Store release.
- Desktop-only features that depend on Tauri commands, local Ollama management, OS tray functions, or desktop file access may not work on Android.
- This build uses the existing OpenJarvis UI. It does not silently claim that local model inference runs on the phone.
