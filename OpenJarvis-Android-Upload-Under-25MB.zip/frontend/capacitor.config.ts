import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'edu.stanford.openjarvis.mobile',
  appName: 'OpenJarvis Mobile',
  webDir: '../src/openjarvis/server/static',
  server: {
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true
  }
};

export default config;
