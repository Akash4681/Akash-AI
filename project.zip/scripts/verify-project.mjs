import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';

const read = (p) => fs.readFileSync(p, 'utf8');
const html = read('www/index.html');
const pkg = JSON.parse(read('package.json'));
const workflow = read('.github/workflows/build.yml');
const requiredFiles = [
  'www/index.html', 'capacitor.config.json', 'native/MainActivity.java',
  'native/PhoneControlPlugin.java', 'native/PhoneControlService.java',
  'native/patch_manifest.py', '.github/workflows/build.yml'
];
for (const p of requiredFiles) assert.ok(fs.existsSync(p), `Missing required file: ${p}`);
assert.equal(pkg.name, 'akash-natasha', 'Unexpected package name');
assert.match(html, /const CALL\s*=\s*\{/ , 'Provider dispatcher is missing');
for (const provider of ['claude', 'gemini', 'groq', 'custom', 'hermes']) {
  assert.match(html, new RegExp(`\\b${provider}\\b`, 'i'), `Provider missing: ${provider}`);
}
for (const tool of ['remember', 'memory_search', 'file_write', 'file_read', 'run_js', 'delegate', 'save_checkpoint', 'resume_checkpoint', 'search_web', 'web_fetch', 'phone_screen', 'phone_tap', 'github_repo_status', 'github_list_files', 'github_read_file', 'github_patch_file', 'github_write_file']) {
  assert.ok(html.includes(`name:'${tool}'`) || html.includes(`name: '${tool}'`), `Expected tool missing: ${tool}`);
}
assert.match(workflow, /node-version:\s*22/);
assert.match(workflow, /assembleDebug/);
assert.match(workflow, /upload-artifact@v4/);
assert.match(html, /function ghPath\(/, 'GitHub path safety guard is missing');
assert.match(html, /async function ghPatch\(/, 'GitHub exact-fragment patch tool is missing');
assert.match(html, /if\(!confirm\('GitHub पर source file बदलकर commit करूँ\?/, 'GitHub writes must require explicit confirmation');
assert.match(html, /p\.startsWith\('\.github\/'\)/, 'GitHub workflow path protection is missing');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)];
assert.ok(scripts.length > 0, 'No inline JavaScript found');
for (let i = 0; i < scripts.length; i++) {
  new vm.Script(scripts[i][1], { filename: `www/index.html:inline-script-${i + 1}` });
}
console.log(`Project preflight passed: ${requiredFiles.length} required files, ${scripts.length} JavaScript block(s), providers and core tools present.`);
console.log('This is a static preflight only; it does not prove API keys, Android permissions, or device features work at runtime.');
