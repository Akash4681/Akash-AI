# AKASH AI + NATASHA AI — consolidated Android project

This is a consolidated update of the existing Capacitor Android project. It keeps the existing dashboard, avatar assets, voice hooks, local memory, agent loop, API provider settings, tools, and native PhoneControl source instead of replacing the app with a new minimal project.

## Build from GitHub (one upload)

1. In your existing GitHub repository, upload this ZIP file itself to the repository root, keeping the exact filename `AKASH_AI_NATASHA_UPDATED.zip`. You do not need to extract it on your phone.
2. Commit the uploaded ZIP. The existing `.github/workflows/build.yml` recognizes this filename and extracts the source during the build.
3. Open **Actions** and check **Build AKASH AI + NATASHA AI APK**.
4. When the workflow succeeds, download the `akash-natasha-full-apk` artifact. If it fails, open the run and use its error message before trying another upload.

The workflow runs a static project preflight before building and fails if the full Phone Control build fails. It does not silently substitute a basic APK.

## Voice and character panel

The dashboard now shows the supplied Akash/Natasha scene artwork as a larger, stable rectangular panel rather than a tiny circular crop. While speech is playing, the panel glows/pulses and a small mouth overlay animates on the avatar image, with the speaking indicator. This is a visual approximation timed to the speech state, not phoneme-accurate lip-sync, facial-motion AI, or a live 3D face.

Optional ElevenLabs text-to-speech can be configured in Settings using an API key and the two voice IDs (one for Akash, one for Natasha). If the request is blocked by network/CORS, the voice ID is invalid, or the service quota is reached, the app falls back to the phone voice. ElevenLabs usage may be paid/limited. The key is stored in local app storage, so use a revocable key and do not treat this prototype as secure secret storage.

## Included provider options

- Groq
- Google Gemini
- Anthropic Claude
- Custom OpenAI-compatible endpoint
- Optional external Hermes endpoint

The app can try configured providers in the saved priority order and fall back after a provider request fails. Only providers with saved keys are attempted. Provider fallback does **not** remove any provider's free-tier quotas or make usage unlimited. API model IDs and availability depend on the provider and account; set a currently supported model ID in Settings if the default is unavailable.

## GitHub coding-agent connection (optional)

The app now includes GitHub repository tools so an authorized assistant can inspect source files, read a file in chunks, patch one exact unique fragment, and propose a commit. A write always requires a separate Android/WebView confirmation dialog. A successful commit to the configured branch can trigger the existing GitHub Actions APK workflow. The app can also check recent workflow run status.

To enable it, open Settings and accept the optional GitHub setup prompts. Create a fine-grained GitHub token limited to your one repository with **Contents: Read and write** and **Actions: Read**. Configure the owner/repository (for example `Akash4681/Akash-AI`) and branch (`main`). Do not use a classic token or a token with broad account permissions. The app stores the token in localStorage, which is a prototype-level storage choice; use a temporary/revocable token and revoke it when no longer needed.

For safety, source writes are restricted to `www/`, `native/`, `scripts/`, `README.md`, `package.json`, and `capacitor.config.json`. The assistant cannot write `.github/workflows/`, `android/`, `.git/`, or arbitrary paths through this tool. A GitHub write is not proof that the APK build passed; check the Actions result before installing an artifact.

## Existing capabilities retained

- Akash/Natasha personas and avatar artwork
- Local conversation memory, saved skills, and chat history
- Voice recognition hooks and text-to-speech support
- Agent loop and tool calls
- File tools, saved JavaScript snippets, sub-task delegation, checkpoints, and reminders
- Web search/fetch tools
- Android PhoneControl plugin and Accessibility service source
- GitHub Actions Android debug APK build

## Important boundaries

- `file_write` saves text into the app's local storage. It does not rewrite the installed app's own source code or publish a new APK.
- A true source-code editing agent requires a separately authenticated repository/build service, careful permission controls, review/approval, tests, and rollback. This package does not claim unattended self-modification is already implemented.
- The PhoneControl service needs the user to enable Android Accessibility manually. Actions are limited by Android permissions, the target app, and protected screens. SMS may incur carrier charges and requires explicit permission.
- API keys are stored in the app's localStorage and provider calls originate from the app. This is a personal prototype pattern, not secure production secret storage. Do not use keys you cannot afford to expose.
- Repeating tasks run only while the app is open; Android background execution is not guaranteed.
- The avatar art remains a still image; a small mouth overlay and glow animate during speech as a visual approximation. It is not a live 3D human model or phoneme-accurate lip-sync. Speech and animation quality depend on device TTS and app implementation.
- The project has not been built and runtime-tested on the user's Redmi Note 10 Pro in this environment. The static preflight checks source structure and JavaScript syntax only; successful GitHub Actions and device tests are still required.

## Local static check

With Node.js 22 installed, run:

```sh
npm test
```

This checks required source files, JavaScript syntax, provider names, core tools, and key build-workflow markers. It does not test API credentials or Android runtime behavior.
