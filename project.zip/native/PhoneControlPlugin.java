package com.akashnatasha.app;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.telephony.SmsManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import android.speech.tts.TextToSpeech;
import java.util.ArrayList;
import java.util.Locale;

@CapacitorPlugin(name = "PhoneControl", permissions = {@Permission(strings = {Manifest.permission.SEND_SMS}, alias = "sms")})
public class PhoneControlPlugin extends Plugin {
  private void ok(PluginCall c, boolean v) { JSObject o = new JSObject(); o.put("ok", v); c.resolve(o); }

  @PluginMethod public void isEnabled(PluginCall c) { JSObject o = new JSObject(); o.put("enabled", PhoneControlService.inst != null); c.resolve(o); }
  @PluginMethod public void openSettings(PluginCall c) {
    Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    getContext().startActivity(i);
    c.resolve();
  }
  @PluginMethod public void readScreen(PluginCall c) { JSObject o = new JSObject(); o.put("screen", PhoneControlService.dump()); c.resolve(o); }
  @PluginMethod public void tap(PluginCall c) {
    String t = c.getString("text");
    ok(c, t != null ? PhoneControlService.tapText(t) : PhoneControlService.tapXY(c.getInt("x", 0), c.getInt("y", 0)));
  }
  @PluginMethod public void typeText(PluginCall c) { ok(c, PhoneControlService.typeText(c.getString("text", ""))); }
  @PluginMethod public void globalAction(PluginCall c) { ok(c, PhoneControlService.globalAct(c.getString("action", ""))); }
  @PluginMethod public void scroll(PluginCall c) { ok(c, PhoneControlService.scroll(!"up".equals(c.getString("direction", "down")))); }
  @PluginMethod public void openApp(PluginCall c) {
    String q = c.getString("name", "").toLowerCase();
    PackageManager pm = getContext().getPackageManager();
    Intent m = new Intent(Intent.ACTION_MAIN);
    m.addCategory(Intent.CATEGORY_LAUNCHER);
    for (ResolveInfo r : pm.queryIntentActivities(m, 0)) {
      String l = r.loadLabel(pm).toString().toLowerCase();
      if (l.contains(q)) {
        Intent i = pm.getLaunchIntentForPackage(r.activityInfo.packageName);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        JSObject o = new JSObject(); o.put("ok", true); o.put("app", l); c.resolve(o);
        return;
      }
    }
    c.reject("app not found");
  }
  @PluginMethod public void sendSms(PluginCall c) {
    if (getPermissionState("sms") != PermissionState.GRANTED) { requestPermissionForAlias("sms", c, "smsCb"); return; }
    doSms(c);
  }
  @PermissionCallback private void smsCb(PluginCall c) {
    if (getPermissionState("sms") == PermissionState.GRANTED) doSms(c); else c.reject("SMS permission denied");
  }
  private TextToSpeech tts;
  private boolean ttsReady = false;
  private String pendingText = null;
  private Locale pendingLoc = null;

  @PluginMethod public void speak(final PluginCall c) {
    final String t = c.getString("text", "");
    final Locale loc = Locale.forLanguageTag(c.getString("lang", "hi-IN"));
    getActivity().runOnUiThread(() -> {
      if (tts == null) {
        tts = new TextToSpeech(getContext(), status -> {
          ttsReady = (status == TextToSpeech.SUCCESS);
          if (ttsReady && pendingText != null) {
            tts.setLanguage(pendingLoc);
            tts.speak(pendingText, TextToSpeech.QUEUE_FLUSH, null, "akash");
            pendingText = null;
          }
        });
      }
      if (ttsReady) {
        tts.setLanguage(loc);
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "akash");
      } else {
        pendingText = t;
        pendingLoc = loc;
      }
    });
    c.resolve();
  }

  private void doSms(PluginCall c) {
    try {
      SmsManager sm = SmsManager.getDefault();
      ArrayList<String> parts = sm.divideMessage(c.getString("text", ""));
      sm.sendMultipartTextMessage(c.getString("number"), null, parts, null, null);
      ok(c, true);
    } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
  }
}
