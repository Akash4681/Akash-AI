package com.akashnatasha.app;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.provider.Settings;
import android.telephony.SmsManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.ArrayList;
import java.util.Locale;

@CapacitorPlugin(name = "PhoneControl", permissions = {@Permission(strings = {Manifest.permission.SEND_SMS}, alias = "sms")})
public class PhoneControlPlugin extends Plugin {
  private void ok(PluginCall c, boolean v) { JSObject o = new JSObject(); o.put("ok", v); c.resolve(o); }

  @PluginMethod public void isEnabled(PluginCall c) { JSObject o = new JSObject(); o.put("enabled", PhoneControlService.inst != null); c.resolve(o); }
  @PluginMethod public void openSettings(PluginCall c) {
    Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    getContext().startActivity(i);
    c.resolve();
  }
  @PluginMethod public void readScreen(PluginCall c) { JSObject o = new JSObject(); o.put("screen", PhoneControlService.dump()); c.resolve(o); }
  @PluginMethod public void tap(PluginCall c) {
    String t = c.getString("text");
    ok(c, t != null ? PhoneControlService.tapText(t) : PhoneControlService.tapXY(c.getInt("x", 0), c.getInt("y", 0)));
  }
  @PluginMethod public void typeText(PluginCall c) { ok(c, PhoneControlService.typeText(c.getString("text", ""))); }
  @PluginMethod public void globalAction(PluginCall c) { ok(c, PhoneControlService.globalAct(c.getString("action", ""))); }
  @PluginMethod public void scroll(PluginCall c) { ok(c, PhoneControlService.scroll(!"up".equals(c.getString("direction", "down")))); }
  @PluginMethod public void openApp(PluginCall c) {
    String q = c.getString("name", "").toLowerCase();
    PackageManager pm = getContext().getPackageManager();
    Intent m = new Intent(Intent.ACTION_MAIN);
    m.addCategory(Intent.CATEGORY_LAUNCHER);
    for (ResolveInfo r : pm.queryIntentActivities(m, 0)) {
      String l = r.loadLabel(pm).toString().toLowerCase();
      if (l.contains(q)) {
        Intent i = pm.getLaunchIntentForPackage(r.activityInfo.packageName);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        JSObject o = new JSObject(); o.put("ok", true); o.put("app", l); c.resolve(o);
        return;
      }
    }
    c.reject("app not found");
  }
  @PluginMethod public void sendSms(PluginCall c) {
    if (getPermissionState("sms") != PermissionState.GRANTED) { requestPermissionForAlias("sms", c, "smsCb"); return; }
    doSms(c);
  }
  @PermissionCallback private void smsCb(PluginCall c) {
    if (getPermissionState("sms") == PermissionState.GRANTED) doSms(c); else c.reject("SMS permission denied");
  }
  private TextToSpeech tts;
  private boolean ttsReady = false;
  private String pendingText = null;
  private Locale pendingLoc = null;
  private String pendingGender = "male";
  private int ttsStatus = -99;
  private int hiAvail = -99;

  private void configureVoice(Locale loc, String gender) {
    if (tts == null) return;
    tts.setLanguage(loc);
    try {
      for (Voice v : tts.getVoices()) {
        if (v == null || v.getLocale() == null || !v.getLocale().getLanguage().equals(loc.getLanguage())) continue;
        String n = v.getName().toLowerCase(Locale.ROOT);
        boolean match = "female".equals(gender) ? (n.contains("female") || n.contains("woman") || n.contains("zira") || n.contains("samantha")) : ((n.contains("male") && !n.contains("female")) || (n.contains("man") && !n.contains("woman")) || n.contains("david") || n.contains("mark"));
        if (match) { tts.setVoice(v); return; }
      }
    } catch (Exception ignored) { }
  }

  @PluginMethod public void speak(final PluginCall c) {
    final String t = c.getString("text", "");
    final Locale loc = Locale.forLanguageTag(c.getString("lang", "hi-IN"));
    final String gender = c.getString("voice", "male");
    getActivity().runOnUiThread(() -> {
      if (tts == null) {
        tts = new TextToSpeech(getContext(), status -> {
          ttsStatus = status;
          ttsReady = (status == TextToSpeech.SUCCESS);
          if (ttsReady) { try { hiAvail = tts.isLanguageAvailable(new Locale("hi", "IN")); } catch (Exception ignored) { } }
          if (ttsReady && pendingText != null) {
            configureVoice(pendingLoc, pendingGender);
            tts.speak(pendingText, TextToSpeech.QUEUE_FLUSH, null, "akash");
            pendingText = null;
          }
        });
      }
      if (ttsReady) {
        configureVoice(loc, gender);
        tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "akash");
      } else {
        pendingText = t;
        pendingLoc = loc;
        pendingGender = gender;
      }
    });
    c.resolve();
  }

  @PluginMethod public void ttsInfo(PluginCall c) {
    JSObject o = new JSObject();
    o.put("ready", ttsReady);
    o.put("status", ttsStatus);
    o.put("hindi", hiAvail);
    c.resolve(o);
  }

  @PluginMethod public void openTtsSettings(PluginCall c) {
    try {
      Intent i = new Intent("com.android.settings.TTS_SETTINGS");
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      getContext().startActivity(i);
    } catch (Exception e) {
      try {
        Intent i2 = new Intent(android.provider.Settings.ACTION_SETTINGS);
        i2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i2);
      } catch (Exception ignored) { }
    }
    c.resolve();
  }

  @PluginMethod public void muteBeeps(PluginCall c) {
    boolean on = c.getBoolean("on", true);
    try {
      android.media.AudioManager am = (android.media.AudioManager) getContext().getSystemService(android.content.Context.AUDIO_SERVICE);
      int[] streams = {android.media.AudioManager.STREAM_NOTIFICATION, android.media.AudioManager.STREAM_SYSTEM, android.media.AudioManager.STREAM_MUSIC};
      for (int s : streams) {
        try { am.adjustStreamVolume(s, on ? android.media.AudioManager.ADJUST_MUTE : android.media.AudioManager.ADJUST_UNMUTE, 0); } catch (Exception ignored) { }
      }
    } catch (Exception ignored) { }
    c.resolve();
  }

  private void doSms(PluginCall c) {
    try {
      SmsManager sm = SmsManager.getDefault();
      ArrayList<String> parts = sm.divideMessage(c.getString("text", ""));
      sm.sendMultipartTextMessage(c.getString("number"), null, parts, null, null);
      ok(c, true);
    } catch (Exception e) { c.reject(String.valueOf(e.getMessage())); }
  }
}
