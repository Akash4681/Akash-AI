import sys
from pathlib import Path

mode = sys.argv[1] if len(sys.argv) > 1 else "full"
manifest = Path("android/app/src/main/AndroidManifest.xml")
if not manifest.exists():
    raise SystemExit("ERROR: AndroidManifest.xml not found; run npx cap add android first")
m = manifest.read_text(encoding="utf-8")

def add_before_application(xml, snippet):
    if snippet in xml:
        return xml
    marker = "<application"
    i = xml.find(marker)
    if i < 0:
        raise SystemExit("ERROR: <application> tag not found in AndroidManifest.xml")
    return xml[:i] + snippet + "\n    " + xml[i:]

perms = [
    '<uses-permission android:name="android.permission.RECORD_AUDIO"/>',
    '<uses-permission android:name="android.permission.CAMERA"/>',
    '<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>',
    '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>',
]
if mode == "full":
    perms.append('<uses-permission android:name="android.permission.SEND_SMS"/>')
for perm in perms:
    if perm not in m:
        m = add_before_application(m, perm)

queries = '''<queries>
      <intent><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent>
      <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
    </queries>'''
if mode == "full" and "<queries>" not in m:
    m = add_before_application(m, queries)

service = '''<service android:name=".PhoneControlService"
        android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"
        android:exported="true" android:label="@string/a11y_label">
        <intent-filter><action android:name="android.accessibilityservice.AccessibilityService"/></intent-filter>
        <meta-data android:name="android.accessibilityservice" android:resource="@xml/accessibility_service_config"/>
      </service>'''
if mode == "full" and ".PhoneControlService" not in m:
    marker = "</application>"
    if marker not in m:
        raise SystemExit("ERROR: </application> tag not found")
    m = m.replace(marker, service + "\n    " + marker, 1)
if "usesCleartextTraffic" not in m:
    m = m.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
manifest.write_text(m, encoding="utf-8")
print("Manifest patched for", mode, "build")
