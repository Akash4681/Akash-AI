import sys
mode = sys.argv[1] if len(sys.argv) > 1 else 'safe'
p = 'android/app/src/main/AndroidManifest.xml'
m = open(p, encoding='utf-8').read()
if mode == 'safe':
    add = ('<uses-permission android:name="android.permission.RECORD_AUDIO"/>'
           '<uses-permission android:name="android.permission.CAMERA"/>'
           '<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>'
           '<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS"/>')
    m = m.replace('</manifest>', add + '</manifest>', 1)
else:
    svc = ('<service android:name=".PhoneControlService" '
           'android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE" android:exported="true">'
           '<intent-filter><action android:name="android.accessibilityservice.AccessibilityService"/></intent-filter>'
           '<meta-data android:name="android.accessibilityservice" android:resource="@xml/accessibility_service_config"/>'
           '</service>')
    add = ('<uses-permission android:name="android.permission.SEND_SMS"/>'
           '<queries><intent><action android:name="android.intent.action.MAIN"/>'
           '<category android:name="android.intent.category.LAUNCHER"/></intent>'
           '<intent><action android:name="android.intent.action.TTS_SERVICE"/></intent></queries>')
    m = m.replace('</application>', svc + '</application>', 1).replace('</manifest>', add + '</manifest>', 1)
open(p, 'w', encoding='utf-8').write(m)
print('patched', mode)
