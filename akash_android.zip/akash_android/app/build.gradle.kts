plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.akash.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.akash.ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

chaquopy {
    defaultConfig {
        version = "3.13"
        buildPython("python3")
        pip {
            install("flask")
            install("requests")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
