import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "com.akash.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.akash.ai"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

chaquopy {
    defaultConfig {
        version = "3.13"
        buildPython("python3")
        pip {
            install("flask")
            install("requests")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.alphacephei:vosk-android:0.3.47@aar")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}

// Downloads the small offline Hindi voice model (used only to hear the word "आकाश") before every build.
val downloadVoiceModel = tasks.register("downloadVoiceModel") {
    val outDir = file("src/main/assets/vosk-model")
    doLast {
        if (File(outDir, "am").exists()) return@doLast
        try {
            val zip = File(temporaryDir, "model.zip")
            uri("https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip").toURL().openStream().use { i ->
                zip.outputStream().use { o -> i.copyTo(o) }
            }
            ZipInputStream(zip.inputStream()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val rel = e.name.substringAfter('/', "")
                    if (rel.isNotEmpty()) {
                        val f = File(outDir, rel)
                        if (f.canonicalPath.startsWith(outDir.canonicalPath)) {
                            if (e.isDirectory) f.mkdirs() else {
                                f.parentFile.mkdirs()
                                f.outputStream().use { zin.copyTo(it) }
                            }
                        }
                    }
                    e = zin.nextEntry
                }
            }
        } catch (ex: Exception) {
            logger.warn("Voice model download failed (${ex.message}); the app will use the basic listener.")
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(downloadVoiceModel) }
tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach { dependsOn(downloadVoiceModel) }
