package com.akash.ai

import android.content.Context
import android.content.res.AssetManager
import android.util.Log
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Starts the embedded Python (Flask) AKASH server once per process. */
object ServerHost {
    const val PORT = 5000
    @Volatile private var started = false

    @Synchronized
    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val web = File(app.filesDir, "web")
        val marker = File(app.filesDir, "web.version")
        val version = app.packageManager.getPackageInfo(app.packageName, 0).lastUpdateTime.toString()
        if (!web.exists() || !marker.exists() || marker.readText() != version) {
            web.deleteRecursively()
            copyAssets(app.assets, "web", web)
            marker.writeText(version)
        }
        val data = File(app.filesDir, "data").apply { mkdirs() }
        if (!Python.isStarted()) Python.start(AndroidPlatform(app))
        Thread({
            try {
                Python.getInstance().getModule("akash_server")
                    .callAttr("run", web.absolutePath, data.absolutePath, PORT)
            } catch (e: Exception) {
                Log.e("AKASH", "server stopped", e)
                started = false
            }
        }, "akash-server").start()
    }

    fun isUp(): Boolean = try {
        val c = URL("http://127.0.0.1:$PORT/health").openConnection() as HttpURLConnection
        c.connectTimeout = 800
        c.readTimeout = 800
        c.responseCode == 200
    } catch (e: Exception) {
        false
    }

    private fun copyAssets(am: AssetManager, path: String, dest: File) {
        val children = am.list(path)
        if (children.isNullOrEmpty()) {
            dest.parentFile?.mkdirs()
            am.open(path).use { input -> dest.outputStream().use { input.copyTo(it) } }
        } else {
            dest.mkdirs()
            for (name in children) copyAssets(am, "$path/$name", File(dest, name))
        }
    }
}
