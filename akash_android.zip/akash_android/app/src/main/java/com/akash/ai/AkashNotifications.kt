package com.akash.ai

import android.app.Notification
import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

/** Keeps the latest notifications (so AKASH can read them out) once the user gives "Notification access". */
class AkashNotifications : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (n.packageName == packageName || n.isOngoing) return
        if (n.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(n.packageName, 0)).toString()
        } catch (e: Exception) {
            n.packageName
        }
        synchronized(recent) {
            recent.addFirst(JSONObject().put("app", label).put("title", title).put("text", text).put("time", System.currentTimeMillis()))
            while (recent.size > 40) recent.removeLast()
        }
        if (speak) AkashService.instance?.speakAsync("$label पर $title: $text".take(200))
    }

    companion object {
        private val recent = java.util.ArrayDeque<JSONObject>()
        @Volatile var speak = false

        fun latest(limit: Int): JSONArray {
            val out = JSONArray()
            synchronized(recent) { recent.take(limit.coerceIn(1, 20)).forEach { out.put(it) } }
            return out
        }

        fun enabled(ctx: Context): Boolean {
            val s = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")
            return s?.contains(ctx.packageName) == true
        }
    }
}
