package com.akash.ai

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Silent always-on listening (no "tong" beeps):
 *  1. One AudioRecord stream; a tiny offline Vosk model only listens for the word "आकाश".
 *  2. After the wake word, the following speech is recorded and sent to /api/stt (Whisper);
 *     if that is unavailable, the offline model decodes it.
 *  3. After every answer there is an 8-second follow-up window that needs no wake word.
 */
class VoiceEngine(private val svc: AkashService) {
    @Volatile var running = false
    private var thread: Thread? = null
    private var model: Model? = null
    private lateinit var rec: AudioRecord
    private var noise = 300.0
    private var hits = 0

    fun start() {
        if (running) return
        running = true
        thread = Thread({
            try {
                loop()
            } catch (e: InterruptedException) {
                // stopped
            } catch (e: Throwable) {
                Log.e("AKASH", "voice loop died", e)
                if (running) svc.engineDied()
            }
        }, "akash-voice").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.interrupt()
    }

    private fun loadModel(): Model? {
        val ctx = svc.applicationContext
        if (ctx.assets.list("vosk-model").isNullOrEmpty()) return null
        val dir = File(ctx.filesDir, "vosk-model")
        val mark = File(ctx.filesDir, "vosk-model.ok")
        val ver = ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime.toString()
        if (!dir.exists() || !mark.exists() || mark.readText() != ver) {
            dir.deleteRecursively()
            ServerHost.copyAssets(ctx.assets, "vosk-model", dir)
            mark.writeText(ver)
        }
        return Model(dir.absolutePath)
    }

    private fun loop() {
        val m = loadModel()
        if (m == null) {
            svc.engineUnavailable()
            return
        }
        model = m
        val wake = Recognizer(m, RATE.toFloat(), "[\"आकाश\", \"[unk]\"]")
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 16384))
        rec.startRecording()
        svc.state("idle")
        val ring = java.util.ArrayDeque<ShortArray>()
        try {
            while (running) {
                val f = readFrame() ?: continue
                if (svc.isSpeaking()) {
                    ring.clear()
                    continue
                }
                val r = rms(f)
                if (r < noise * 3) noise = noise * 0.98 + r * 0.02
                ring.addLast(f)
                while (ring.size > 75) ring.removeFirst()
                if (wakeHit(wake, f)) {
                    val pre = ring.toList()
                    ring.clear()
                    svc.state("listening")
                    val text = clean(transcribe(capture(pre, 15000)))
                    converse(if (text.length > 1) text else null, wake)
                    svc.state("idle")
                    wake.reset()
                    hits = 0
                }
            }
        } finally {
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            wake.close()
        }
    }

    // ---------- conversation ----------
    private fun converse(first: String?, wake: Recognizer) {
        var cmd: String? = first
        var rounds = 0
        while (running && rounds < 30) {
            rounds++
            if (cmd.isNullOrBlank()) {
                svc.state("speaking")
                say("जी?", wake)
                svc.state("listening")
                cmd = followUp(15000) ?: return
            }
            svc.state("thinking")
            val answer = svc.ask(cmd ?: return)
            svc.state("speaking")
            say(answer, wake)
            svc.state("listening")
            cmd = followUp(15000) ?: return
        }
    }

    /** Speaks and, while speaking, lets a loud "आकाश" interrupt it. */
    private fun say(text: String, wake: Recognizer) {
        svc.startSpeak(text)
        var strikes = 0
        val giveUp = System.currentTimeMillis() + 45000
        while (running && svc.isSpeaking() && System.currentTimeMillis() < giveUp) {
            val f = readFrame() ?: continue
            if (rms(f) > max(1500.0, noise * 6) && wakeHit(wake, f)) {
                if (++strikes >= 1) {
                    svc.stopSpeak()
                    break
                }
            }
        }
        if (svc.isSpeaking()) svc.stopSpeak()
        wake.reset()
        hits = 0
        val until = System.currentTimeMillis() + 450
        while (running && System.currentTimeMillis() < until) readFrame()
    }

    private fun followUp(ms: Int): String? {
        val pre = waitForSpeech(ms) ?: return null
        val t = clean(transcribe(capture(pre, 15000)))
        return if (t.length > 1) t else null
    }

    private fun clean(t: String): String = WAKE.replaceFirst(t.trim(), "").trim().trim(',', '.', '।', '!')

    // ---------- audio ----------
    private fun readFrame(): ShortArray? {
        val buf = ShortArray(FRAME)
        var got = 0
        while (got < FRAME) {
            val n = rec.read(buf, got, FRAME - got)
            if (n <= 0) {
                Thread.sleep(5)
                return null
            }
            got += n
        }
        return buf
    }

    private fun rms(f: ShortArray): Double {
        var s = 0.0
        for (x in f) s += x.toDouble() * x
        return sqrt(s / f.size)
    }

    private fun threshold() = max(450.0, noise * 2.2)

    private fun wakeHit(r: Recognizer, f: ShortArray): Boolean {
        val fin = r.acceptWaveForm(f, f.size)
        val j = try { JSONObject(if (fin) r.result else r.partialResult) } catch (e: Exception) { return false }
        val t = if (fin) j.optString("text") else j.optString("partial")
        if (t.contains("आकाश")) {
            hits++
            if (fin || hits >= 2) {
                hits = 0
                r.reset()
                return true
            }
        } else if (!fin) hits = 0
        if (fin) hits = 0
        return false
    }

    private fun capture(initial: List<ShortArray>, maxMs: Int): ShortArray {
        val frames = ArrayList<ShortArray>(initial)
        var silent = 0
        var elapsed = 0
        while (running && elapsed < maxMs) {
            val f = readFrame() ?: continue
            frames.add(f)
            elapsed += 20
            if (rms(f) > threshold()) silent = 0 else silent += 20
            if (silent >= 1800) break
        }
        val out = ShortArray(frames.sumOf { it.size })
        var p = 0
        for (f in frames) {
            System.arraycopy(f, 0, out, p, f.size)
            p += f.size
        }
        return out
    }

    private fun waitForSpeech(ms: Int): List<ShortArray>? {
        val pre = java.util.ArrayDeque<ShortArray>()
        var elapsed = 0
        var run = 0
        while (running && elapsed < ms) {
            val f = readFrame() ?: continue
            elapsed += 20
            pre.addLast(f)
            while (pre.size > 15) pre.removeFirst()
            if (rms(f) > threshold()) {
                run++
                if (run >= 3) return pre.toList()
            } else run = 0
        }
        return null
    }

    // ---------- speech to text ----------
    private fun transcribe(pcm: ShortArray): String {
        if (pcm.size < RATE / 2) return ""
        try {
            val r = JSONObject(svc.httpPost("/api/stt", toWav(pcm), "audio/wav"))
            if (!r.has("error")) return r.optString("text")
        } catch (e: Exception) {
            Log.w("AKASH", "online STT failed, using offline", e)
        }
        return offlineDecode(pcm)
    }

    private fun offlineDecode(pcm: ShortArray): String {
        val m = model ?: return ""
        val rc = Recognizer(m, RATE.toFloat())
        try {
            var i = 0
            while (i < pcm.size) {
                val n = minOf(4000, pcm.size - i)
                rc.acceptWaveForm(pcm.copyOfRange(i, i + n), n)
                i += n
            }
            return JSONObject(rc.finalResult).optString("text")
        } finally {
            rc.close()
        }
    }

    private fun toWav(pcm: ShortArray): ByteArray {
        val len = pcm.size * 2
        val bb = ByteBuffer.allocate(44 + len).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + len); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1); bb.putInt(RATE); bb.putInt(RATE * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(len)
        for (s in pcm) bb.putShort(s)
        return bb.array()
    }

    companion object {
        private const val RATE = 16000
        private const val FRAME = 320
        private val WAKE = Regex("^(?:हे\\s*|hey\\s+|ok\\s+)?(?:आकाश|आकश|आकाष|akash|aakash)[\\s,.:!।-]*", RegexOption.IGNORE_CASE)

        fun modelAvailable(ctx: android.content.Context): Boolean = try {
            !ctx.assets.list("vosk-model").isNullOrEmpty()
        } catch (e: Exception) {
            false
        }
    }
}
