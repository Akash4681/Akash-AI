package com.akash.ai

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/** Phone actions called from Python tools (jclass("com.akash.ai.PhoneBridge")). Every method returns a JSON string. */
object PhoneBridge {
    private lateinit var ctx: Context

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun ok(m: String) = JSONObject().put("ok", true).put("message", m).toString()
    private fun fail(m: String) = JSONObject().put("ok", false).put("error", m).toString()

    /** Indian numbers without a country code get +91. */
    fun normalize(raw: String): String {
        val s = raw.filter { it.isDigit() || it == '+' }
        return when {
            s.startsWith("+") -> s
            s.length == 10 -> "+91$s"
            s.length == 11 && s.startsWith("0") -> "+91" + s.drop(1)
            s.length == 12 && s.startsWith("91") -> "+$s"
            else -> s
        }
    }

    @JvmStatic
    fun findContact(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return fail("संपर्क पढ़ने की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        val out = JSONArray()
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { c ->
            val seen = HashSet<String>()
            while (c.moveToNext() && out.length() < 6) {
                val n = c.getString(0) ?: continue
                val num = normalize(c.getString(1) ?: continue)
                if (seen.add("$n|$num")) out.put(JSONObject().put("name", n).put("number", num))
            }
        }
        return if (out.length() == 0) fail("'$name' नाम का कोई संपर्क नहीं मिला")
        else JSONObject().put("ok", true).put("contacts", out).toString()
    }

    @Suppress("DEPRECATION")
    @JvmStatic
    fun sendSms(number: String, text: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return fail("SMS भेजने की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        return try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(normalize(number), null, sm.divideMessage(text), null, null)
            ok("SMS भेज दिया")
        } catch (e: Exception) {
            fail("SMS नहीं गया: ${e.message}")
        }
    }

    @JvmStatic
    fun call(number: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return fail("कॉल की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        return try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(Uri.fromParts("tel", normalize(number), null), Bundle())
            ok("कॉल लगा रहा हूँ")
        } catch (e: Exception) {
            fail("कॉल नहीं लगी: ${e.message}")
        }
    }

    private fun waPackage(): String? = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
        try {
            ctx.packageManager.getPackageInfo(it, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Opens the WhatsApp chat. Returns an error text, or null on success. */
    private fun openWhatsapp(number: String, text: String?): String? {
        val pkg = waPackage() ?: return "WhatsApp इंस्टॉल नहीं है"
        if (!AkashAccessibility.enabled(ctx)) return "Accessibility सेवा चालू नहीं है (Settings → फ़ोन की अनुमतियाँ → Accessibility)"
        val digits = normalize(number).removePrefix("+")
        val url = "https://wa.me/$digits" + if (text != null) "?text=" + Uri.encode(text) else ""
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) {
            "WhatsApp नहीं खुल पाया: ${e.message}"
        }
    }

    private const val HELP = "जाँचो: Accessibility चालू है, ‘दूसरे ऐप के ऊपर दिखाओ’ की अनुमति है, और नंबर सही है।"

    @JvmStatic
    fun whatsappMessage(number: String, text: String): String {
        AkashAccessibility.begin("send")
        openWhatsapp(number, text)?.let { AkashAccessibility.cancel(); return fail(it) }
        return if (AkashAccessibility.await(15000)) ok("WhatsApp पर भेज दिया") else fail("WhatsApp में Send बटन नहीं मिला। $HELP")
    }

    @JvmStatic
    fun whatsappCall(number: String, video: Boolean): String {
        AkashAccessibility.begin(if (video) "vcall" else "call")
        openWhatsapp(number, null)?.let { AkashAccessibility.cancel(); return fail(it) }
        return if (AkashAccessibility.await(20000)) ok("WhatsApp कॉल लगा रहा हूँ") else fail("WhatsApp में कॉल का बटन नहीं मिला। $HELP")
    }

    @JvmStatic
    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase().trim()
        fun label(i: android.content.pm.ResolveInfo) = i.loadLabel(pm).toString().lowercase()
        val hit = apps.firstOrNull { label(it) == q }
            ?: apps.firstOrNull { label(it).contains(q) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(q) }
            ?: return fail("'$name' नाम का ऐप नहीं मिला")
        return try {
            ctx.startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(hit.activityInfo.packageName, hit.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            ok("${hit.loadLabel(pm)} खोल दिया")
        } catch (e: Exception) {
            fail("ऐप नहीं खुला: ${e.message}")
        }
    }
}
