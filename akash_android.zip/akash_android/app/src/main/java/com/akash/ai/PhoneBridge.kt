package com.akash.ai

import android.Manifest
import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.LocationManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

/** Phone actions called from Python tools (jclass("com.akash.ai.PhoneBridge")). Every method returns a JSON string. */
object PhoneBridge {
    private lateinit var ctx: Context

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private fun ok(m: String) = JSONObject().put("ok", true).put("message", m).toString()
    private fun fail(m: String) = JSONObject().put("ok", false).put("error", m).toString()

    /** Indian numbers without a country code get +91. */
    fun normalize(raw: String): String {
        val s = raw.filter { it.isDigit() || it == '+' }
        return when {
            s.startsWith("+") -> s
            s.length == 10 -> "+91$s"
            s.length == 11 && s.startsWith("0") -> "+91" + s.drop(1)
            s.length == 12 && s.startsWith("91") -> "+$s"
            else -> s
        }
    }

    @JvmStatic
    fun findContact(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return fail("संपर्क पढ़ने की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        val out = JSONArray()
        ctx.contentResolver.query(
            Phone.CONTENT_URI,
            arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { c ->
            val seen = HashSet<String>()
            while (c.moveToNext() && out.length() < 6) {
                val n = c.getString(0) ?: continue
                val num = normalize(c.getString(1) ?: continue)
                if (seen.add("$n|$num")) out.put(JSONObject().put("name", n).put("number", num))
            }
        }
        return if (out.length() == 0) fail("'$name' नाम का कोई संपर्क नहीं मिला")
        else JSONObject().put("ok", true).put("contacts", out).toString()
    }

    @Suppress("DEPRECATION")
    @JvmStatic
    fun sendSms(number: String, text: String): String {
        if (!has(Manifest.permission.SEND_SMS)) return fail("SMS भेजने की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        return try {
            val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
            sm.sendMultipartTextMessage(normalize(number), null, sm.divideMessage(text), null, null)
            ok("SMS भेज दिया")
        } catch (e: Exception) {
            fail("SMS नहीं गया: ${e.message}")
        }
    }

    @JvmStatic
    fun call(number: String): String {
        if (!has(Manifest.permission.CALL_PHONE)) return fail("कॉल की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        return try {
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.placeCall(Uri.fromParts("tel", normalize(number), null), Bundle())
            ok("कॉल लगा रहा हूँ")
        } catch (e: Exception) {
            fail("कॉल नहीं लगी: ${e.message}")
        }
    }

    private fun waPackage(): String? = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
        try {
            ctx.packageManager.getPackageInfo(it, 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Opens the WhatsApp chat. Returns an error text, or null on success. */
    private fun openWhatsapp(number: String, text: String?): String? {
        val pkg = waPackage() ?: return "WhatsApp इंस्टॉल नहीं है"
        if (!AkashAccessibility.enabled(ctx)) return "Accessibility सेवा चालू नहीं है (Settings → फ़ोन की अनुमतियाँ → Accessibility)"
        val digits = normalize(number).removePrefix("+")
        val url = "https://wa.me/$digits" + if (text != null) "?text=" + Uri.encode(text) else ""
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            null
        } catch (e: Exception) {
            "WhatsApp नहीं खुल पाया: ${e.message}"
        }
    }

    private const val HELP = "जाँचो: Accessibility चालू है, ‘दूसरे ऐप के ऊपर दिखाओ’ की अनुमति है, और नंबर सही है।"

    @JvmStatic
    fun whatsappMessage(number: String, text: String): String {
        AkashAccessibility.begin("send")
        openWhatsapp(number, text)?.let { AkashAccessibility.cancel(); return fail(it) }
        return if (AkashAccessibility.await(15000)) ok("WhatsApp पर भेज दिया") else fail("WhatsApp में Send बटन नहीं मिला। $HELP")
    }

    @JvmStatic
    fun whatsappCall(number: String, video: Boolean): String {
        AkashAccessibility.begin(if (video) "vcall" else "call")
        openWhatsapp(number, null)?.let { AkashAccessibility.cancel(); return fail(it) }
        return if (AkashAccessibility.await(20000)) ok("WhatsApp कॉल लगा रहा हूँ") else fail("WhatsApp में कॉल का बटन नहीं मिला। $HELP")
    }

    @JvmStatic
    fun openApp(name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val q = name.lowercase().trim()
        fun label(i: android.content.pm.ResolveInfo) = i.loadLabel(pm).toString().lowercase()
        val hit = apps.firstOrNull { label(it) == q }
            ?: apps.firstOrNull { label(it).contains(q) }
            ?: apps.firstOrNull { it.activityInfo.packageName.lowercase().contains(q) }
            ?: return fail("'$name' नाम का ऐप नहीं मिला")
        return try {
            ctx.startActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(hit.activityInfo.packageName, hit.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            ok("${hit.loadLabel(pm)} खोल दिया")
        } catch (e: Exception) {
            fail("ऐप नहीं खुला: ${e.message}")
        }
    }

    // ------------------------------------------------------------------ more phone powers
    @JvmStatic
    fun context(): Context = ctx

    private const val A11Y_OFF = "Accessibility सेवा चालू नहीं है (Settings → फ़ोन की अनुमतियाँ → Accessibility)"

    private fun start(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    @JvmStatic
    fun setAlarm(hour: Int, minute: Int, label: String): String = try {
        start(
            Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        ok("अलार्म ${hour}:${"%02d".format(minute)} पर लगा दिया")
    } catch (e: Exception) {
        fail("अलार्म नहीं लगा: ${e.message}")
    }

    @JvmStatic
    fun setTimer(seconds: Int, label: String): String = try {
        start(
            Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        )
        ok("टाइमर $seconds सेकंड का चालू")
    } catch (e: Exception) {
        fail("टाइमर नहीं लगा: ${e.message}")
    }

    @JvmStatic
    fun playMusic(query: String): String = try {
        start(
            Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                .putExtra(SearchManager.QUERY, query)
        )
        ok("‘$query’ चलाने को कहा")
    } catch (e: Exception) {
        fail("कोई म्यूज़िक ऐप नहीं खुला: ${e.message}")
    }

    @JvmStatic
    fun mediaKey(action: String): String = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (action) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        ok("हो गया: $action")
    } catch (e: Exception) {
        fail("मीडिया बटन नहीं दबा: ${e.message}")
    }

    @JvmStatic
    fun navigate(place: String): String = try {
        try {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))).setPackage("com.google.android.apps.maps"))
        } catch (e: Exception) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
        }
        ok("$place का रास्ता खोल दिया")
    } catch (e: Exception) {
        fail("रास्ता नहीं खुला: ${e.message}")
    }

    @JvmStatic
    fun flashlight(on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) fail("इस फ़ोन में टॉर्च नहीं मिली") else {
            cm.setTorchMode(id, on)
            ok(if (on) "टॉर्च चालू" else "टॉर्च बंद")
        }
    } catch (e: Exception) {
        fail("टॉर्च नहीं चली: ${e.message}")
    }

    @JvmStatic
    fun setVolume(percent: Int): String = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, percent.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI)
        ok("आवाज़ $percent% कर दी")
    } catch (e: Exception) {
        fail("आवाज़ नहीं बदली: ${e.message}")
    }

    @SuppressLint("MissingPermission")
    @JvmStatic
    fun location(): String {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION)) return fail("लोकेशन की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        return try {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val best = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
                .mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
            if (best == null) fail("लोकेशन अभी नहीं मिली (GPS चालू करके एक बार Maps खोलो)")
            else JSONObject().put("ok", true).put("lat", best.latitude).put("lon", best.longitude).put("accuracy_m", best.accuracy)
                .put("age_minutes", (System.currentTimeMillis() - best.time) / 60000).toString()
        } catch (e: Exception) {
            fail("लोकेशन नहीं मिली: ${e.message}")
        }
    }

    @JvmStatic
    fun addEvent(title: String, start: Long, end: Long): String {
        if (!has(Manifest.permission.WRITE_CALENDAR) || !has(Manifest.permission.READ_CALENDAR)) return fail("कैलेंडर की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        return try {
            var calId = -1L
            ctx.contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI, arrayOf(CalendarContract.Calendars._ID),
                "${CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL} >= ? AND ${CalendarContract.Calendars.VISIBLE} = 1", arrayOf("500"), null
            )?.use { if (it.moveToFirst()) calId = it.getLong(0) }
            if (calId < 0) return fail("कोई लिखने लायक कैलेंडर नहीं मिला")
            val v = ContentValues().apply {
                put(CalendarContract.Events.DTSTART, start)
                put(CalendarContract.Events.DTEND, end)
                put(CalendarContract.Events.TITLE, title)
                put(CalendarContract.Events.CALENDAR_ID, calId)
                put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id)
            }
            ctx.contentResolver.insert(CalendarContract.Events.CONTENT_URI, v)
            ok("कैलेंडर में ‘$title’ जोड़ दिया")
        } catch (e: Exception) {
            fail("कैलेंडर में नहीं जुड़ा: ${e.message}")
        }
    }

    @JvmStatic
    fun notifications(limit: Int): String {
        if (!AkashNotifications.enabled(ctx)) return fail("नोटिफ़िकेशन पढ़ने की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ → नोटिफ़िकेशन)")
        return JSONObject().put("ok", true).put("notifications", AkashNotifications.latest(limit)).toString()
    }

    @JvmStatic
    fun setNotifySpeak(on: Boolean): String {
        AkashNotifications.speak = on
        ctx.getSharedPreferences("akash", Context.MODE_PRIVATE).edit().putBoolean("notify", on).apply()
        return ok(if (on) "नोटिफ़िकेशन अब बोलकर सुनाऊँगा" else "नोटिफ़िकेशन बोलना बंद")
    }

    // ---- screen control through the Accessibility service (works in any app)
    @JvmStatic
    fun screenRead(): String = AkashAccessibility.instance?.let { JSONObject().put("ok", true).put("screen", it.readScreen()).toString() } ?: fail(A11Y_OFF)

    @JvmStatic
    fun screenTap(text: String): String = AkashAccessibility.instance?.let { if (it.tapText(text)) ok("‘$text’ दबा दिया") else fail("‘$text’ स्क्रीन पर नहीं मिला") } ?: fail(A11Y_OFF)

    @JvmStatic
    fun screenType(text: String): String = AkashAccessibility.instance?.let { if (it.typeText(text)) ok("लिख दिया") else fail("लिखने की जगह नहीं मिली; पहले उस खाने को दबाओ") } ?: fail(A11Y_OFF)

    @JvmStatic
    fun screenPress(key: String): String = AkashAccessibility.instance?.let { if (it.press(key)) ok("दबा दिया: $key") else fail("यह बटन नहीं दबा: $key") } ?: fail(A11Y_OFF)

    @JvmStatic
    fun screenScroll(direction: String): String = AkashAccessibility.instance?.let { if (it.scroll(direction)) ok("स्क्रॉल किया") else fail("स्क्रॉल होने वाली चीज़ नहीं मिली") } ?: fail(A11Y_OFF)

    // ---- camera: one photo, no preview (works while the app is on screen; Android blocks camera in the background)
    private fun downscale(b: ByteArray): ByteArray {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var s = 1
        while (o.outWidth / s > 1280) s *= 2
        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return b
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return out.toByteArray()
    }

    @Suppress("DEPRECATION")
    @JvmStatic
    fun capturePhoto(front: Boolean): String {
        if (!has(Manifest.permission.CAMERA)) return fail("कैमरे की अनुमति नहीं है (Settings → फ़ोन की अनुमतियाँ)")
        var cam: android.hardware.Camera? = null
        return try {
            val info = android.hardware.Camera.CameraInfo()
            val want = if (front) android.hardware.Camera.CameraInfo.CAMERA_FACING_FRONT else android.hardware.Camera.CameraInfo.CAMERA_FACING_BACK
            var idx = -1
            for (i in 0 until android.hardware.Camera.getNumberOfCameras()) {
                android.hardware.Camera.getCameraInfo(i, info)
                if (info.facing == want) { idx = i; break }
            }
            if (idx < 0) return fail("ऐसा कैमरा नहीं मिला")
            cam = android.hardware.Camera.open(idx)
            val prm = cam.parameters
            prm.setRotation(if (front) 270 else 90)
            cam.parameters = prm
            cam.setPreviewTexture(SurfaceTexture(0))
            cam.startPreview()
            Thread.sleep(900)
            val latch = CountDownLatch(1)
            var data: ByteArray? = null
            cam.takePicture(null, null) { d, _ -> data = d; latch.countDown() }
            latch.await(6, TimeUnit.SECONDS)
            val bytes = data ?: return fail("फ़ोटो नहीं आई")
            val f = File(ctx.cacheDir, "look.jpg")
            f.writeBytes(downscale(bytes))
            JSONObject().put("ok", true).put("path", f.absolutePath).toString()
        } catch (e: Exception) {
            fail("कैमरा नहीं खुला (पीछे से कैमरा Android रोकता है; ऐप खोलकर बोलो): ${e.message}")
        } finally {
            try { cam?.release() } catch (_: Exception) {}
        }
    }

    // ---- speaking / sleeping
    private var fallbackTts: TextToSpeech? = null
    private var fallbackReady = false
    private var pendingSpeech: String? = null

    @JvmStatic
    fun speak(text: String): String {
        val svc = AkashService.instance
        if (svc != null) {
            svc.speakAsync(text)
            return ok("बोल दिया")
        }
        pendingSpeech = text
        if (fallbackTts == null) {
            fallbackTts = TextToSpeech(ctx) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    fallbackTts?.language = Locale("hi", "IN")
                    fallbackReady = true
                    pendingSpeech?.let { fallbackTts?.speak(it, TextToSpeech.QUEUE_ADD, null, "p") }
                }
            }
        } else if (fallbackReady) {
            fallbackTts?.speak(text, TextToSpeech.QUEUE_ADD, null, "p")
        }
        return ok("बोल दिया")
    }

    /** "सो जाओ": stop the always-on mic, after a short delay so the last answer can still be spoken. */
    @JvmStatic
    fun stopListening(): String {
        Handler(Looper.getMainLooper()).postDelayed({ ctx.stopService(Intent(ctx, AkashService::class.java)) }, 6000)
        return ok("ठीक है, 6 सेकंड में सुनना बंद। दोबारा चालू करने के लिए ऐप खोलकर माइक दबाओ।")
    }
}
