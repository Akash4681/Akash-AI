package com.akash.ai

import android.app.Application

class AkashApp : Application() {
    override fun onCreate() {
        super.onCreate()
        PhoneBridge.init(this)
        AkashNotifications.speak = getSharedPreferences("akash", MODE_PRIVATE).getBoolean("notify", false)
    }
}
