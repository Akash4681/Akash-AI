package com.akash.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Presses WhatsApp's Send / Call buttons, but only while AKASH has an open request
 * (begin() ... finish()) and only inside WhatsApp's own window.
 */
class AkashAccessibility : AccessibilityService() {

    class Pending(var phase: String, val deadline: Long, var confirmBy: Long = 0)

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val st = state ?: return
        if (System.currentTimeMillis() > st.deadline) {
            finish(false)
            return
        }
        if (e?.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val root = rootInActiveWindow ?: return
        try {
            step(root, st)
        } catch (_: Exception) {
        }
    }

    private fun step(root: AccessibilityNodeInfo, st: Pending) {
        when (st.phase) {
            "send" -> {
                val n = byId(root, "send") ?: byLabel(root, SEND)
                if (n != null && click(n)) finish(true)
            }
            "call", "vcall" -> {
                val n = byLabel(root, if (st.phase == "vcall") VCALL else CALL)
                if (n != null && click(n)) {
                    st.phase = "confirm"
                    st.confirmBy = System.currentTimeMillis() + 4000
                }
            }
            "confirm" -> {
                val n = byLabel(root, CONFIRM)
                if (n != null && click(n)) finish(true)
                else if (System.currentTimeMillis() > st.confirmBy) finish(true)
            }
        }
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            depth++
        }
        return false
    }

    private fun byId(root: AccessibilityNodeInfo, id: String): AccessibilityNodeInfo? {
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")?.firstOrNull()?.let { return it }
        }
        return null
    }

    private fun byLabel(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            val d = n.contentDescription?.toString()
            val t = n.text?.toString()
            if ((d != null && labels.any { it.equals(d, true) }) || (t != null && labels.any { it.equals(t, true) })) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return null
    }

    companion object {
        @Volatile var instance: AkashAccessibility? = null
        @Volatile private var state: Pending? = null
        @Volatile private var latch = CountDownLatch(0)
        @Volatile private var success = false

        private val SEND = listOf("Send", "भेजें", "भेजे")
        private val CALL = listOf("Voice call", "Audio call", "वॉइस कॉल", "ऑडियो कॉल")
        private val VCALL = listOf("Video call", "वीडियो कॉल")
        private val CONFIRM = listOf("Call", "CALL", "Voice call", "Video call", "कॉल", "कॉल करें")

        fun begin(kind: String) {
            success = false
            latch = CountDownLatch(1)
            state = Pending(kind, System.currentTimeMillis() + 25000)
        }

        fun cancel() {
            state = null
            latch.countDown()
        }

        fun finish(ok: Boolean) {
            success = ok
            state = null
            latch.countDown()
        }

        /** Waits for the button press. A call whose confirm step was reached counts as success. */
        fun await(ms: Long): Boolean {
            latch.await(ms, TimeUnit.MILLISECONDS)
            val ok = success || state?.phase == "confirm"
            state = null
            return ok
        }

        fun enabled(ctx: Context): Boolean {
            if (instance != null) return true
            val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            return s?.contains(ctx.packageName + "/") == true
        }
    }
}
