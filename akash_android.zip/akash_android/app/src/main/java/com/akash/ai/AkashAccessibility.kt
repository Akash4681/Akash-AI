package com.akash.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Presses WhatsApp's Send / Call buttons, but only while AKASH has an open request
 * (begin() ... finish()) and only inside WhatsApp's own window.
 */
class AkashAccessibility : AccessibilityService() {

    class Pending(var phase: String, val deadline: Long, var confirmBy: Long = 0)

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val st = state ?: return
        if (System.currentTimeMillis() > st.deadline) {
            finish(false)
            return
        }
        if (e?.packageName?.toString()?.startsWith("com.whatsapp") != true) return
        val root = rootInActiveWindow ?: return
        try {
            step(root, st)
        } catch (_: Exception) {
        }
    }

    private fun step(root: AccessibilityNodeInfo, st: Pending) {
        when (st.phase) {
            "send" -> {
                val n = byId(root, "send") ?: byLabel(root, SEND)
                if (n != null && click(n)) finish(true)
            }
            "call", "vcall" -> {
                val n = byLabel(root, if (st.phase == "vcall") VCALL else CALL)
                if (n != null && click(n)) {
                    st.phase = "confirm"
                    st.confirmBy = System.currentTimeMillis() + 4000
                }
            }
            "confirm" -> {
                val n = byLabel(root, CONFIRM)
                if (n != null && click(n)) finish(true)
                else if (System.currentTimeMillis() > st.confirmBy) finish(true)
            }
        }
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 4) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            depth++
        }
        return false
    }

    private fun byId(root: AccessibilityNodeInfo, id: String): AccessibilityNodeInfo? {
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            root.findAccessibilityNodeInfosByViewId("$pkg:id/$id")?.firstOrNull()?.let { return it }
        }
        return null
    }

    private fun byLabel(root: AccessibilityNodeInfo, labels: List<String>): AccessibilityNodeInfo? {
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeLast()
            val d = n.contentDescription?.toString()
            val t = n.text?.toString()
            if ((d != null && labels.any { it.equals(d, true) }) || (t != null && labels.any { it.equals(t, true) })) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return null
    }


    // ---- generic screen control (any app) used by the screen_* tools
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(स्क्रीन पढ़ नहीं पाया)"
        val sb = StringBuilder("ऐप: ${root.packageName}\n")
        var n = 0
        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (n > 150 || depth > 25) return
            val label = node.text?.toString() ?: node.contentDescription?.toString()
            if (!label.isNullOrBlank()) {
                n++
                sb.append("- ").append(label.take(80))
                if (node.isEditable) sb.append("  [लिखने की जगह]") else if (node.isClickable) sb.append("  [टैप]")
                sb.append('\n')
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { walk(it, depth + 1) }
        }
        walk(root, 0)
        return sb.toString()
    }

    private fun findContaining(root: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val q = text.lowercase()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeFirst()
            val t = n.text?.toString()?.lowercase()
            val d = n.contentDescription?.toString()?.lowercase()
            if ((t != null && t.contains(q)) || (d != null && d.contains(q))) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return null
    }

    /** Finds the first result card (it has views / duration in its description) and taps it. */
    private fun tapFirstVideo(): Boolean {
        val root = rootInActiveWindow ?: return false
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        val hint = Regex("views|view|मिनट|minutes?|seconds?|सेकंड|ago|पहले|व्यू", RegexOption.IGNORE_CASE)
        while (stack.isNotEmpty()) {
            val n = stack.removeFirst()
            val d = n.contentDescription?.toString() ?: n.text?.toString()
            if (d != null && hint.containsMatchIn(d) && d.length > 12) {
                var cur: AccessibilityNodeInfo? = n
                var depth = 0
                while (cur != null && depth < 5) {
                    if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    cur = cur.parent
                    depth++
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return false
    }

    /** Waits for the results page to load, then taps the first video. Tries a few times. */
    fun autoPlayFirstVideo(firstDelayMs: Long) {
        val h = android.os.Handler(android.os.Looper.getMainLooper())
        var tries = 0
        fun attempt() {
            tries++
            if (!tapFirstVideo() && tries < 4) h.postDelayed({ attempt() }, 1500)
        }
        h.postDelayed({ attempt() }, firstDelayMs)
    }

    fun tapText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = findContaining(root, text) ?: return false
        return click(n)
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        var node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) {
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(root)
            while (stack.isNotEmpty() && node == null) {
                val n = stack.removeFirst()
                if (n.isEditable) node = n
                for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
            }
        }
        val target = node ?: return false
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun press(key: String): Boolean = performGlobalAction(
        when (key) {
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> GLOBAL_ACTION_BACK
        }
    )

    fun scroll(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val n = stack.removeFirst()
            if (n.isScrollable) {
                return n.performAction(if (direction == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.add(it) }
        }
        return false
    }

    companion object {
        @Volatile var instance: AkashAccessibility? = null
        @Volatile private var state: Pending? = null
        @Volatile private var latch = CountDownLatch(0)
        @Volatile private var success = false

        private val SEND = listOf("Send", "भेजें", "भेजे")
        private val CALL = listOf("Voice call", "Audio call", "वॉइस कॉल", "ऑडियो कॉल")
        private val VCALL = listOf("Video call", "वीडियो कॉल")
        private val CONFIRM = listOf("Call", "CALL", "Voice call", "Video call", "कॉल", "कॉल करें")

        fun begin(kind: String) {
            success = false
            latch = CountDownLatch(1)
            state = Pending(kind, System.currentTimeMillis() + 25000)
        }

        fun cancel() {
            state = null
            latch.countDown()
        }

        fun finish(ok: Boolean) {
            success = ok
            state = null
            latch.countDown()
        }

        /** Waits for the button press. A call whose confirm step was reached counts as success. */
        fun await(ms: Long): Boolean {
            latch.await(ms, TimeUnit.MILLISECONDS)
            val ok = success || state?.phase == "confirm"
            state = null
            return ok
        }

        fun enabled(ctx: Context): Boolean {
            if (instance != null) return true
            val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            return s?.contains(ctx.packageName + "/") == true
        }
    }
}
