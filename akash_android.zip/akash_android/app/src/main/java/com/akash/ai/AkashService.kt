package com.akash.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Always-on listener (foreground service). Hears "हे आकाश <command>", sends the command to the
 * local AKASH server, and speaks the answer. Phone actions happen inside the server's tools.
 */
class AkashService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wake: PowerManager.WakeLock? = null
    @Volatile private var running = false
    @Volatile private var busy = false
    private var awaiting = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        createChannel()
        ServiceCompat.startForeground(this, 1, notif("सुन रहा हूँ — बोलो “हे आकाश”"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        running = true
        listening = true
        ServerHost.start(this)
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "akash:listen").apply { acquire() }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) = afterSpeech()
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) = afterSpeech()
                })
                ttsReady = true
            }
        }
        listenSoon(1500)
    }

    override fun onDestroy() {
        running = false
        listening = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        tts?.shutdown()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ---------- listening ----------
    private fun listenSoon(ms: Long) {
        if (running) main.postDelayed({ startListen() }, ms)
    }

    private fun startListen() {
        if (!running || busy) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotif("Speech सेवा नहीं मिली (Google ऐप चाहिए)")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        recognizer?.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) listenSoon(300) else handle(t)
        }

        override fun onError(error: Int) {
            val quick = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            listenSoon(if (quick) 300 else 2500)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ---------- understanding ----------
    private fun handle(t: String) {
        if (awaiting) {
            awaiting = false
            runCommand(t)
            return
        }
        if (WAKE.find(t) == null) {
            listenSoon(300)
            return
        }
        val cmd = t.replace(WAKE, "").trim()
        if (cmd.length > 1) runCommand(cmd) else {
            awaiting = true
            say("जी, बोलिए")
        }
    }

    private fun runCommand(cmd: String) {
        busy = true
        updateNotif("सोच रहा हूँ…")
        Thread {
            var answer = "कुछ गड़बड़ हुई, दोबारा बोलो।"
            try {
                answer = ask(cmd)
            } catch (e: Exception) {
                Log.e("AKASH", "ask failed", e)
            }
            main.post { say(answer) }
        }.start()
    }

    private fun ask(cmd: String): String {
        var n = 0
        while (!ServerHost.isUp() && n < 40) {
            Thread.sleep(500)
            n++
        }
        val id = JSONObject(http("POST", "/api/chat/start", JSONObject().put("message", cmd).toString())).getString("id")
        repeat(240) {
            val j = JSONObject(http("GET", "/api/job/$id", null))
            if (j.getString("status") != "running") return j.getString("answer")
            Thread.sleep(600)
        }
        return "बहुत देर लग गई।"
    }

    private fun http(method: String, path: String, body: String?): String {
        val c = URL("http://127.0.0.1:${ServerHost.PORT}$path").openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 3000
        c.readTimeout = 70000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // ---------- speaking ----------
    private fun say(text: String) {
        busy = true
        updateNotif("बोल रहा हूँ…")
        val clean = text.replace(Regex("```[\\s\\S]*?```"), " कोड देख लो। ")
            .replace(Regex("https?://\\S+"), "").replace(Regex("[*#_`]"), "").take(400)
        if (!ttsReady || clean.isBlank()) {
            afterSpeech()
            return
        }
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "akash")
    }

    private fun afterSpeech() {
        busy = false
        updateNotif("सुन रहा हूँ — बोलो “हे आकाश”")
        listenSoon(500)
    }

    // ---------- notification ----------
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("akash", "AKASH", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notif(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AkashService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "akash")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AKASH AI")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "बंद करो", stop)
            .setOngoing(true)
            .build()
    }

    private fun updateNotif(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(text))
    }

    companion object {
        @Volatile var listening = false
        const val ACTION_STOP = "com.akash.ai.STOP"
        private val WAKE = Regex("(?:हे\\s*|hey\\s+|ok\\s+)?(?:आकाश|आकश|आकाष|akash|aakash)[\\s,.:!।-]*", RegexOption.IGNORE_CASE)
    }
}
