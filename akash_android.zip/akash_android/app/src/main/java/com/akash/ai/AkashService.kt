package com.akash.ai

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/**
 * Always-on listener (foreground service). Preferred: VoiceEngine (silent, offline wake word).
 * Fallback when the Vosk model is missing: Android SpeechRecognizer loop (may beep).
 */
class AkashService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wake: PowerManager.WakeLock? = null
    private var engine: VoiceEngine? = null
    @Volatile private var engineMode = false
    @Volatile private var running = false
    @Volatile private var busy = false
    @Volatile private var speaking = false
    private var awaiting = false
    private var restarts = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return
        }
        createChannel()
        ServiceCompat.startForeground(this, 1, notif("सुन रहा हूँ — बोलो “आकाश”"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        instance = this
        running = true
        listening = true
        ServerHost.start(this)
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "akash:listen").apply { acquire() }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {
                        speaking = true
                    }

                    override fun onDone(id: String?) {
                        speaking = false
                        if (!engineMode && id == "akash") afterSpeech()
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        speaking = false
                        if (!engineMode && id == "akash") afterSpeech()
                    }

                    override fun onStop(id: String?, interrupted: Boolean) {
                        speaking = false
                    }
                })
                ttsReady = true
            }
        }
        if (VoiceEngine.modelAvailable(this)) startEngine() else startLegacy()
    }

    override fun onDestroy() {
        running = false
        listening = false
        instance = null
        main.removeCallbacksAndMessages(null)
        engine?.stop()
        recognizer?.destroy()
        tts?.shutdown()
        wake?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    // ---------- engine control ----------
    private fun startEngine() {
        engineMode = true
        engine = VoiceEngine(this).also { it.start() }
    }

    /** Called by the engine thread if it crashed: restart it (a few times). */
    fun engineDied() {
        if (!running) return
        restarts++
        if (restarts > 8) {
            main.post { startLegacy() }
            return
        }
        main.postDelayed({ if (running) startEngine() }, 3000)
    }

    /** Called when the offline model is not in the app: use the old recogniser. */
    fun engineUnavailable() {
        main.post { startLegacy() }
    }

    private fun startLegacy() {
        engineMode = false
        engine?.stop()
        engine = null
        listenSoon(1500)
    }

    // ---------- used by VoiceEngine / PhoneBridge ----------
    fun isSpeaking(): Boolean = speaking

    private fun speakable(text: String): String =
        text.replace(Regex("```[\\s\\S]*?```"), " कोड स्क्रीन पर है। ")
            .replace(Regex("https?://\\S+"), "").replace(Regex("[*#_`]"), "")
            .replace("आकाश", "मैं").replace("AKASH", "मैं").replace("Akash", "मैं").take(400)

    fun startSpeak(text: String) {
        val clean = speakable(text)
        if (!ttsReady || clean.isBlank()) {
            speaking = false
            return
        }
        speaking = true
        if (tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "engine") != TextToSpeech.SUCCESS) speaking = false
    }

    fun stopSpeak() {
        tts?.stop()
        speaking = false
    }

    fun speakAsync(text: String) {
        val clean = speakable(text)
        if (ttsReady && clean.isNotBlank()) {
            speaking = true
            if (tts?.speak(clean, TextToSpeech.QUEUE_ADD, null, "ext") != TextToSpeech.SUCCESS) speaking = false
        }
    }

    fun state(s: String) {
        updateNotif(
            when (s) {
                "listening" -> "सुन रहा हूँ…"
                "thinking" -> "सोच रहा हूँ…"
                "speaking" -> "बोल रहा हूँ…"
                else -> "तैयार — बोलो “आकाश”"
            }
        )
        Thread { try { httpPost("/api/voice_state", JSONObject().put("state", s).toString().toByteArray(), "application/json") } catch (_: Exception) {} }.start()
    }

    fun ask(cmd: String): String {
        try {
            var n = 0
            while (!ServerHost.isUp() && n < 40) {
                Thread.sleep(500)
                n++
            }
            val body = JSONObject().put("message", cmd).put("source", "voice").toString()
            val id = JSONObject(httpPost("/api/chat/start", body.toByteArray(), "application/json")).getString("id")
            repeat(300) {
                val j = JSONObject(httpGet("/api/job/$id"))
                if (j.getString("status") != "running") return j.getString("answer")
                Thread.sleep(600)
            }
            return "बहुत देर लग गई।"
        } catch (e: Exception) {
            Log.e("AKASH", "ask failed", e)
            return "कुछ गड़बड़ हुई, दोबारा बोलो।"
        }
    }

    fun httpPost(path: String, body: ByteArray, contentType: String): String {
        val c = URL("http://127.0.0.1:${ServerHost.PORT}$path").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 3000
        c.readTimeout = 70000
        c.doOutput = true
        c.setRequestProperty("Content-Type", contentType)
        c.outputStream.use { it.write(body) }
        return (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
    }

    private fun httpGet(path: String): String {
        val c = URL("http://127.0.0.1:${ServerHost.PORT}$path").openConnection() as HttpURLConnection
        c.connectTimeout = 3000
        c.readTimeout = 70000
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // ---------- legacy listening (only when the offline model is missing) ----------
    private fun listenSoon(ms: Long) {
        if (running && !engineMode) main.postDelayed({ startListen() }, ms)
    }

    private fun startListen() {
        if (!running || busy || engineMode) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotif("Speech सेवा नहीं मिली (Google ऐप चाहिए)")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(listener) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        recognizer?.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (t.isNullOrBlank()) listenSoon(300) else handle(t)
        }

        override fun onError(error: Int) {
            val quick = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
            listenSoon(if (quick) 300 else 2500)
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handle(t: String) {
        if (awaiting) {
            awaiting = false
            runCommand(t)
            return
        }
        if (LEGACY_WAKE.find(t) == null) {
            listenSoon(300)
            return
        }
        val cmd = t.replace(LEGACY_WAKE, "").trim()
        if (cmd.length > 1) runCommand(cmd) else {
            awaiting = true
            say("जी, बोलिए")
        }
    }

    private fun runCommand(cmd: String) {
        busy = true
        updateNotif("सोच रहा हूँ…")
        Thread {
            val answer = ask(cmd)
            main.post { say(answer) }
        }.start()
    }

    private fun say(text: String) {
        busy = true
        val clean = speakable(text)
        if (!ttsReady || clean.isBlank()) {
            afterSpeech()
            return
        }
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "akash")
    }

    private fun afterSpeech() {
        busy = false
        updateNotif("सुन रहा हूँ — बोलो “आकाश”")
        listenSoon(500)
    }

    // ---------- notification ----------
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("akash", "AKASH", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notif(text: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, AkashService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "akash")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AKASH AI")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "बंद करो", stop)
            .setOngoing(true)
            .build()
    }

    private fun updateNotif(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(text))
    }

    companion object {
        @Volatile var listening = false
        @Volatile var instance: AkashService? = null
        const val ACTION_STOP = "com.akash.ai.STOP"
        private val LEGACY_WAKE = Regex("(?:हे\\s*|hey\\s+|ok\\s+)?(?:आकाश|आकश|आकाष|akash|aakash)[\\s,.:!।-]*", RegexOption.IGNORE_CASE)
    }
}
