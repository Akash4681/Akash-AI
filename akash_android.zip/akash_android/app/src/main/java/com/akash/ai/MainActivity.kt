package com.akash.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#050817")
        window.navigationBarColor = Color.parseColor("#050817")
        web = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#050817"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = object : WebChromeClient() {
                override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setMessage(message)
                        .setPositiveButton("हाँ") { _, _ -> result.confirm() }
                        .setNegativeButton("नहीं") { _, _ -> result.cancel() }
                        .setOnCancelListener { result.cancel() }
                        .show()
                    return true
                }
            }
            webViewClient = WebViewClient()
            addJavascriptInterface(Native(), "AkashNative")
        }
        setContentView(web)
        web.loadDataWithBaseURL(
            null,
            "<body style='background:#050817;color:#8fa0cc;font-family:sans-serif;text-align:center;padding-top:40vh'>AKASH शुरू हो रहा है…</body>",
            "text/html", "UTF-8", null
        )
        ServerHost.start(this)
        askBasicPermissions()
        Thread {
            var n = 0
            while (!ServerHost.isUp() && n < 120) {
                Thread.sleep(500)
                n++
            }
            runOnUiThread { web.loadUrl("http://127.0.0.1:${ServerHost.PORT}/") }
        }.start()
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun askBasicPermissions() {
        val need = mutableListOf<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
        else if (!AkashService.listening) startListeningService()
    }

    private fun startListeningService() {
        if (granted(Manifest.permission.RECORD_AUDIO)) ContextCompat.startForegroundService(this, Intent(this, AkashService::class.java))
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && granted(Manifest.permission.RECORD_AUDIO) && !AkashService.listening) startListeningService()
        refreshSoon()
    }

    private fun refreshSoon() {
        web.postDelayed({ web.evaluateJavascript("window.akashNativeRefresh&&akashNativeRefresh()", null) }, 900)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) refreshSoon()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else moveTaskToBack(true)
    }

    /** Exposed to the web page as window.AkashNative. */
    inner class Native {
        @JavascriptInterface
        fun status(): String {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            return JSONObject()
                .put("mic", granted(Manifest.permission.RECORD_AUDIO))
                .put("sms", granted(Manifest.permission.SEND_SMS))
                .put("call", granted(Manifest.permission.CALL_PHONE))
                .put("contacts", granted(Manifest.permission.READ_CONTACTS))
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("a11y", AkashAccessibility.enabled(this@MainActivity))
                .put("battery", pm.isIgnoringBatteryOptimizations(packageName))
                .put("listening", AkashService.listening)
                .toString()
        }

        @JavascriptInterface
        fun toggleListening() {
            runOnUiThread {
                if (AkashService.listening) stopService(Intent(this@MainActivity, AkashService::class.java))
                else if (granted(Manifest.permission.RECORD_AUDIO)) startListeningService()
                else askBasicPermissions()
                refreshSoon()
            }
        }

        @JavascriptInterface
        fun grant(kind: String) {
            runOnUiThread {
                when (kind) {
                    "mic" -> askBasicPermissions()
                    "phone" -> requestPermissions(
                        arrayOf(Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS), 2
                    )
                    "overlay" -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    "a11y" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    "battery" -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                }
            }
        }
    }
}
