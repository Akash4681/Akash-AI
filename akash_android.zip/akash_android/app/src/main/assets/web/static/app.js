"use strict";
const $ = id => document.getElementById(id);
const TOOL_LABEL = {web_search: "वेब सर्च", remember: "मेमोरी", add_task: "टास्क", list_tasks: "टास्क", calculate: "हिसाब", get_time: "समय",
  propose_change: "सुधार प्रस्ताव", list_files: "फाइलें", read_file: "फाइलें", write_file: "फाइलें"};
const AST = {waiting: "इंतज़ार में", working: "काम कर रहा है…", done: "पूरा ✓", error: "गड़बड़ ✗"};
let SET = {voice_reply: true}, busy = false, view = "home", lastSeen = "";
const NATIVE = typeof window.AkashNative !== "undefined";

/* ---------- helpers ---------- */
function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
function toast(msg) { const t = $("toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), 3200); }
async function api(path, opts) {
  const r = await fetch(path, opts); let d = null; try { d = await r.json(); } catch (_) {}
  if (!r.ok) throw new Error((d && (d.error || d.message)) || ("Error " + r.status));
  return d;
}
const post = (p, b) => api(p, {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(b || {})});
const sleep = ms => new Promise(r => setTimeout(r, ms));
function btn(label, cls, fn) { const b = el("button", cls || "mini", label); b.type = "button"; b.addEventListener("click", fn); return b; }
function listItem(text, meta, actions) {
  const li = el("li", "item"), box = el("div", "item-text"); box.append(el("span", "", text)); if (meta) box.append(el("small", "", meta));
  li.append(box); (actions || []).forEach(a => li.append(a)); return li;
}
const avatar = id => "/static/agents/" + id + ".jpg";

/* ---------- navigation ---------- */
function showView(name, anchor) {
  view = name;
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.dataset.view === name));
  document.querySelectorAll(".pill").forEach(p => p.classList.toggle("active", p.dataset.go === name && (name !== "home" || (p.dataset.anchor || "top") === (anchor || "top"))));
  $("side").classList.remove("open"); $("scrim").classList.remove("show");
  if (name === "memory") loadMemory();
  if (name === "tasks") loadTasks();
  if (name === "skills") loadSkills();
  if (name === "tools") loadTools();
  if (name === "settings") loadSettings();
  const SHEETS = ["pCode", "pSelf", "pStatus", "pMem"];
  if (name === "home" && anchor && SHEETS.includes(anchor) && window.matchMedia("(max-width:979px)").matches) { openSheet(anchor); return; }
  setTimeout(() => { if (anchor && anchor !== "top") $(anchor).scrollIntoView({behavior: "smooth", block: "start"}); else window.scrollTo({top: 0, behavior: "smooth"}); }, 30);
}
document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => showView(b.dataset.go, b.dataset.anchor)));
$("menuBtn").addEventListener("click", () => { $("side").classList.add("open"); $("scrim").classList.add("show"); });
$("scrim").addEventListener("click", () => { $("side").classList.remove("open"); $("scrim").classList.remove("show"); });

/* ---------- system status ---------- */
const RINGS = [["cpu", "CPU", "#4d8dff"], ["ram", "RAM", "#4df0b0"], ["storage", "Storage", "#ffc24d"], ["net", "Network", "#52e5ff"]];
const hist = [];
function buildRings() {
  $("rings").replaceChildren(...RINGS.map(([k, label, c]) => { const d = el("div"), r = el("div", "ring"); r.id = "ring_" + k; r.style.setProperty("--c", c); r.append(el("span", "", "—")); d.append(r, el("b", "", label)); return d; }));
}
function setRing(k, pct, text) { const r = $("ring_" + k); if (!r) return; r.style.setProperty("--p", pct == null ? 0 : pct); r.firstChild.textContent = text; }
function drawSpark() {
  const pts = hist.map((v, i) => (i / Math.max(1, hist.length - 1) * 200).toFixed(1) + "," + (48 - v / 100 * 44).toFixed(1)).join(" ");
  $("spark").innerHTML = hist.length > 1 ? `<polyline points="${pts}" fill="none" stroke="#4da3ff" stroke-width="1.6" vector-effect="non-scaling-stroke"/>` : "";
}
async function refreshMetrics() {
  if (document.hidden || view !== "home") return;
  try {
    const m = await api("/api/metrics");
    setRing("cpu", m.cpu, m.cpu == null ? "—" : m.cpu + "%"); setRing("ram", m.ram, m.ram == null ? "—" : m.ram + "%");
    setRing("storage", m.storage, m.storage + "%");
    setRing("net", m.online ? Math.max(8, 100 - (m.net_ms || 0) / 4) : 0, m.online ? (m.net_ms || 0) + "ms" : "Off");
    const v = m.cpu != null ? m.cpu : m.ram; if (v != null) { hist.push(v); if (hist.length > 40) hist.shift(); drawSpark(); }
    $("onlineDot").className = m.online ? "on" : ""; $("onlineTxt").textContent = m.online ? "Online" : "Offline";
    $("miniStat").textContent = "CPU " + (m.cpu == null ? "—" : m.cpu + "%") + " · RAM " + (m.ram == null ? "—" : m.ram + "%") + " · Net " + (m.online ? (m.net_ms || 0) + "ms" : "Off");
    $("healthTxt").textContent = m.online ? "Healthy" : "Offline"; $("healthTxt").className = m.online ? "ok" : "";
  } catch (_) { $("onlineTxt").textContent = "Server बंद"; $("onlineDot").className = ""; }
}
async function refreshStatus() {
  try {
    const s = await api("/api/status");
    $("modePill").textContent = s.mode + (s.mode === "AI API" ? " · " + s.model : "");
    const b = $("taskBadge"); b.textContent = s.tasks; b.hidden = !s.tasks;
    $("codeState").textContent = s.code_run ? "Ready" : "Locked"; $("codeState").className = s.code_run ? "ok" : "muted";
    const k = s.kinds || {}, pct = Math.min(100, Math.round(s.memories / 200 * 100));
    const ring = $("memRing"); ring.style.setProperty("--p", pct); ring.style.setProperty("--c", "#4df0b0"); ring.replaceChildren(el("span", "", pct + "%"));
    $("memLegend").replaceChildren(...[["Past Chats", s.messages], ["Preferences", k.preference || 0], ["Projects", k.project || 0], ["Knowledge", (k.note || 0) + (k.fact || 0)]].map(([n, v]) => el("li", "", n + " (" + v + ")")));
    loadProposals(); loadBackups(); loadPlugins();
  } catch (_) { $("modePill").textContent = "ऑफ़लाइन"; }
}

/* ---------- chat + live agents ---------- */
const messages = $("messages"), input = $("messageInput");
function addBubble(kind, title, text, tools) {
  const d = el("div", "bubble " + kind); d.append(el("b", "", title), el("p", "", text));
  if (tools && tools.length) d.append(el("small", "tools", "🔧 " + tools.map(x => TOOL_LABEL[x] || x).join(" · ")));
  messages.appendChild(d); messages.scrollTop = messages.scrollHeight;
}
function nodeEl(img, icon, name, state, note) {
  const n = el("div", "node " + (state || "")), i = el("i");
  if (img) { const im = el("img"); im.src = img; im.alt = ""; im.style.cssText = "width:100%;height:100%;border-radius:50%;object-fit:cover"; i.append(im); } else i.textContent = icon;
  n.append(i, el("b", "", name)); if (note) n.append(el("small", "", note)); return n;
}
function renderFlow(container, nodes) {
  const out = []; nodes.forEach((n, i) => { if (i) out.push(el("span", "arrow", "→")); out.push(n); }); container.replaceChildren(...out);
}
function idleFlow() {
  renderFlow($("flow"), [nodeEl(null, "👤", "Your Request"), nodeEl(avatar("research"), "", "Research"), nodeEl(avatar("content"), "", "Content"), nodeEl(avatar("media"), "", "Media"), nodeEl(null, "✔", "Result")]);
  $("flowState").textContent = "तैयार";
}
function renderJob(j) {
  const live = j.steps.find(s => s.status === "working");
  $("coreStatus").textContent = live ? live.name + " काम कर रहा है…" : (j.status === "done" ? "जवाब तैयार है — अगला सवाल पूछो" : "टीम तैयार हो रही है…");
  $("agentsLive").textContent = live ? "काम चालू" : "सब तैयार";
  document.querySelectorAll(".agent").forEach(c => { c.className = "agent"; c.querySelector(".ast").textContent = "आराम में"; });
  j.steps.forEach(s => { const c = document.querySelector(`.agent[data-agent="${s.agent}"]`); if (c) { c.className = "agent " + s.status; c.querySelector(".ast").textContent = AST[s.status] || ""; } });
  const nodes = [nodeEl(null, "👤", "Your Request", "done")];
  j.steps.forEach(s => nodes.push(nodeEl(avatar(s.agent), "", s.name.replace(" Agent", ""), s.status, s.note)));
  nodes.push(nodeEl(null, "✔", "Result", j.status === "done" && !j.steps.some(s => s.status === "error") ? "done" : ""));
  renderFlow($("flow"), nodes);
  $("flowState").textContent = live ? "चल रहा है" : (j.status === "done" ? "पूरा" : "शुरू");
  drawLinks(j.steps.filter(s => s.status === "working" || s.status === "done").map(s => [s.agent, s.status]));
}
async function pollJob(id, onUpdate) {
  for (let i = 0; i < 300; i++) {
    const j = await api("/api/job/" + id); onUpdate(j);
    if (j.status !== "running") return j; await sleep(600);
  }
  throw new Error("बहुत देर लग गई, दोबारा कोशिश करो");
}
function resetAgents() {
  document.querySelectorAll(".agent").forEach(c => { c.className = "agent"; c.querySelector(".ast").textContent = "आराम में"; });
  $("agentsLive").textContent = "सब तैयार"; $("coreStatus").textContent = "तुम्हारे निर्देश का इंतज़ार है"; clearLinks();
}
async function send(text) {
  text = (text || "").trim(); if (!text || busy) return; busy = true; setOrb("thinking");
  addBubble("user", "तुम", text); input.value = ""; input.style.height = "";
  document.querySelector(".orbbox").classList.add("busy"); $("coreStatus").textContent = "काम शुरू हो रहा है…";
  try {
    const {id} = await post("/api/chat/start", {message: text}); lastSeen = id;
    const j = await pollJob(id, renderJob);
    addBubble("assistant", "AKASH", j.answer, j.tools); speak(j.answer);
    if (j.tools.some(t => ["add_task", "remember"].includes(t))) { loadTasks(); loadMemory(); }
    if (j.tools.some(t => ["modify_own_code", "restore_backup"].includes(t))) { toast("कोड बदला। स्क्रीन के बदलाव देखने के लिए पेज दोबारा खोलो; app.py बदली हो तो Shutdown करके ऐप फिर खोलो।"); loadBackups(); }
  } catch (e) { addBubble("assistant", "AKASH", "गड़बड़: " + e.message); }
  finally { busy = false; setOrb("idle"); clearLinks(); document.querySelector(".orbbox").classList.remove("busy"); setTimeout(resetAgents, 2500); refreshStatus(); loadActions(); }
}
$("chatForm").addEventListener("submit", e => { e.preventDefault(); send(input.value); });
input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input.value); } });
input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 110) + "px"; });
document.querySelectorAll(".agent").forEach(c => c.addEventListener("click", () => {
  if (view !== "home") showView("home", "pVoice");
  input.value = c.dataset.name + " (" + c.dataset.task + "): "; input.focus(); $("pVoice").scrollIntoView({behavior: "smooth", block: "center"});
}));

/* ---------- voice (Chrome Web Speech API) ---------- */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null, vmode = null, awaiting = false, muted = false, userStopped = false;
const WAKE = /(?:हे\s*|हे\s+|hey\s+|ok\s+)?(?:आकाश|आकश|आकाष|akash|aakash)[\s,.:!।-]*/i;
function uiVoice(on) {
  $("micBtn").classList.toggle("live", on); $("micTop").classList.toggle("live", on); $("wave").classList.toggle("on", on);
  $("micLabel").textContent = on ? (vmode === "wake" ? "सुन रहा हूँ — “हे आकाश” बोलो" : "बोलो… मैं सुन रहा हूँ") : "बात करने के लिए टैप करो";
  $("bgBtn").classList.toggle("active", on && vmode === "wake"); $("bgState").textContent = on && vmode === "wake" ? "सक्रिय" : "बंद";
  $("wakeTxt").classList.toggle("on", on && vmode === "wake"); $("voiceState").textContent = on ? "Listening" : "Online";
}
function stopVoice() { userStopped = true; if (rec) { try { rec.abort(); } catch (_) {} } rec = null; vmode = null; awaiting = false; uiVoice(false); }
function startVoice(mode) {
  if (!SR) { toast("इस ब्राउज़र में माइक नहीं चलता। Chrome इस्तेमाल करो।"); return; }
  if (rec) stopVoice();
  userStopped = false; vmode = mode; awaiting = false;
  const r = new SR(); r.lang = "hi-IN"; r.continuous = mode === "wake"; r.interimResults = false;
  r.onresult = e => { for (let i = e.resultIndex; i < e.results.length; i++) if (e.results[i].isFinal) heard(e.results[i][0].transcript.trim()); };
  r.onerror = e => { if (e.error === "not-allowed" || e.error === "service-not-allowed") { toast("माइक की अनुमति दो (Chrome → साइट सेटिंग)"); stopVoice(); } };
  r.onend = () => { if (vmode === "wake" && !userStopped) { setTimeout(() => { try { r.start(); } catch (_) {} }, 300); } else if (!userStopped) { vmode = null; uiVoice(false); } };
  rec = r; try { r.start(); uiVoice(true); } catch (e) { toast("माइक शुरू नहीं हुआ"); }
}
function heard(t) {
  if (!t || muted || busy) return;
  if (vmode === "once") { stopVoice(); send(t); return; }
  if (awaiting) { awaiting = false; send(t); return; }
  const m = t.match(WAKE);
  if (!m) { $("coreStatus").textContent = "सुना, पर “हे आकाश” नहीं बोला — इसलिए छोड़ दिया"; return; }
  const cmd = t.replace(WAKE, "").trim();
  if (cmd.length > 1) send(cmd); else { awaiting = true; $("coreStatus").textContent = "जी, बोलिए…"; speak("जी, बोलिए", true); }
}
function speak(text, force) {
  if (!("speechSynthesis" in window) || (SET.voice_reply === false && !force)) return;
  const clean = text.replace(/```[\s\S]*?```/g, " कोड देख लो। ").replace(/https?:\/\/\S+/g, "").replace(/[*#_`]/g, "").slice(0, 400);
  if (!clean.trim()) return;
  const u = new SpeechSynthesisUtterance(clean); u.lang = "hi-IN"; u.rate = 1;
  u.onstart = () => { muted = true; }; u.onend = u.onerror = () => { setTimeout(() => { muted = false; }, 400); };
  window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
}
$("micBtn").addEventListener("click", () => NATIVE ? nativeToggle() : (rec ? stopVoice() : startVoice("once")));
$("stopVoiceBtn").addEventListener("click", () => { stopVoice(); window.speechSynthesis && window.speechSynthesis.cancel(); });
const toggleWake = () => NATIVE ? nativeToggle() : (rec && vmode === "wake" ? stopVoice() : startVoice("wake"));
$("micTop").addEventListener("click", toggleWake); $("bgBtn").addEventListener("click", toggleWake);
$("voiceModeBtn").addEventListener("click", () => { showView("home", "pVoice"); toggleWake(); });

/* ---------- coding studio ---------- */
async function loadFiles() {
  try {
    const f = await api("/api/files"), sel = $("fileSel"), cur = sel.value;
    sel.replaceChildren(new Option("— नई फाइल —", ""), ...f.map(n => new Option(n, n))); sel.value = f.includes(cur) ? cur : "";
  } catch (_) {}
}
$("fileSel").addEventListener("change", async e => {
  if (!e.target.value) { $("fileName").value = ""; return; }
  try { const d = await api("/api/files/" + encodeURIComponent(e.target.value)); $("codeEditor").value = d.content; $("fileName").value = d.name; } catch (er) { toast(er.message); }
});
$("saveBtn").addEventListener("click", async () => {
  const name = $("fileName").value.trim(); if (!name) { toast("पहले फाइल का नाम लिखो, जैसे video.py"); return; }
  try { await post("/api/files", {name, content: $("codeEditor").value}); toast("सेव हो गया ✅"); await loadFiles(); $("fileSel").value = name; } catch (e) { toast(e.message); }
});
$("runBtn").addEventListener("click", async () => {
  const out = $("codeOut"), b = $("runBtn"); b.disabled = true; $("codeState").textContent = "Running…"; out.className = "out"; out.textContent = "चल रहा है…";
  try {
    const r = await post("/api/run", {code: $("codeEditor").value});
    out.className = "out" + (r.code ? " err" : ""); out.textContent = (r.stdout || "") + (r.stderr || "") || "(कोई आउटपुट नहीं)";
  } catch (e) { out.className = "out err"; out.textContent = e.message; }
  finally { b.disabled = false; refreshStatus(); }
});
$("codeEditor").addEventListener("keydown", e => {
  if (e.key === "Tab") { e.preventDefault(); const t = e.target, s = t.selectionStart; t.value = t.value.slice(0, s) + "    " + t.value.slice(t.selectionEnd); t.selectionStart = t.selectionEnd = s + 4; }
});

/* ---------- self-development ---------- */
const SELF_ICONS = {Analyze: "📊", Test: "🧪", Improve: "⚙", "Ask Approval": "🛡"};
function idleSelf() { renderFlow($("selfFlow"), ["Analyze", "Test", "Improve", "Ask Approval"].map(n => nodeEl(null, SELF_ICONS[n], n))); }
$("selfRun").addEventListener("click", async () => {
  const b = $("selfRun"); if (b.disabled) return; b.disabled = true; b.textContent = "सुधार चक्र चल रहा है…";
  try {
    const {id} = await post("/api/selfdev/run");
    await pollJob(id, j => renderFlow($("selfFlow"), j.steps.map(s => nodeEl(null, SELF_ICONS[s.name], s.name, s.status, s.note))));
    toast("प्रस्ताव तैयार — नीचे मंज़ूर या नामंज़ूर करो");
  } catch (e) { toast(e.message); }
  finally { b.disabled = false; b.textContent = "Request Approval — सुधार चक्र चलाओ"; loadProposals(); refreshStatus(); }
});
const PSTAT = {pending: "⏳ इंतज़ार", approved: "✔ मंज़ूर", rejected: "✖ नामंज़ूर"};
async function loadProposals() {
  try {
    const rows = await api("/api/proposals"), ul = $("propList");
    if (!rows.length) { ul.replaceChildren(el("li", "empty", "अभी कोई प्रस्ताव नहीं।")); return; }
    ul.replaceChildren(...rows.slice(0, 5).map(p => {
      const acts = p.status === "pending" ? [
        btn("✔ लागू करो", "mini ok", async () => { await post("/api/proposals/" + p.id + "/approve"); loadProposals(); showView("home", "pVoice"); send("Self-Development: यह सुधार मंज़ूर है, इसे अपने कोड में लागू करो (बैकअप के साथ) — " + p.title + ": " + p.detail); }),
        btn("✖", "mini danger", async () => { await post("/api/proposals/" + p.id + "/reject"); loadProposals(); refreshStatus(); })] : [];
      return listItem(p.title + (p.detail ? " — " + p.detail : ""), PSTAT[p.status] || p.status, acts);
    }));
  } catch (_) {}
}

/* ---------- memory / tasks / skills / tools ---------- */
const KIND = {note: "नोट", preference: "पसंद", fact: "तथ्य", project: "प्रोजेक्ट"};
async function loadMemory() {
  try {
    const rows = await api("/api/memory"), ul = $("memList");
    if (!rows.length) { ul.replaceChildren(el("li", "empty", "अभी कुछ सेव नहीं है।")); return; }
    ul.replaceChildren(...rows.map(m => listItem(m.text, (KIND[m.kind] || m.kind) + " · " + m.ts.replace("T", " "),
      [btn("🗑", "mini danger", async () => { await api("/api/memory/" + m.id, {method: "DELETE"}); loadMemory(); refreshStatus(); })])));
  } catch (e) { toast(e.message); }
}
$("memForm").addEventListener("submit", async e => {
  e.preventDefault(); const t = $("memInput").value.trim(); if (!t) return;
  try { await post("/api/memory", {text: t, kind: $("memKind").value}); $("memInput").value = ""; loadMemory(); refreshStatus(); } catch (er) { toast(er.message); }
});
async function loadTasks() {
  try {
    const rows = await api("/api/tasks"), ul = $("taskList");
    if (!rows.length) { ul.replaceChildren(el("li", "empty", "कोई काम नहीं।")); return; }
    ul.replaceChildren(...rows.map(t => {
      const li = listItem(t.title, t.done ? "पूरा" : "बाकी", [btn(t.done ? "↩" : "✔", "mini", async () => { await api("/api/tasks/" + t.id + "/toggle", {method: "POST"}); loadTasks(); refreshStatus(); })]);
      if (t.done) li.classList.add("done"); return li;
    }));
  } catch (e) { toast(e.message); }
}
$("taskForm").addEventListener("submit", async e => {
  e.preventDefault(); const t = $("taskInput").value.trim(); if (!t) return;
  try { await post("/api/tasks", {title: t}); $("taskInput").value = ""; loadTasks(); refreshStatus(); } catch (er) { toast(er.message); }
});
function runSkill(prompt) { showView("home", "pVoice"); $("sheet").hidden = true; send(prompt); }
async function loadSkills() {
  try {
    const rows = await api("/api/skills"), ul = $("skillList");
    ul.replaceChildren(...rows.map(s => listItem(s.name, s.prompt, [btn("▶", "mini ok", () => runSkill(s.prompt)),
      btn("🗑", "mini danger", async () => { await api("/api/skills/" + s.id, {method: "DELETE"}); loadSkills(); })])));
  } catch (e) { toast(e.message); }
}
$("skillForm").addEventListener("submit", async e => {
  e.preventDefault(); try { await post("/api/skills", {name: $("skillName").value, prompt: $("skillPrompt").value}); $("skillName").value = $("skillPrompt").value = ""; loadSkills(); } catch (er) { toast(er.message); }
});
async function loadTools() {
  try { const rows = await api("/api/tools"); $("toolList").replaceChildren(...rows.map(t => listItem(t.name + (t.label ? " · " + t.label : ""), t.desc + " — " + t.agents.join(", ")))); } catch (e) { toast(e.message); }
}

/* ---------- settings (API key lives here) ---------- */
async function loadSettings() {
  try {
    const s = await api("/api/settings"); SET = s;
    $("keyState").textContent = s.api_key_set ? "चालू " + s.api_key_hint : "जुड़ी नहीं"; $("keyState").className = s.api_key_set ? "ok" : "muted";
    $("setVoice").checked = s.voice_reply;
    $("provList").replaceChildren(...(s.providers || []).map(p => listItem(p.provider.toUpperCase() + "  " + p.hint, "मॉडल: " + p.model)));
    $("keyState").textContent = s.providers && s.providers.length ? s.providers.length + " चाबी ✅" : "जुड़ी नहीं"; $("keyState").className = s.providers && s.providers.length ? "ok" : "muted"; $("setName").value = s.assistant_name || "";  applyName(s.assistant_name); $("setMulti").checked = s.multi_agent; $("setAsk").checked = s.ask_before_send; $("setNotify").checked = !!s.read_notifications; $("setStt").value = s.stt_model || ""; $("setVision").value = s.vision_model || ""; if (NATIVE) loadPerms();

    $("setTav").placeholder = s.tavily_set ? "पहले से जुड़ी है" : "tvly-… (वैकल्पिक)";
  } catch (e) { $("setMsg").textContent = e.message; }
}
document.querySelectorAll(".chip").forEach(c => c.addEventListener("click", () => {
  document.querySelectorAll(".chip").forEach(x => x.classList.toggle("on", x === c)); $("setBase").value = c.dataset.base; $("setModel").value = c.dataset.model;
}));
const formVals = () => ({api_keys: $("setKeys").value, tavily_key: $("setTav").value, voice_reply: $("setVoice").checked, assistant_name: $("setName").value.trim(), multi_agent: $("setMulti").checked, ask_before_send: $("setAsk").checked, read_notifications: $("setNotify").checked, stt_model: $("setStt").value, vision_model: $("setVision").value});
$("saveSet").addEventListener("click", async () => {
  try { await post("/api/settings", formVals()); $("setKeys").value = $("setTav").value = ""; $("setMsg").textContent = "सेव हो गया ✅"; await loadSettings(); refreshStatus(); } catch (e) { $("setMsg").textContent = e.message; }
});
$("testSet").addEventListener("click", async () => {
  $("setMsg").textContent = "सब चाबियाँ जाँच रहा हूँ…";
  try {
    const r = await post("/api/settings/verify", {api_keys: $("setKeys").value});
    $("setMsg").textContent = (r.results || []).map(x => (x.ok ? "✅ " + x.provider.toUpperCase() + " — " + x.model : "❌ " + x.provider.toUpperCase() + " — " + x.message)).join("\n") + "\n" + r.message;
    await loadSettings(); refreshStatus();
  } catch (e) { $("setMsg").textContent = e.message; }
});

/* ---------- bottom bar: quick actions, power, shutdown ---------- */
$("quickBtn").addEventListener("click", async () => {
  const body = $("sheetBody"); body.replaceChildren();
  try { (await api("/api/skills")).forEach(s => body.append(btn("▶ " + s.name, "btn", () => runSkill(s.prompt)))); } catch (_) {}
  body.append(btn("🧹 चैट साफ़ करो", "btn", async () => { await api("/api/history", {method: "DELETE"}); messages.replaceChildren(); addBubble("assistant", "AKASH", "चैट साफ़ हो गई।"); $("sheet").hidden = true; refreshStatus(); }));
  body.append(btn("🛡 सुधार चक्र चलाओ", "btn", () => { $("sheet").hidden = true; showView("home", "pSelf"); setTimeout(() => $("selfRun").click(), 400); }));
  $("sheet").hidden = false;
});
$("sheetClose").addEventListener("click", () => { $("sheet").hidden = true; });
$("powerBtn").addEventListener("click", () => { stopVoice(); window.speechSynthesis && window.speechSynthesis.cancel(); $("sleep").hidden = false; });
$("sleep").addEventListener("click", () => { $("sleep").hidden = true; });
$("shutBtn").addEventListener("click", async () => {
  if (!confirm("AKASH बंद करें? (ऐप दोबारा Pydroid से चलाना होगा)")) return;
  try { await post("/api/shutdown"); $("sleepTxt").textContent = "AKASH बंद हो गया। दोबारा चलाने के लिए Pydroid में app.py Run करो।"; $("sleep").hidden = false; stopVoice(); }
  catch (e) { toast(e.message); }
});

/* ---------- boot ---------- */
(async function boot() {
  buildRings(); idleFlow(); idleSelf(); loadFiles(); refreshStatus(); refreshMetrics(); loadSettings(); loadActions(); if (NATIVE) { nativeUI(); loadPerms(); }
  try { const l = await api("/api/job/latest"); if (!l.none && l.status !== "running") lastSeen = l.id; } catch (_) {}
  setInterval(refreshMetrics, 4000);
  try {
    const h = await api("/api/history");
    if (h.length) { messages.replaceChildren(); h.forEach(m => addBubble(m.role === "user" ? "user" : "assistant", m.role === "user" ? "तुम" : "AKASH", m.content)); }
  } catch (_) {}
})();

/* ---------- phone actions: confirm card ---------- */
async function loadActions() {
  try {
    const rows = await api("/api/actions"), box = $("actionBox");
    box.replaceChildren(...rows.map(a => {
      const d = el("div", "action"); d.append(el("b", "", "⚠ पुष्टि चाहिए"), el("span", "", a.summary));
      const r = el("div", "vrow");
      r.append(btn("✔ हाँ, करो", "btn", async () => { const x = await post("/api/actions/" + a.id + "/confirm"); addBubble("assistant", "AKASH", x.answer, x.tools); loadActions(); }),
               btn("✖ रद्द", "stop", async () => { const x = await post("/api/actions/" + a.id + "/cancel"); addBubble("assistant", "AKASH", x.answer); loadActions(); }));
      d.append(r); return d;
    }));
  } catch (_) {}
}

/* ---------- voice commands given to the Android service show up live here ---------- */
setInterval(async () => {
  if (busy || document.hidden || view !== "home") return;
  try {
    const j = await api("/api/job/latest"); if (j.none) return;
    try { const v = await api("/api/voice_state"); if (j.status !== "running") setOrb(v.state); } catch (_) {}
    if (j.status === "running") { setOrb("thinking"); renderJob(j); document.querySelector(".orbbox").classList.add("busy"); return; }
    if (j.id !== lastSeen) {
      lastSeen = j.id; renderJob(j); document.querySelector(".orbbox").classList.remove("busy");
      addBubble("user", "तुम (आवाज़)", j.message); addBubble("assistant", "AKASH", j.answer, j.tools);
      setTimeout(resetAgents, 2500); refreshStatus(); loadActions();
    }
  } catch (_) {}
}, 1500);

/* ---------- Android app bridge (only when running inside the AKASH APK) ---------- */
function nativeState() { try { return JSON.parse(window.AkashNative.status()); } catch (_) { return {}; } }
function nativeUI() { const on = !!nativeState().listening; vmode = on ? "wake" : null; uiVoice(on); }
function nativeToggle() { window.AkashNative.toggleListening(); setTimeout(() => { nativeUI(); loadPerms(); }, 900); }
window.akashNativeRefresh = () => { nativeUI(); loadPerms(); };
function loadPerms() {
  if (!NATIVE) return; $("nativePanel").hidden = false; const st = nativeState();
  const rows = [["mic", "🎙 माइक (हमेशा सुनने के लिए)", st.mic, "mic"], ["phone", "📞 SMS, कॉल और संपर्क", st.sms && st.call && st.contacts, "phone"],
    ["a11y", "♿ Accessibility (WhatsApp अपने-आप चलाने के लिए)", st.a11y, "a11y"], ["overlay", "🪟 दूसरे ऐप के ऊपर दिखाओ (पीछे से ऐप खोलने के लिए)", st.overlay, "overlay"],
    ["battery", "🔋 बैटरी की रोक हटाओ (बैकग्राउंड में चलता रहे)", st.battery, "battery"],
    ["more", "📷 कैमरा, 📍 लोकेशन, 📅 कैलेंडर", st.camera && st.location && st.calendar, "more"],
    ["notif", "🔔 नोटिफ़िकेशन पढ़ने की अनुमति", st.notif, "notif"]];
  const items = rows.map(([k, label, ok, g]) => listItem(label, ok ? "✅ हो चुका" : "⏳ बाकी", ok ? [] : [btn("दो", "mini ok", () => window.AkashNative.grant(g))]));
  items.push(listItem("🎧 “हे आकाश” सुनना", st.listening ? "चालू — नोटिफ़िकेशन में दिखता है" : "बंद", [btn(st.listening ? "बंद करो" : "चालू करो", "mini", nativeToggle)]));
  $("permList").replaceChildren(...items);
}

/* ---------- code backups (self-development safety net) ---------- */
async function loadBackups() {
  try {
    const rows = await api("/api/backups"), ul = $("bkList");
    if (!rows.length) { ul.replaceChildren(el("li", "empty", "अभी कोई बैकअप नहीं।")); return; }
    ul.replaceChildren(...rows.slice(0, 8).map(b => listItem(b.label, b.ts.replace("T", " ") + " · " + b.files.join(", "), [btn("↩", "mini ok", async () => {
      const r = await post("/api/backups/" + b.id + "/restore");
      toast(r.restart_needed ? "पुराना कोड लग गया। Shutdown करके ऐप फिर खोलो।" : "पुराना कोड लग गया। पेज दोबारा खोल रहा हूँ…");
      loadBackups(); if (!r.restart_needed) setTimeout(() => location.reload(), 1200);
    })])));
  } catch (_) {}
}
$("bkNow").addEventListener("click", async () => { try { await post("/api/backups", {label: "हाथ से लिया बैकअप"}); toast("बैकअप रख लिया ✅"); loadBackups(); } catch (e) { toast(e.message); } });

/* ---------- phone layout: extra panels open as full-screen sheets ---------- */
function openSheet(id) { document.querySelectorAll(".sheet-open").forEach(e => e.classList.remove("sheet-open")); $(id).classList.add("sheet-open"); $(id).scrollTop = 0; if (id === "pCode") loadFiles(); if (id === "pSelf") { loadProposals(); loadBackups(); } if (id === "pStatus") refreshMetrics(); }
document.querySelectorAll(".chips4 button").forEach(b => b.addEventListener("click", () => openSheet(b.dataset.open)));
document.querySelectorAll(".sheet-x").forEach(b => b.addEventListener("click", () => b.closest(".panel").classList.remove("sheet-open")));

/* ---------- orb states + glowing lines from the orb to working agents ---------- */
function setOrb(state) { const b = document.querySelector(".orbbox"); ["idle", "listening", "thinking", "speaking"].forEach(x => b.classList.toggle("st-" + x, x === state)); }
const SVGNS = "http://www.w3.org/2000/svg";
function clearLinks() { $("links").replaceChildren(); }
function drawLinks(list) {
  const svg = $("links"), grid = $("grid"), orb = $("orbwrap"); if (!svg || !grid || !orb) return;
  const g = grid.getBoundingClientRect(), o = orb.getBoundingClientRect(); const x1 = o.left + o.width / 2 - g.left, y1 = o.top + o.height / 2 - g.top;
  svg.setAttribute("viewBox", "0 0 " + g.width + " " + g.height); svg.setAttribute("width", g.width); svg.setAttribute("height", g.height);
  const out = [];
  list.forEach(([id, st]) => {
    const card = document.querySelector('.agent[data-agent="' + id + '"]'); if (!card) return;
    const r = card.getBoundingClientRect(), x2 = r.left + r.width / 2 - g.left, y2 = r.top - g.top + 4, my = (y1 + y2) / 2;
    const p = document.createElementNS(SVGNS, "path");
    p.setAttribute("d", "M" + x1 + "," + y1 + " C" + x1 + "," + my + " " + x2 + "," + my + " " + x2 + "," + y2);
    p.setAttribute("class", "link " + st); out.push(p);
  });
  svg.replaceChildren(...out);
}
window.addEventListener("resize", clearLinks);
async function loadPlugins() {
  try {
    const rows = await api("/api/plugins"), ul = $("plList");
    ul.replaceChildren(...(rows.length ? rows.map(p => listItem(p.name, p.description)) : [el("li", "empty", "अभी कोई नहीं। AKASH से कहो: “तुम ये सीख लो”।")]));
  } catch (_) {}
}

/* ---------- assistant name + Stonic-style mobile tabs ---------- */
function applyName(name) {
  const n = (name || "").trim() || "आकाश";
  $("brandName").textContent = n === "आकाश" ? "AKASH AI" : n + " AI";
  $("wakeTxt").textContent = "कहो “" + n + "” को जगाने के लिए";
}
function setTab(t) {
  document.body.dataset.tab = t;
  document.querySelectorAll(".tabbtn").forEach(b => b.classList.toggle("active", b.dataset.tab === t));
  if (t === "settings") { showView("settings"); return; }
  showView("home");
  window.scrollTo({top: 0, behavior: "smooth"});
}
document.querySelectorAll(".tabbtn").forEach(b => b.addEventListener("click", () => setTab(b.dataset.tab)));
document.body.dataset.tab = "home";

/* ---------- studio home: globe, agent room, headlines, notes, chat tabs ---------- */
const ST = {};
const ROOM_IMG = {};
["research","content","media","coding","productivity","finance","health","files","automation","selfdev"].forEach(id => { const im = new Image(); im.src = "/static/agents/" + id + ".jpg"; ROOM_IMG[id] = im; });
const ROOM_DESK = {research:[40,40],content:[150,40],media:[260,40],coding:[370,40],productivity:[455,40],finance:[40,160],health:[150,160],files:[260,160],automation:[370,160],selfdev:[455,160]};
function drawRoom() {
  const c = $("room"); if (!c || !c.offsetParent) return; const g = c.getContext("2d"); const W = c.width, H = c.height;
  g.fillStyle = "#0a0203"; g.fillRect(0, 0, W, H);
  g.strokeStyle = "rgba(255,60,60,.12)"; g.lineWidth = 1;
  for (let x = 0; x < W; x += 26) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, H); g.stroke(); }
  for (let y = 0; y < H; y += 26) { g.beginPath(); g.moveTo(0, y); g.lineTo(W, y); g.stroke(); }
  g.fillStyle = "rgba(255,60,60,.08)"; g.fillRect(20, 120, W - 40, 6);
  let active = 0, t = Date.now() / 300;
  Object.keys(ROOM_DESK).forEach(id => {
    const [x, y] = ROOM_DESK[id], st = ST[id] || "";
    const working = st === "working"; if (working) active++;
    g.fillStyle = working ? "rgba(255,70,70,.28)" : "rgba(60,10,12,.7)";
    g.strokeStyle = working ? "#ff5b5b" : "rgba(255,60,60,.35)";
    g.fillRect(x, y + 48, 62, 40); g.strokeRect(x, y + 48, 62, 40);
    const im = ROOM_IMG[id];
    if (im && im.complete) g.drawImage(im, x + 6, y, 50, 50);
    if (working) { g.fillStyle = "rgba(255,90,90," + (0.3 + 0.3 * Math.sin(t)) + ")"; g.beginPath(); g.arc(x + 31, y + 25, 34, 0, 6.28); g.fill(); }
    g.fillStyle = "#ffd6d6"; g.font = "9px sans-serif"; g.fillText((st === "done" ? "✓ " : working ? "● " : "") + id.slice(0, 9), x + 3, y + 102);
  });
  const rc = $("roomCount"); if (rc) rc.textContent = active;
}
setInterval(drawRoom, 300);

function drawGlobe() {
  const box = $("globe"); if (!box || !window.THREE) return;
  const w = box.clientWidth || 300, h = box.clientHeight || 200;
  const r = new THREE.WebGLRenderer({antialias: true, alpha: true}); r.setSize(w, h); r.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
  box.replaceChildren(r.domElement);
  const sc = new THREE.Scene(), cam = new THREE.PerspectiveCamera(40, w / h, 0.1, 100); cam.position.z = 3.2;
  const g = new THREE.Group(); sc.add(g);
  g.add(new THREE.Mesh(new THREE.SphereGeometry(1, 40, 40), new THREE.MeshBasicMaterial({color: 0x2a0708})));
  g.add(new THREE.Mesh(new THREE.SphereGeometry(1.01, 24, 24), new THREE.MeshBasicMaterial({color: 0xff3b3b, wireframe: true, transparent: true, opacity: 0.25})));
  const pts = [];
  for (let i = 0; i < 160; i++) { const u = Math.random() * Math.PI * 2, v = Math.acos(2 * Math.random() - 1); pts.push(Math.sin(v) * Math.cos(u), Math.cos(v), Math.sin(v) * Math.sin(u)); }
  const geo = new THREE.BufferGeometry(); geo.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
  g.add(new THREE.Points(geo, new THREE.PointsMaterial({color: 0xff8a2a, size: 0.05})));
  $("satCount").textContent = "160 नोड";
  (function loop() { g.rotation.y += 0.0035; r.render(sc, cam); requestAnimationFrame(loop); })();
}

async function loadNews() {
  try {
    const r = await api("/api/headlines"), ul = $("newsList");
    if (!r.items.length) { ul.replaceChildren(el("li", "empty", "ख़बरें अभी नहीं मिलीं (इंटरनेट जाँचो)")); }
    else ul.replaceChildren(...r.items.map(n => { const a = el("a", "", n.title); a.href = n.url; a.target = "_blank"; a.rel = "noopener"; a.style.cssText = "color:#ffd6d6;text-decoration:none;font-size:12px;line-height:1.4"; const li = el("li", "item"); li.append(a); return li; }));
    $("newsAt").textContent = new Date().toLocaleTimeString("hi-IN", {hour: "2-digit", minute: "2-digit"});
  } catch (_) {}
}

async function loadNotesList() {
  try {
    const rows = await api("/api/memory"), ul = $("notesList");
    ul.replaceChildren(...(rows.length ? rows.slice(0, 30).map(m => listItem(m.text, KIND[m.kind] || m.kind)) : [el("li", "empty", "अभी कोई नोट नहीं।")]));
  } catch (_) {}
}

function setChatTab(t) {
  document.body.dataset.ctab = t;
  document.querySelectorAll(".ctab").forEach(b => b.classList.toggle("active", b.dataset.ctab === t));
  if (t === "notes") loadNotesList();
  if (t === "agent") { renderFlowNow(); }
}
document.querySelectorAll(".ctab").forEach(b => b.addEventListener("click", () => setChatTab(b.dataset.ctab)));
document.body.dataset.ctab = "voice";
function renderFlowNow() { /* the workflow panel already follows the latest job */ }

const _renderJobOrig = renderJob;
renderJob = function (j) {
  (j.steps || []).forEach(s => { ST[s.agent] = s.status; });
  _renderJobOrig(j);
  drawRoom();
};

(function studioBoot() {
  drawGlobe(); loadNews(); setInterval(loadNews, 600000); drawRoom();
})();

/* ---------- theme: red STUDIO or blue NEON ---------- */
function applyTheme(t) { document.body.classList.toggle("theme-blue", t === "blue"); }

$("orbTab").addEventListener("click", () => { $("micTop").click(); });
$("orbTab2").addEventListener("click", () => { $("micTop").click(); });
