"use strict";
/* AKASH extras: pixel Agent Town, tool log, Control Center, themes.
   Loaded after app.js and uses its helpers ($, el, api, post, send, showView, input, addBubble, view). */
(function () {
  const W = 360, H = 510, COLS = 2, CW = 180, RH = 82, TOP = 92;
  const AG = [], STATE = {}, SEEN = new Set(), TLOG = [];
  let running = false, t0 = performance.now(), clearT = null;

  /* ---------- agents + pixel avatars ---------- */
  function pixelate(img, n) {
    const c = document.createElement("canvas"); c.width = c.height = n;
    const x = c.getContext("2d"), s = Math.min(img.width, img.height);
    x.drawImage(img, (img.width - s) / 2, 0, s, s, 0, 0, n, n);
    return c;
  }
  function agents() {
    if (AG.length) return AG;
    document.querySelectorAll(".agent").forEach(c => {
      const o = {id: c.dataset.agent, name: c.dataset.name, task: c.dataset.task, short: c.dataset.agent === "selfdev" ? "Self-Dev" : c.dataset.name.replace(" Agent", ""), pix: null};
      const im = c.querySelector("img");
      if (im) { const i = new Image(); i.onload = () => { try { o.pix = pixelate(i, 16); } catch (_) {} }; i.src = im.src; }
      AG.push(o);
    });
    return AG;
  }

  /* ---------- drawing ---------- */
  function drawDesk(g, a, i, t, accent) {
    const col = i % COLS, row = Math.floor(i / COLS), cx = col * CW + CW / 2, y0 = TOP + row * RH;
    const st = STATE[a.id] || {status: "idle"}, work = st.status === "working", done = st.status === "done";
    g.fillStyle = "#1d2a5c"; g.fillRect(cx - 10, y0 + 30, 20, 12);                       // chair
    const bob = work ? Math.round(Math.sin(t * 10 + i) * 1.5) : 0, ax = cx - 14, ay = y0 + 3 + bob;
    if (a.pix) g.drawImage(a.pix, ax, ay, 28, 28); else { g.fillStyle = "#6c8cff"; g.fillRect(ax, ay, 28, 28); }
    g.lineWidth = 2; g.strokeStyle = work ? accent : done ? "#4df0b0" : "rgba(140,160,220,.5)"; g.strokeRect(ax - 1, ay - 1, 30, 30);
    g.fillStyle = "#5a3d2b"; g.fillRect(cx - 34, y0 + 32, 68, 16);                       // desk
    g.fillStyle = "#7a5439"; g.fillRect(cx - 34, y0 + 32, 68, 3);
    g.fillStyle = "#0a0f22"; g.fillRect(cx - 12, y0 + 22, 24, 13);                        // monitor
    g.fillStyle = work ? (Math.floor(t * 8) % 2 ? accent : "#2b6cff") : done ? "#2fbf8f" : "#1a2450"; g.fillRect(cx - 10, y0 + 24, 20, 8);
    g.textAlign = "center";
    g.font = "bold 9px monospace"; g.fillStyle = work ? "#fff" : "#9fb2e6"; g.fillText(a.short.slice(0, 14), cx, y0 + 60);
    g.font = "9px sans-serif"; g.fillStyle = work ? accent : done ? "#4df0b0" : "#6f80b3";
    g.fillText(work ? (st.tool || "काम कर रहा…") : done ? "पूरा ✓" : st.status === "waiting" ? "इंतज़ार में" : "आराम में", cx, y0 + 72);
    if (work) { g.fillStyle = accent; g.fillText(".".repeat(Math.floor(t * 3) % 4), cx + 30, y0 + 12); }
    else if (!done && Math.floor(t / 2 + i) % 5 === 0) { g.fillStyle = "#6f80b3"; g.fillText("z", cx + 22, y0 + 8); }
  }
  function draw(now) {
    const cv = $("townCv"); if (!cv) return; const g = cv.getContext("2d"); g.imageSmoothingEnabled = false;
    const accent = (getComputedStyle(document.body).getPropertyValue("--cyan") || "#52e5ff").trim() || "#52e5ff", t = (now - t0) / 1000;
    g.fillStyle = "#0b1230"; g.fillRect(0, 0, W, H);
    for (let y = 0; y < H; y += 20) for (let x = 0; x < W; x += 20) if (((x + y) / 20) % 2 === 0) { g.fillStyle = "rgba(255,255,255,.03)"; g.fillRect(x, y, 20, 20); }
    g.fillStyle = "#101b44"; g.fillRect(0, 0, W, 72); g.fillStyle = accent; g.globalAlpha = .5; g.fillRect(0, 70, W, 2); g.globalAlpha = 1;
    const busy = Object.values(STATE).some(s => s.status === "working"), r = 15 + Math.sin(t * (busy ? 6 : 2)) * (busy ? 3 : 1.5);
    const gr = g.createRadialGradient(W / 2, 32, 2, W / 2, 32, r + 14); gr.addColorStop(0, "#fff"); gr.addColorStop(.35, accent); gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr; g.beginPath(); g.arc(W / 2, 32, r + 14, 0, 7); g.fill();
    g.textAlign = "center"; g.font = "bold 10px monospace"; g.fillStyle = "#cfe3ff"; g.fillText("AKASH CORE", W / 2, 66);
    g.textAlign = "left"; g.font = "9px sans-serif"; g.fillStyle = busy ? accent : "#6f80b3"; g.fillText(busy ? "● काम चालू" : "● सब तैयार", 10, 16);
    agents().forEach((a, i) => drawDesk(g, a, i, t, accent));
  }
  function loop(now) {
    if (view !== "town") { running = false; return; }
    draw(now); requestAnimationFrame(loop);
  }

  /* ---------- job feed: desk states + tool log ---------- */
  function renderLog() {
    const ul = $("toolLog"); if (!ul) return;
    if (!TLOG.length) return;
    ul.replaceChildren(...TLOG.slice(0, 40).map(e => {
      const li = el("li"); const a = el("div", "", e.at + " · " + e.agent + " · " + e.label + (e.ok ? " ✓" : " ✗"));
      li.append(a, el("small", "muted", e.sec + " सेकंड"));
      if (!e.ok) li.classList.add("bad");
      return li;
    }));
  }
  window.extrasJob = function (j) {
    agents();
    const last = {}; (j.toollog || []).forEach(t => { last[t.agent] = t; });
    (j.steps || []).forEach(s => {
      const tl = last[s.agent], working = s.status === "working";
      STATE[s.agent] = {status: s.status === "error" ? "idle" : s.status, tool: working ? (tl ? tl.label + " ✓" : "सोच रहा…") : ""};
    });
    (j.toollog || []).forEach((t, idx) => {
      const key = j.id + ":" + idx; if (SEEN.has(key)) return; SEEN.add(key);
      const a = AG.find(x => x.id === t.agent);
      TLOG.unshift({at: t.at, agent: a ? a.short : "—", label: t.label, sec: t.sec, ok: t.ok});
    });
    if (TLOG.length > 60) TLOG.length = 60;
    const live = (j.steps || []).some(s => s.status === "working");
    if ($("townState")) $("townState").textContent = live ? "काम चालू" : "सब तैयार";
    if (j.status && j.status !== "running") {
      if ($("jobStat")) $("jobStat").textContent = "आख़िरी काम: ⏱ " + (j.secs || 0) + " सेकंड · 🔤 " + (j.tokens || 0) + " टोकन · 🔧 " + (j.toollog || []).length + " टूल" + (j.quiet ? " · 🤫 चुप रहा" : "");
      clearTimeout(clearT); clearT = setTimeout(() => { Object.keys(STATE).forEach(k => delete STATE[k]); }, 6000);
    }
    renderLog();
  };
  window.townOpen = function () {
    agents(); renderLog();
    if (!running) { running = true; requestAnimationFrame(loop); }
  };
  document.addEventListener("DOMContentLoaded", () => {
    const cv = $("townCv"); if (!cv) return;
    cv.addEventListener("click", e => {
      const r = cv.getBoundingClientRect(), x = (e.clientX - r.left) * W / r.width, y = (e.clientY - r.top) * H / r.height;
      if (y < TOP) return;
      const a = agents()[Math.floor((y - TOP) / RH) * COLS + Math.floor(x / CW)];
      if (a) { showView("home", "pVoice"); input.value = a.name + " (" + a.task + "): "; input.focus(); }
    });
  });

  /* ---------- Control Center ---------- */
  const TILES = [
    ["🎙", "आवाज़ से बात", "mic"], ["🗂", "काम (Tasks)", "view", "tasks"], ["🧠", "मेमोरी", "view", "memory"],
    ["⏰", "रिमाइंडर", "fill", "मुझे याद दिलाओ: "], ["⏱", "अलार्म / टाइमर", "fill", "अलार्म लगाओ: "], ["📱", "ऐप खोलो", "fill", "खोलो: "],
    ["💬", "WhatsApp संदेश", "fill", "WhatsApp पर संदेश भेजो: "], ["📞", "कॉल करो", "fill", "कॉल करो: "], ["🧭", "रास्ता", "fill", "रास्ता दिखाओ: "],
    ["🎵", "संगीत", "fill", "गाना बजाओ: "], ["🔦", "टॉर्च", "send", "टॉर्च चालू करो"], ["📍", "मेरी लोकेशन", "send", "मेरी अभी की लोकेशन बताओ"],
    ["📰", "आज की ख़बर", "send", "आज की 3 मुख्य ख़बरें छोटे में बताओ"], ["☀", "आज का सार", "send", "आज का दिन, मेरे बाकी टास्क और 3 मुख्य ख़बरें छोटे में बताओ"],
    ["📊", "सिस्टम स्कैन", "scan"], ["🩺", "आवाज़ की जाँच", "diag"], ["⭐", "Skills", "view", "skills"], ["🧩", "Developer", "dev"], ["🔧", "Settings", "view", "settings"]
  ];
  async function stats() {
    const box = $("ctlStats"); if (!box) return;
    try {
      const m = await api("/api/metrics");
      const items = [["CPU", m.cpu == null ? "—" : m.cpu + "%"], ["RAM", m.ram == null ? "—" : m.ram + "%"], ["Storage", m.storage + "%"],
        ["Net", m.online ? m.net_ms + "ms" : "Off"], ["आज के टोकन", m.tokens_today || 0], ["API कॉल", m.calls_today || 0]];
      box.replaceChildren(...items.map(([k, v]) => { const d = el("div", "cs"); d.append(el("b", "", String(v)), el("small", "", k)); return d; }));
    } catch (_) {}
  }
  async function scan() {
    try {
      const [m, s] = await Promise.all([api("/api/metrics"), api("/api/status")]);
      addBubble("assistant", "AKASH", "सिस्टम स्कैन: CPU " + (m.cpu == null ? "—" : m.cpu + "%") + " · RAM " + (m.ram == null ? "—" : m.ram + "%") + " · Storage " + m.storage + "% · नेटवर्क " + (m.online ? m.net_ms + "ms" : "बंद") +
        " · आज " + (m.tokens_today || 0) + " टोकन · मॉडल: " + s.model + " · बाकी काम: " + s.tasks);
      showView("home", "pVoice");
    } catch (e) { toast(e.message); }
  }
  async function diag() {
    const lines = [];
    try {
      if (typeof window.AkashNative === "undefined") lines.push("ℹ️ यह ऐप के अंदर नहीं, ब्राउज़र है — फ़ोन वाली जाँच नहीं हो सकती");
      else {
        const n = JSON.parse(window.AkashNative.status());
        lines.push((n.mic ? "✅" : "❌") + " माइक की अनुमति" + (n.mic ? "" : " — Settings → फ़ोन की अनुमतियाँ में दो"));
        lines.push((n.listening ? "✅" : "❌") + " सुनना चालू" + (n.listening ? "" : " — Background Mode या 🎙 दबाओ"));
        lines.push((n.battery ? "✅" : "❌") + " बैटरी में रोक नहीं" + (n.battery ? "" : " — फ़ोन सेटिंग में AKASH को Unrestricted करो"));
      }
      const [m, s] = await Promise.all([api("/api/metrics"), api("/api/settings")]);
      lines.push((m.online ? "✅" : "❌") + " इंटरनेट" + (m.online ? " (" + m.net_ms + "ms)" : " बंद है — आवाज़ पहचान और AI दोनों नहीं चलेंगे"));
      lines.push((s.api_key_set ? "✅" : "❌") + " API key · model: " + s.model);
      lines.push("आवाज़ पहचान: " + (s.stt_model || (/groq/.test(s.base_url) ? "whisper-large-v3-turbo (अपने-आप)" : "फ़ोन के अंदर वाला, कम सही")));
    } catch (e) { lines.push("जाँच पूरी नहीं हुई: " + e.message); }
    showView("home", "pVoice"); addBubble("assistant", "AKASH", "आवाज़ की जाँच:\n" + lines.join("\n"));
  }
  function build() {
    const g = $("ctlGrid"); if (!g || g.children.length) return;
    TILES.forEach(([icon, label, kind, arg]) => {
      const b = el("button", "ctile"); b.type = "button"; b.append(el("i", "", icon), el("span", "", label));
      b.addEventListener("click", () => {
        if (kind === "view") showView(arg);
        else if (kind === "mic") { showView("home", "pVoice"); $("micBtn").click(); }
        else if (kind === "fill") { showView("home", "pVoice"); input.value = arg; input.focus(); }
        else if (kind === "send") { showView("home", "pVoice"); send(arg); }
        else if (kind === "scan") scan();
        else if (kind === "diag") diag();
        else if (kind === "dev") showView("home", "pSelf");
      });
      g.append(b);
    });
  }
  window.controlOpen = function () { build(); stats(); };
  setInterval(() => { if (view === "control") stats(); }, 4000);

  /* ---------- themes ---------- */
  window.applyTheme = function (t) {
    document.body.classList.remove("theme-red", "theme-green");
    if (t === "red" || t === "green") document.body.classList.add("theme-" + t);
  };
  document.addEventListener("DOMContentLoaded", () => {
    const sel = $("setTheme"); if (!sel) return;
    sel.addEventListener("change", () => { applyTheme(sel.value); post("/api/settings", {theme: sel.value}).catch(() => {}); });
  });
})();
