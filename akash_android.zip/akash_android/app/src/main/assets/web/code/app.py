"""AKASH AI v3 - Flask backend.

Real LLM (any OpenAI-compatible API) with tool calling, 10 specialist agents that
run as a live pipeline, web search, SQLite memory, tasks, sandboxed files, a code
runner, system metrics, skills and a Self-Development cycle that only ever
*proposes* changes (the user approves; AKASH never edits its own code).
"""
import ast
import json
import operator
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from datetime import datetime
from html import unescape
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

import requests
from flask import Flask, jsonify, render_template, request

APP_DIR = Path(__file__).resolve().parent


def load_env():
    f = APP_DIR / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()
WEB = Path(os.getenv("AKASH_WEB") or APP_DIR)
CODE_DIR = Path(os.getenv("AKASH_CODE") or APP_DIR)
app = Flask(__name__, template_folder=str(WEB / "templates"), static_folder=str(WEB / "static"))
app.config["TEMPLATES_AUTO_RELOAD"] = True

# ----------------------------------------------------------------- agents
BASE_TOOLS = ["remember", "get_time"]
AGENTS = [
    {"id": "research", "name": "Research Agent", "icon": "⌕", "task": "वेब रिसर्च और तथ्य-जाँच", "tools": ["web_search"],
     "role": "You research on the web and fact-check. Always use web_search for current facts and name your sources."},
    {"id": "content", "name": "Content Agent", "icon": "✎", "task": "स्क्रिप्ट, कैप्शन, लेखन", "tools": [],
     "role": "You write scripts, captions, posts and plans. Use the research notes you are given."},
    {"id": "media", "name": "Media Agent", "icon": "▶", "task": "इमेज/वीडियो की योजना", "tools": [],
     "role": "You plan images and videos: shot list, thumbnail text, image-generator prompts. You cannot render media yourself; say so if asked."},
    {"id": "coding", "name": "Coding Agent", "icon": "</>", "task": "कोड और डिबगिंग", "tools": ["calculate", "list_files", "read_file", "write_file"],
     "role": "You write, explain and debug code. Put runnable Python in a ```python block; the user can run it in Coding Studio."},
    {"id": "productivity", "name": "Productivity Agent", "icon": "✓", "task": "टास्क, योजना, रिमाइंडर", "tools": ["add_task", "list_tasks"],
     "role": "You manage the user's tasks and daily plans. Use add_task/list_tasks for real changes."},
    {"id": "finance", "name": "Finance Agent", "icon": "₹", "task": "बजट और हिसाब", "tools": ["calculate", "web_search"],
     "role": "You do budgets and calculations. Use calculate for exact arithmetic. Not financial advice."},
    {"id": "health", "name": "Health Agent", "icon": "♡", "task": "सामान्य स्वास्थ्य जानकारी", "tools": ["web_search"],
     "role": "You give general wellness information only, never diagnoses; suggest a doctor for anything serious."},
    {"id": "files", "name": "Files Agent", "icon": "▤", "task": "फाइलें पढ़ना/लिखना (workspace)", "tools": ["list_files", "read_file", "write_file"],
     "role": "You read and write text files inside the user's workspace folder only."},
    {"id": "automation", "name": "Automation Agent", "icon": "⚙", "task": "फ़ोन के काम, WhatsApp, SMS, कॉल", "tools": ["add_task", "list_tasks", "write_file", "find_contact", "send_sms", "make_call", "whatsapp_message", "whatsapp_call", "open_app"],
     "role": "You do phone tasks for the user: SMS, calls, WhatsApp messages/calls, opening apps, plus routines, tasks and files. Phone tools work only inside the AKASH Android app."},
    {"id": "selfdev", "name": "Self-Development Agent", "icon": "↗", "task": "खुद का कोड बदलना (बैकअप के साथ)", "tools": ["propose_change", "read_own_code", "search_own_code", "modify_own_code", "list_backups", "restore_backup"],
     "role": "You can change AKASH's own code when the user asks. Files: app.py (backend), templates/index.html, static/app.js, static/style.css. Workflow: search_own_code / read_own_code to see the real text, then modify_own_code with an exact, unique 'old' text (small edits; to add code, use old='' to append). A backup is made automatically. Afterwards tell the user: what changed, the backup id, whether a restart is needed (app.py changes), and that saying 'पुराना कोड वापस लगाओ' restores it. If the user asks to restore, use list_backups/restore_backup. Never claim a change was made unless the tool says ok."},
]
BYID = {a["id"]: a for a in AGENTS}
TOOL_LABELS = {"web_search": "वेब सर्च", "remember": "मेमोरी", "add_task": "टास्क", "list_tasks": "टास्क", "calculate": "हिसाब",
               "get_time": "समय", "propose_change": "सुधार प्रस्ताव", "read_own_code": "कोड पढ़ना", "search_own_code": "कोड खोजना", "modify_own_code": "कोड बदला", "list_backups": "बैकअप", "restore_backup": "कोड वापस", "list_files": "फाइलें", "read_file": "फाइलें", "write_file": "फाइलें", "find_contact": "संपर्क", "send_sms": "SMS", "make_call": "कॉल", "whatsapp_message": "WhatsApp", "whatsapp_call": "WhatsApp कॉल", "open_app": "ऐप खोलना"}


# --------------------------------------------------------------- settings
def data_dir():
    d = Path(os.getenv("AKASH_DATA") or APP_DIR / "data")
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_settings():
    try:
        return json.loads((data_dir() / "settings.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def put_settings(upd):
    s = get_settings()
    for k in ("api_key", "model", "base_url", "tavily_key"):
        if k in upd and isinstance(upd[k], str):
            v = upd[k].strip()
            if k in ("api_key", "tavily_key") and v == "":
                continue  # blank = keep the existing secret
            s[k] = v
    for k in ("voice_reply", "multi_agent", "ask_before_send"):
        if k in upd:
            s[k] = bool(upd[k])
    p = data_dir() / "settings.json"
    p.write_text(json.dumps(s, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        p.chmod(0o600)
    except OSError:
        pass
    return s


def llm_config(over=None):
    s = {**get_settings(), **(over or {})}
    return {"key": (s.get("api_key") or os.getenv("OPENAI_API_KEY", "")).strip(),
            "model": (s.get("model") or os.getenv("OPENAI_MODEL", "") or "gpt-4.1-mini").strip(),
            "base": (s.get("base_url") or os.getenv("OPENAI_BASE_URL", "") or "https://api.openai.com/v1").strip().rstrip("/")}


def ai_on():
    return bool(llm_config()["key"])


def tavily_key():
    return (get_settings().get("tavily_key") or os.getenv("TAVILY_API_KEY", "")).strip()


def hint(k):
    return ("…" + k[-4:]) if k else ""


# --------------------------------------------------------------- database
def db():
    p = Path(os.getenv("AKASH_DB") or data_dir() / "akash.db")
    p.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(p)
    c.row_factory = sqlite3.Row
    return c


DEFAULT_SKILLS = [
    ("YouTube वीडियो प्लान", "मेरे चैनल के लिए Self Development पर एक YouTube वीडियो का आइडिया, स्क्रिप्ट आउटलाइन और थंबनेल टेक्स्ट बनाओ।"),
    ("आज की ख़बर", "इंटरनेट पर खोजकर आज की भारत की मुख्य ख़बरें 5 छोटी पंक्तियों में बताओ।"),
    ("आज की योजना", "मेरे खुले टास्क देखकर आज का समय-अनुसार प्लान बनाओ।"),
    ("कोड रिव्यू", "मेरे workspace की फाइलें देखो और उनमें सुधार के सुझाव दो।"),
]


def now():
    return datetime.now().isoformat(timespec="seconds")


def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY, ts TEXT, role TEXT, content TEXT);
        CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY, ts TEXT, kind TEXT, text TEXT);
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, ts TEXT, title TEXT, done INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS proposals(id INTEGER PRIMARY KEY, ts TEXT, title TEXT, detail TEXT, status TEXT DEFAULT 'pending');
        CREATE TABLE IF NOT EXISTS skills(id INTEGER PRIMARY KEY, name TEXT, prompt TEXT);
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, ts TEXT, kind TEXT, detail TEXT);
        """)
        if not c.execute("SELECT 1 FROM skills LIMIT 1").fetchone():
            c.executemany("INSERT INTO skills(name,prompt) VALUES(?,?)", DEFAULT_SKILLS)
        old = APP_DIR / "memory.json"
        if old.exists() and not c.execute("SELECT 1 FROM memories LIMIT 1").fetchone():
            try:
                d = json.loads(old.read_text(encoding="utf-8"))
                for kind, key in (("note", "notes"), ("preference", "preferences")):
                    for n in d.get(key, []):
                        t = n.get("text") if isinstance(n, dict) else str(n)
                        if t:
                            c.execute("INSERT INTO memories(ts,kind,text) VALUES(?,?,?)", (now(), kind, t[:500]))
            except Exception:
                pass


def log_event(kind, detail):
    try:
        with db() as c:
            c.execute("INSERT INTO events(ts,kind,detail) VALUES(?,?,?)", (now(), kind, str(detail)[:300]))
            c.execute("DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT 200)")
    except Exception:
        pass


# ----------------------------------------------------------------- memory
def tokens(s):
    return {w for w in re.split(r"[\s,.!?।;:()\"'\[\]]+", s.lower()) if len(w) > 1}


def relevant_memories(message, limit=6):
    with db() as c:
        rows = [dict(r) for r in c.execute("SELECT * FROM memories ORDER BY id DESC LIMIT 300")]
    prefs = [r for r in rows if r["kind"] == "preference"][:10]
    q = tokens(message)
    scored = sorted(((len(q & tokens(r["text"])), r["id"], r) for r in rows if r["kind"] != "preference"),
                    key=lambda x: (x[0], x[1]), reverse=True)
    return prefs + ([r for s, _, r in scored if s > 0][:limit] or [r for _, _, r in scored][:3])


def save_memory(text, kind="note"):
    text = (text or "").strip()[:500]
    if not text:
        return None
    kind = kind if kind in ("note", "preference", "fact", "project") else "note"
    with db() as c:
        dup = c.execute("SELECT id FROM memories WHERE text=?", (text,)).fetchone()
        return dup["id"] if dup else c.execute("INSERT INTO memories(ts,kind,text) VALUES(?,?,?)", (now(), kind, text)).lastrowid


def recent_history(n=10):
    with db() as c:
        rows = c.execute("SELECT role,content FROM history ORDER BY id DESC LIMIT ?", (n,)).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]


def log_turn(user, assistant):
    with db() as c:
        c.execute("INSERT INTO history(ts,role,content) VALUES(?,?,?)", (now(), "user", user[:2000]))
        c.execute("INSERT INTO history(ts,role,content) VALUES(?,?,?)", (now(), "assistant", assistant[:4000]))
        c.execute("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY id DESC LIMIT 400)")


# ------------------------------------------------------------- web search
UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"}


def clean(s):
    return unescape(re.sub(r"<[^>]+>", "", s or "")).strip()


def search_provider():
    return "Tavily" if tavily_key() else "DuckDuckGo"


def web_search(query, n=5):
    query = (query or "").strip()
    if not query:
        return []
    if tavily_key():
        r = requests.post("https://api.tavily.com/search", timeout=20, json={"api_key": tavily_key(), "query": query, "max_results": n})
        r.raise_for_status()
        return [{"title": x.get("title", ""), "url": x.get("url", ""), "snippet": (x.get("content") or "")[:400]} for x in r.json().get("results", [])[:n]]
    r = requests.post("https://html.duckduckgo.com/html/", data={"q": query}, headers=UA, timeout=20)
    r.raise_for_status()
    links = re.findall(r'<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>(.*?)</a>', r.text, re.S)
    snips = re.findall(r'class="result__snippet"[^>]*>(.*?)</a>', r.text, re.S)
    out = []
    for i, (href, title) in enumerate(links[:n]):
        if "uddg=" in href:
            href = unquote(parse_qs(urlparse(href).query).get("uddg", [href])[0])
        out.append({"title": clean(title), "url": href, "snippet": clean(snips[i]) if i < len(snips) else ""})
    return out


# ------------------------------------------------- self code edit + backups
EDITABLE = ["app.py", "templates/index.html", "static/app.js", "static/style.css"]
_CS = {"id": None, "t": 0.0, "files": set()}  # edits made within 3 minutes share one backup


def code_path(name):
    if name not in EDITABLE:
        raise ValueError("सिर्फ़ ये फाइलें बदली जा सकती हैं: " + ", ".join(EDITABLE))
    return (CODE_DIR if name == "app.py" else WEB) / name


def backups_root():
    d = data_dir() / "backups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _manifest(bid, label, files):
    (backups_root() / bid / "manifest.json").write_text(json.dumps({"id": bid, "ts": now(), "label": label, "files": files}, ensure_ascii=False), encoding="utf-8")


def make_backup(label, files=None):
    files = [f for f in (files or EDITABLE) if code_path(f).exists()]
    bid = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:4]
    for f in files:
        dst = backups_root() / bid / f
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(code_path(f), dst)
    _manifest(bid, label, files)
    for old in sorted(p for p in backups_root().iterdir() if p.is_dir())[:-40]:
        shutil.rmtree(old, ignore_errors=True)
    return bid


def ensure_backup(name, label):
    if _CS["id"] and time.time() - _CS["t"] < 180 and (backups_root() / _CS["id"]).exists():
        if name not in _CS["files"]:
            dst = backups_root() / _CS["id"] / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(code_path(name), dst)
            _CS["files"].add(name)
            _manifest(_CS["id"], label, sorted(_CS["files"]))
    else:
        _CS.update(id=make_backup(label, [name]), files={name})
    _CS["t"] = time.time()
    return _CS["id"]


def list_backups():
    out = []
    for d in sorted((p for p in backups_root().iterdir() if p.is_dir()), reverse=True):
        try:
            out.append(json.loads((d / "manifest.json").read_text(encoding="utf-8")))
        except Exception:
            pass
    return out


def restore_backup(bid="latest"):
    bl = list_backups()
    m = next((b for b in bl if bid in ("latest", "", None) or b["id"] == bid), None)
    if not m:
        raise ValueError("ऐसा कोई बैकअप नहीं मिला")
    make_backup("वापस लगाने से पहले की हालत", m["files"])
    for f in m["files"]:
        shutil.copy2(backups_root() / m["id"] / f, code_path(f))
    _CS.update(id=None, files=set())
    return {"ok": True, "restored": m["id"], "label": m["label"], "files": m["files"], "restart_needed": "app.py" in m["files"]}


def modify_own_code(file, old, new, reason=""):
    name = (file or "").strip().lstrip("/")
    p = code_path(name)
    text = p.read_text(encoding="utf-8")
    if old == "":
        new_text = text + ("" if text.endswith("\n") else "\n") + new
    else:
        n = text.count(old)
        if n == 0:
            raise ValueError("'old' वाला लिखा हुआ टेक्स्ट फाइल में नहीं मिला। पहले read_own_code से असली टेक्स्ट देखो।")
        if n > 1:
            raise ValueError(f"'old' टेक्स्ट {n} जगह मिला; थोड़ा और आसपास का टेक्स्ट जोड़ो ताकि वह अकेला (unique) हो।")
        new_text = text.replace(old, new, 1)
    if name.endswith(".py"):
        try:
            compile(new_text, name, "exec")
        except SyntaxError as e:
            raise ValueError(f"नया Python कोड गलत है (लाइन {e.lineno}: {e.msg}); कुछ नहीं बदला।")
    bid = ensure_backup(name, reason.strip()[:120] or "AKASH ने खुद बदला")
    p.write_text(new_text, encoding="utf-8")
    log_event("self_edit", f"{name} backup={bid}")
    return {"ok": True, "file": name, "backup": bid, "restart_needed": name == "app.py"}


def read_own_code(file, start=1, end=150):
    name = (file or "").strip().lstrip("/")
    lines = code_path(name).read_text(encoding="utf-8").splitlines()
    start, end = max(1, int(start or 1)), min(len(lines), int(end or 150))
    body = "\n".join(f"{i}: {lines[i - 1]}" for i in range(start, end + 1))
    return {"file": name, "total_lines": len(lines), "shown": f"{start}-{end}", "code": body[:12000]}


def search_own_code(text):
    hits = []
    for f in EDITABLE:
        try:
            for i, line in enumerate(code_path(f).read_text(encoding="utf-8").splitlines(), 1):
                if text.lower() in line.lower() and len(hits) < 40:
                    hits.append(f"{f}:{i}: {line.strip()[:140]}")
        except OSError:
            pass
    return hits or ["कुछ नहीं मिला"]


# --------------------------------------------------------- workspace files
def workspace():
    w = data_dir() / "workspace"
    w.mkdir(parents=True, exist_ok=True)
    return w


def safe_path(name):
    name = (name or "").strip().lstrip("/\\")
    if not name or len(name) > 120:
        raise ValueError("फाइल का नाम सही नहीं है")
    p = (workspace() / name).resolve()
    if workspace().resolve() not in p.parents:
        raise ValueError("सिर्फ़ workspace के अंदर की फाइलें allowed हैं")
    return p


def list_files():
    w = workspace()
    return sorted(str(p.relative_to(w)) for p in w.rglob("*") if p.is_file() and not p.name.startswith("_"))[:200]


def read_file(name):
    p = safe_path(name)
    if not p.is_file():
        raise ValueError("फाइल नहीं मिली")
    return p.read_text(encoding="utf-8", errors="replace")[:20000]


def write_file(name, content):
    p = safe_path(name)
    if len(content or "") > 100_000:
        raise ValueError("फाइल बहुत बड़ी है (100KB से कम रखो)")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content or "", encoding="utf-8")
    return str(p.relative_to(workspace()))


# ------------------------------------------------------------------ tools
_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.Pow: operator.pow, ast.Mod: operator.mod, ast.USub: operator.neg, ast.FloorDiv: operator.floordiv}


def safe_eval(expr):
    def ev(n):
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.BinOp) and type(n.op) in _OPS:
            if isinstance(n.op, ast.Pow) and abs(ev(n.right)) > 100:
                raise ValueError("power too large")
            return _OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and type(n.op) in _OPS:
            return _OPS[type(n.op)](ev(n.operand))
        raise ValueError("unsupported expression")
    return ev(ast.parse(expr, mode="eval").body)


S = {"type": "string"}


def fn(name, desc, props=None, req=None):
    return {"type": "function", "function": {"name": name, "description": desc,
                                              "parameters": {"type": "object", "properties": props or {}, "required": req or []}}}


TOOLS = [
    fn("web_search", "Search the web for current info, news, prices, facts.", {"query": S}, ["query"]),
    fn("remember", "Save to long-term memory when the user asks to remember something or states a lasting preference.",
       {"text": S, "kind": {"type": "string", "enum": ["note", "preference", "fact", "project"]}}, ["text"]),
    fn("add_task", "Add a to-do item.", {"title": S}, ["title"]),
    fn("list_tasks", "List the user's open tasks."),
    fn("calculate", "Evaluate an arithmetic expression exactly.", {"expression": S}, ["expression"]),
    fn("get_time", "Get the current local date and time."),
    fn("list_files", "List files in the user's workspace folder."),
    fn("read_file", "Read a text file from the workspace.", {"name": S}, ["name"]),
    fn("write_file", "Create/overwrite a text file in the workspace.", {"name": S, "content": S}, ["name", "content"]),
    fn("propose_change", "Propose an improvement to AKASH itself. Only queued for user approval; nothing is changed.",
       {"title": S, "detail": S}, ["title", "detail"]),
]
NUM = {"type": "string", "description": "phone number; get it from find_contact, never guess"}
TOOLS += [
    fn("find_contact", "Find a contact's phone number by name. Try both Hindi and English spellings if nothing is found.", {"name": S}, ["name"]),
    fn("send_sms", "Send an SMS (Android app only).", {"number": NUM, "text": S}, ["number", "text"]),
    fn("make_call", "Place a normal phone call (Android app only).", {"number": NUM}, ["number"]),
    fn("whatsapp_message", "Send a WhatsApp message to one person (Android app only).", {"number": NUM, "text": S}, ["number", "text"]),
    fn("whatsapp_call", "Start a WhatsApp voice or video call (Android app only).", {"number": NUM, "video": {"type": "boolean"}}, ["number"]),
    fn("open_app", "Open an installed app by its name (Android app only).", {"name": S}, ["name"]),
]
TOOLS += [
    fn("read_own_code", "Read AKASH's own source file with line numbers. file is one of app.py, templates/index.html, static/app.js, static/style.css.",
       {"file": S, "start": {"type": "integer"}, "end": {"type": "integer"}}, ["file"]),
    fn("search_own_code", "Find a text in AKASH's own source files; returns file:line matches.", {"text": S}, ["text"]),
    fn("modify_own_code", "Change AKASH's own code: replace the exact unique text 'old' by 'new' (old='' appends 'new' at the end). Automatic backup first; Python syntax is checked before writing.",
       {"file": S, "old": S, "new": S, "reason": S}, ["file", "old", "new"]),
    fn("list_backups", "List code backups, newest first."),
    fn("restore_backup", "Put back an older version of the code. id='latest' or a backup id from list_backups.", {"id": S}, []),
]
TOOLMAP = {t["function"]["name"]: t for t in TOOLS}

ACTION_TOOLS = {"send_sms", "make_call", "whatsapp_message", "whatsapp_call"}
ACTIONS = {}


def phone():
    """The Kotlin PhoneBridge when running inside the Android app, else None."""
    try:
        from java import jclass
        return jclass("com.akash.ai.PhoneBridge")
    except Exception:
        return None


def phone_call(method, *args):
    b = phone()
    if b is None:
        return json.dumps({"ok": False, "error": "ये सुविधा सिर्फ़ AKASH के Android ऐप में है"}, ensure_ascii=False)
    try:
        return str(getattr(b, method)(*args))
    except Exception as e:
        log_event("phone_error", f"{method}: {e}")
        return json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"}, ensure_ascii=False)


def describe_action(name, a):
    who, text = a.get("number", ""), a.get("text", "")
    return {"send_sms": f"SMS → {who}: “{text}”", "make_call": f"कॉल → {who}", "whatsapp_message": f"WhatsApp → {who}: “{text}”",
            "whatsapp_call": f"WhatsApp {'वीडियो' if a.get('video') else 'वॉइस'} कॉल → {who}"}.get(name, name)


def exec_action(name, a):
    num, text = str(a.get("number", "")).strip(), str(a.get("text", ""))
    if not num:
        return json.dumps({"ok": False, "error": "number missing"})
    if name == "send_sms":
        return phone_call("sendSms", num, text)
    if name == "make_call":
        return phone_call("call", num)
    if name == "whatsapp_message":
        return phone_call("whatsappMessage", num, text)
    if name == "whatsapp_call":
        return phone_call("whatsappCall", num, bool(a.get("video")))
    return json.dumps({"ok": False, "error": "unknown action"})


def live_actions():
    for k in [k for k, v in ACTIONS.items() if time.time() - v["t"] > 600]:
        ACTIONS.pop(k, None)
    return sorted(ACTIONS.values(), key=lambda v: v["t"])


def queue_action(name, a):
    if not get_settings().get("ask_before_send", True):
        return exec_action(name, a)
    aid = uuid.uuid4().hex[:8]
    ACTIONS[aid] = {"id": aid, "tool": name, "args": a, "summary": describe_action(name, a), "t": time.time()}
    return json.dumps({"status": "needs_confirmation", "id": aid, "summary": ACTIONS[aid]["summary"],
                       "note": "NOT done yet. Tell the user exactly what will happen and ask yes/no. The app also shows a confirm button."}, ensure_ascii=False)


def run_pending(aid, confirm):
    act = ACTIONS.pop(aid, None)
    if not act:
        return "वह काम अब बाकी नहीं है।", []
    if not confirm:
        return "ठीक है, रद्द कर दिया।", []
    try:
        r = json.loads(exec_action(act["tool"], act["args"]))
    except ValueError:
        r = {"ok": False, "error": "जवाब समझ नहीं आया"}
    return (("हो गया ✅ " + r.get("message", "")) if r.get("ok") else "नहीं हो पाया: " + r.get("error", "अज्ञात गड़बड़")), [act["tool"]]


YES = {"हाँ", "हां", "haan", "han", "ha", "yes", "yeah", "ok", "okay", "ठीक है", "भेज दो", "भेजो", "कर दो", "करो", "जी", "जी हाँ", "जी हां", "हाँ भेजो", "हां भेजो", "हाँ भेज दो", "हां भेज दो", "हाँ कर दो", "हां कर दो", "कॉल करो", "हाँ कॉल करो", "हां कॉल करो"}
NO = {"नहीं", "नही", "ना", "no", "nope", "cancel", "रद्द", "रद्द करो", "रुको", "मत भेजो", "रहने दो", "नहीं भेजो"}


def quick_confirm(message):
    acts = live_actions()
    if not acts:
        return None
    w = re.sub(r"[.,!?।\"'…-]+", "", message.lower()).strip()
    if w in YES:
        return run_pending(acts[-1]["id"], True)
    if w in NO:
        return run_pending(acts[-1]["id"], False)
    return None


def run_tool(name, a):
    try:
        if name == "web_search":
            return json.dumps(web_search(a.get("query", "")) or {"error": "no results"}, ensure_ascii=False)
        if name == "remember":
            return json.dumps({"saved": bool(save_memory(a.get("text"), a.get("kind", "note")))})
        if name == "add_task":
            t = (a.get("title") or "").strip()[:200]
            if not t:
                return json.dumps({"error": "empty title"})
            with db() as c:
                c.execute("INSERT INTO tasks(ts,title) VALUES(?,?)", (now(), t))
            return json.dumps({"added": t})
        if name == "list_tasks":
            with db() as c:
                return json.dumps([r["title"] for r in c.execute("SELECT title FROM tasks WHERE done=0")], ensure_ascii=False)
        if name == "calculate":
            return json.dumps({"result": safe_eval(a.get("expression", ""))})
        if name == "get_time":
            return datetime.now().strftime("%A, %d %B %Y, %I:%M %p")
        if name == "list_files":
            return json.dumps(list_files(), ensure_ascii=False)
        if name == "read_file":
            return read_file(a.get("name"))
        if name == "write_file":
            return json.dumps({"written": write_file(a.get("name"), a.get("content"))}, ensure_ascii=False)
        if name == "read_own_code":
            return json.dumps(read_own_code(a.get("file"), a.get("start", 1), a.get("end", 150)), ensure_ascii=False)
        if name == "search_own_code":
            return json.dumps(search_own_code(str(a.get("text", ""))), ensure_ascii=False)
        if name == "modify_own_code":
            return json.dumps(modify_own_code(a.get("file"), a.get("old", ""), a.get("new", ""), a.get("reason", "")), ensure_ascii=False)
        if name == "list_backups":
            return json.dumps(list_backups()[:15], ensure_ascii=False)
        if name == "restore_backup":
            return json.dumps(restore_backup(a.get("id") or "latest"), ensure_ascii=False)
        if name == "find_contact":
            return phone_call("findContact", str(a.get("name", "")))
        if name == "open_app":
            return phone_call("openApp", str(a.get("name", "")))
        if name in ACTION_TOOLS:
            return queue_action(name, a)
        if name == "propose_change":
            with db() as c:
                c.execute("INSERT INTO proposals(ts,title,detail) VALUES(?,?,?)", (now(), (a.get("title") or "")[:150], (a.get("detail") or "")[:1500]))
            return json.dumps({"queued": "waiting for user approval"})
    except Exception as e:
        log_event("tool_error", f"{name}: {e}")
        return json.dumps({"error": f"{type(e).__name__}: {e}"})
    return json.dumps({"error": "unknown tool"})


# ------------------------------------------------------------------ brain
def choose_agents(message):
    m = message.lower()
    rules = [
        ("research", ["search", "research", "find", "news", "खोज", "रिसर्च", "जानकारी", "इंटरनेट", "सर्च", "ख़बर", "खबर"]),
        ("content", ["script", "write", "caption", "story", "लिख", "स्क्रिप्ट", "कहानी", "पोस्ट", "video", "वीडियो"]),
        ("media", ["video", "image", "photo", "thumbnail", "वीडियो", "फोटो", "तस्वीर", "थंबनेल"]),
        ("coding", ["code", "coding", "app", "website", "bug", "कोड", "ऐप", "वेबसाइट", "प्रोग्राम"]),
        ("productivity", ["plan", "task", "remind", "schedule", "योजना", "काम", "रिमाइंडर", "टास्क", "प्लान"]),
        ("finance", ["money", "budget", "cost", "पैसा", "बजट", "खर्च", "लागत", "हिसाब"]),
        ("health", ["health", "fitness", "diet", "स्वास्थ्य", "फिटनेस", "खाना"]),
        ("files", ["file", "फाइल", "workspace"]),
        ("automation", ["automate", "routine", "ऑटोमेट", "रूटीन", "अपने-आप", "whatsapp", "व्हाट्सएप", "व्हाट्सअप", "sms", "एसएमएस", "call", "कॉल", "फोन कर", "मैसेज", "संदेश भेज", "message", "open ", "खोलो"]),
        ("selfdev", ["improve yourself", "self-develop", "खुद को", "सुधार", "बैकअप", "backup", "पुराना कोड", "कोड वापस", "कोड बदल", "अपने कोड", "अपने अंदर", "खुद में", "अपडेट कर"]),
    ]
    def hit(w):  # English keywords match word starts only ("app" must not fire inside "whatsapp")
        return re.search(r"\b" + re.escape(w.strip()), m) is not None if w.isascii() else w in m
    return ([a for a, words in rules if any(hit(w) for w in words)] or ["productivity"])[:4]


def sys_prompt(role, message, extra=""):
    mem = "\n".join(f"- [{m['kind']}] {m['text']}" for m in relevant_memories(message)) or "(कुछ नहीं)"
    return ("You are AKASH, a Hindi-first personal AI assistant (reply in the user's language, simple Hindi by default). "
            "Replies are often spoken aloud on a phone: be short and clear, no tables. "
            f"{role} Be honest: never claim an action happened unless a tool result confirms it. You cannot post online, upload or pay anywhere. Ask confirmation before anything sensitive. Use remember when the user asks you to remember something. "
            "PHONE: you can act on the phone ONLY through the phone tools (SMS, calls, WhatsApp, open app); if a tool says it is unavailable, say so honestly. "
            "For a person given by name, call find_contact first (never guess numbers; if several match, ask which). If a tool returns needs_confirmation, say exactly what will be sent/called and ask yes/no; never say it was already done. "
            f"{extra}\nNow: {datetime.now().strftime('%A %d %B %Y %I:%M %p')}\nSaved memory:\n{mem}")


def llm_run(system, messages, tool_names, over=None, max_iter=5):
    """One agent call with a tool loop. Returns (text, tools_used)."""
    cfg = llm_config(over)
    tools = [TOOLMAP[n] for n in dict.fromkeys(BASE_TOOLS + tool_names)]
    msgs = [{"role": "system", "content": system}] + messages
    used, use_tools = [], bool(tools)
    for _ in range(max_iter):
        body = {"model": cfg["model"], "messages": msgs, "temperature": 0.5}
        if use_tools:
            body["tools"] = tools
        r = requests.post(f"{cfg['base']}/chat/completions", timeout=60, json=body,
                          headers={"Authorization": f"Bearer {cfg['key']}", "Content-Type": "application/json"})
        if r.status_code == 400 and use_tools:
            use_tools = False
            continue
        r.raise_for_status()
        m = r.json()["choices"][0]["message"]
        calls = m.get("tool_calls")
        if not calls:
            return (m.get("content") or "").strip() or "जवाब खाली आया, दोबारा पूछो।", used
        msgs.append({"role": "assistant", "content": m.get("content"), "tool_calls": calls})
        for c in calls:
            name = c["function"]["name"]
            try:
                args = json.loads(c["function"].get("arguments") or "{}")
            except ValueError:
                args = {}
            used.append(name)
            msgs.append({"role": "tool", "tool_call_id": c["id"], "content": run_tool(name, args)[:6000]})
    return "काम पूरा करने में बहुत चरण लग गए। सवाल छोटा करके पूछो।", used


def api_error_text(e):
    code = getattr(getattr(e, "response", None), "status_code", None)
    hints = {401: "API key गलत है", 403: "API key को अनुमति नहीं है", 404: "model का नाम या base URL गलत है", 429: "API की limit/balance खत्म है"}
    return hints.get(code, "AI API से संपर्क नहीं हो पाया") + " — Settings में key, model और base URL जाँचो।"


def demo_chat(message):
    m = message.strip()
    mem = re.match(r"^(?:याद रखो|याद रखना|remember)[:\s,]+(.+)", m, re.I | re.S)
    if mem:
        save_memory(mem.group(1))
        return "ठीक है, मैंने इसे मेमोरी में सेव कर लिया।", ["remember"]
    s = re.match(r"^(?:search|सर्च|खोजो|खोज|इंटरनेट पर खोजो)[:\s,]+(.+)", m, re.I | re.S)
    if s:
        try:
            res = web_search(s.group(1))
            return ("सर्च के नतीजे:\n" + "\n".join(f"{i}. {x['title']} — {x['url']}" for i, x in enumerate(res, 1)) if res else "कोई नतीजा नहीं मिला।"), ["web_search"]
        except Exception as e:
            log_event("search_error", e)
            return f"वेब सर्च नहीं हो पाई ({type(e).__name__})। इंटरनेट जाँचो।", []
    if re.search(r"\b(hi|hello|hey)\b|नमस्ते|हेलो|हाय", m, re.I):
        return "नमस्ते! मैं AKASH हूँ। बताओ, क्या काम करूँ?", []
    return ("अभी API key नहीं जुड़ी है, इसलिए मैं सोचकर जवाब नहीं दे सकता। Settings (⚙) में API key डालो। "
            "तब तक: “सर्च: <विषय>” बोलो तो इंटरनेट पर खोजूँगा, “याद रखो: <बात>” बोलो तो मेमोरी में रखूँगा।"), []


# -------------------------------------------------------------------- jobs
JOBS, JLOCK = {}, threading.Lock()


def new_job():
    with JLOCK:
        for k in [k for k, v in JOBS.items() if time.time() - v["t"] > 900]:
            JOBS.pop(k, None)
        jid = uuid.uuid4().hex[:12]
        JOBS[jid] = {"id": jid, "t": time.time(), "status": "running", "steps": [], "answer": "", "tools": [], "agents": [], "mode": "", "message": ""}
        return JOBS[jid]


def step(job, i, **kw):
    job["steps"][i].update(kw)


def mk_steps(ids):
    return [{"agent": a, "name": BYID[a]["name"], "status": "waiting", "tools": [], "note": ""} for a in ids]


def process_chat(message, job):
    job["message"] = message
    qc = quick_confirm(message)
    if qc is not None:
        job["agents"], job["steps"], job["mode"] = ["automation"], mk_steps(["automation"]), "confirm"
        step(job, 0, status="done", note="तुम्हारी हाँ/नहीं पर अमल")
        job["answer"], job["tools"] = qc
        log_turn(message, job["answer"])
        job["status"] = "done"
        return
    chosen = choose_agents(message)
    job["agents"] = chosen
    job["mode"] = "AI API" if ai_on() else "Demo mode"
    job["steps"] = mk_steps(chosen)
    try:
        if not ai_on():
            for i in range(len(chosen)):
                step(job, i, status="working")
            ans, used = demo_chat(message)
            for i in range(len(chosen)):
                step(job, i, status="done", note="डेमो मोड")
            job["answer"], job["tools"] = ans, used
        elif len(chosen) == 1 or not get_settings().get("multi_agent", True):
            tool_names = [t for a in chosen for t in BYID[a]["tools"]]
            for i in range(len(chosen)):
                step(job, i, status="working")
            roles = " ".join(BYID[a]["role"] for a in chosen)
            ans, used = llm_run(sys_prompt(roles, message), recent_history(10) + [{"role": "user", "content": message}], tool_names)
            for i in range(len(chosen)):
                step(job, i, status="done", tools=sorted(set(used)))
            job["answer"], job["tools"] = ans, list(dict.fromkeys(used))
        else:
            outs, alltools = [], []
            for i, a in enumerate(chosen):
                step(job, i, status="working")
                prior = "\n\n".join(f"[{BYID[x]['name']}]\n{o}" for x, o in outs)
                user = f"User request: {message}" + (f"\n\nWork done so far by teammates:\n{prior}" if prior else "")
                out, used = llm_run(sys_prompt(BYID[a]["role"], message, "You are one step in a team pipeline. Do only your part, briefly (max 120 words)."),
                                    [{"role": "user", "content": user}], BYID[a]["tools"])
                outs.append((a, out))
                alltools += used
                step(job, i, status="done", tools=sorted(set(used)), note=out[:110])
            team = "\n\n".join(f"[{BYID[x]['name']}]\n{o}" for x, o in outs)
            ans, used = llm_run(sys_prompt("Combine your team's work into ONE final answer for the user.", message),
                                recent_history(6) + [{"role": "user", "content": f"User request: {message}\n\nTeam work:\n{team}\n\nGive the final answer."}], [])
            job["answer"], job["tools"] = ans, list(dict.fromkeys(alltools + used))
    except Exception as e:
        log_event("chat_error", e)
        for s_ in job["steps"]:
            if s_["status"] in ("working", "waiting"):
                s_["status"] = "error"
        job["answer"] = api_error_text(e)
    log_turn(message, job["answer"])
    job["status"] = "done"


def public_job(j):
    return {k: j[k] for k in ("id", "status", "steps", "answer", "tools", "agents", "mode", "message")}


# ------------------------------------------------------------- self-dev
def run_tests():
    tdir = APP_DIR / "tests"
    if not tdir.exists():
        return False, "tests फ़ोल्डर नहीं मिला"
    env = {**os.environ, "AKASH_DATA": tempfile.mkdtemp()}
    env.pop("AKASH_DB", None)
    try:
        r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", str(tdir)], cwd=APP_DIR, env=env,
                           capture_output=True, text=True, timeout=90)
        lines = (r.stderr or r.stdout).strip().splitlines() or [""]
        return r.returncode == 0, lines[-1]
    except Exception as e:
        return False, f"टेस्ट नहीं चल पाए: {type(e).__name__}"


def process_selfdev(job):
    job["steps"] = [{"agent": n, "name": n, "status": "waiting", "tools": [], "note": ""} for n in ("Analyze", "Test", "Improve", "Ask Approval")]
    job["mode"] = "selfdev"
    try:
        step(job, 0, status="working")
        with db() as c:
            errs = [dict(r) for r in c.execute("SELECT kind,detail FROM events ORDER BY id DESC LIMIT 30")]
            n_mem = c.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
            n_hist = c.execute("SELECT COUNT(*) FROM history").fetchone()[0]
        findings = []
        if not ai_on():
            findings.append("API key जुड़ी नहीं है, इसलिए असली AI जवाब बंद हैं।")
        if errs:
            findings.append(f"हाल में {len(errs)} गड़बड़ियाँ दर्ज हुईं, जैसे: {errs[0]['kind']} — {errs[0]['detail'][:80]}")
        if n_mem == 0:
            findings.append("मेमोरी खाली है; पसंद-नापसंद सेव करने से जवाब बेहतर होंगे।")
        if n_hist > 300:
            findings.append("चैट इतिहास बड़ा हो रहा है; पुरानी बातों का सार बनाना उपयोगी होगा।")
        findings = findings or ["कोई बड़ी समस्या नहीं मिली।"]
        step(job, 0, status="done", note="; ".join(findings)[:160])

        step(job, 1, status="working")
        ok, tail = run_tests()
        step(job, 1, status="done" if ok else "error", note=("टेस्ट पास: " if ok else "टेस्ट फ़ेल: ") + tail[:80])

        step(job, 2, status="working")
        base = "\n".join("- " + f for f in findings) + f"\n- टेस्ट: {'पास' if ok else 'फ़ेल'}"
        plan = "सुझाव: " + findings[0] + "\n(पूरा सुझाव बनाने के लिए API key जोड़ो।)"
        if ai_on():
            try:
                plan, _ = llm_run(sys_prompt("You review AKASH itself and propose ONE concrete, safe improvement.", "improve"),
                                  [{"role": "user", "content": "Findings:\n" + base + "\n\nWrite ONE improvement proposal in simple Hindi: what to change, why, how to test, how to roll back. Max 120 words."}], [])
            except Exception as e:
                log_event("selfdev_error", e)
                plan = base
        step(job, 2, status="done", note=plan[:110])

        step(job, 3, status="working")
        with db() as c:
            c.execute("INSERT INTO proposals(ts,title,detail) VALUES(?,?,?)", (now(), "सुधार चक्र: " + findings[0][:80], plan[:1500]))
        step(job, 3, status="done", note="प्रस्ताव तुम्हारी मंज़ूरी के लिए रखा गया")
        job["answer"] = "सुधार चक्र पूरा। प्रस्ताव मंज़ूरी के इंतज़ार में है; कोई बदलाव लागू नहीं किया गया।"
    except Exception as e:
        log_event("selfdev_error", e)
        job["answer"] = f"सुधार चक्र रुक गया: {type(e).__name__}"
        for s_ in job["steps"]:
            if s_["status"] in ("working", "waiting"):
                s_["status"] = "error"
    job["status"] = "done"


# ---------------------------------------------------------------- metrics
def cpu_pct():
    def snap():
        with open("/proc/stat") as f:
            v = list(map(int, f.readline().split()[1:]))
        return v[3] + (v[4] if len(v) > 4 else 0), sum(v)
    try:
        i1, t1 = snap()
        time.sleep(0.15)
        i2, t2 = snap()
        return round(100 * (1 - (i2 - i1) / max(1, t2 - t1)))
    except Exception:
        try:
            return min(100, round(os.getloadavg()[0] / (os.cpu_count() or 1) * 100))
        except Exception:
            return None


def ram_pct():
    try:
        with open("/proc/meminfo") as f:
            m = {l.split(":")[0]: int(l.split()[1]) for l in f}
        return round(100 * (1 - m["MemAvailable"] / m["MemTotal"]))
    except Exception:
        return None


_NET = {"t": 0, "v": (False, None)}


def net_check():
    if time.time() - _NET["t"] < 5:
        return _NET["v"]
    t0 = time.time()
    try:
        socket.create_connection(("1.1.1.1", 53), 1.2).close()
        v = (True, round((time.time() - t0) * 1000))
    except Exception:
        v = (False, None)
    _NET.update(t=time.time(), v=v)
    return v


def local_only():
    return os.getenv("HOST", "127.0.0.1") in ("127.0.0.1", "localhost") and request.remote_addr in ("127.0.0.1", "::1")


def code_allowed():
    flag = os.getenv("ALLOW_CODE_RUN")
    return flag == "1" or (flag != "0" and local_only())


# ------------------------------------------------------------------ routes
@app.route("/")
def index():
    init_db()
    return render_template("index.html", agents=AGENTS)


def read_message():
    return str((request.get_json(silent=True) or {}).get("message", "")).strip()


@app.route("/api/chat", methods=["POST"])
def chat():
    init_db()
    message = read_message()
    if not message:
        return jsonify({"error": "कृपया पहले कुछ बोलो या लिखो।"}), 400
    job = new_job()
    process_chat(message, job)
    return jsonify(public_job(job))


@app.route("/api/chat/start", methods=["POST"])
def chat_start():
    init_db()
    message = read_message()
    if not message:
        return jsonify({"error": "कृपया पहले कुछ बोलो या लिखो।"}), 400
    job = new_job()
    job["message"] = message
    job["agents"] = choose_agents(message)
    job["steps"] = mk_steps(job["agents"])
    threading.Thread(target=process_chat, args=(message, job), daemon=True).start()
    return jsonify({"id": job["id"]})


@app.route("/api/selfdev/run", methods=["POST"])
def selfdev_run():
    init_db()
    job = new_job()
    threading.Thread(target=process_selfdev, args=(job,), daemon=True).start()
    return jsonify({"id": job["id"]})


@app.route("/api/job/latest")
def job_latest():
    js = [j for j in JOBS.values() if j.get("message")]
    return jsonify(public_job(max(js, key=lambda j: j["t"]))) if js else jsonify({"none": True})


@app.route("/api/actions")
def actions_api():
    return jsonify([{k: v[k] for k in ("id", "tool", "summary")} for v in live_actions()])


@app.route("/api/actions/<aid>/<decision>", methods=["POST"])
def action_decide(aid, decision):
    if decision not in ("confirm", "cancel"):
        return jsonify({"error": "bad decision"}), 400
    text, tools = run_pending(aid, decision == "confirm")
    return jsonify({"answer": text, "tools": tools})


@app.route("/api/job/<jid>")
def job_status(jid):
    j = JOBS.get(jid)
    return jsonify(public_job(j)) if j else (jsonify({"error": "job नहीं मिला"}), 404)


@app.route("/api/history", methods=["GET", "DELETE"])
def history():
    init_db()
    if request.method == "DELETE":
        with db() as c:
            c.execute("DELETE FROM history")
        return jsonify({"ok": True})
    return jsonify(recent_history(30))


@app.route("/api/metrics")
def metrics():
    du = shutil.disk_usage(APP_DIR)
    online, ms = net_check()
    return jsonify({"cpu": cpu_pct(), "ram": ram_pct(), "storage": round(du.used / du.total * 100), "online": online, "net_ms": ms})


@app.route("/api/status")
def status():
    init_db()
    with db() as c:
        n = lambda q: c.execute(q).fetchone()[0]
        kinds = {r["kind"]: r["n"] for r in c.execute("SELECT kind, COUNT(*) n FROM memories GROUP BY kind")}
        counts = {"memories": sum(kinds.values()), "kinds": kinds, "tasks": n("SELECT COUNT(*) FROM tasks WHERE done=0"),
                  "pending": n("SELECT COUNT(*) FROM proposals WHERE status='pending'"), "messages": n("SELECT COUNT(*) FROM history")}
    cfg = llm_config()
    return jsonify({"mode": "AI API" if ai_on() else "Demo mode", "model": cfg["model"] if ai_on() else "—", "search": search_provider(),
                    "code_run": code_allowed(), "tools": len(TOOLS), **counts})


@app.route("/api/settings", methods=["GET", "POST"])
def settings_api():
    if request.method == "POST":
        if not local_only() and os.getenv("ALLOW_REMOTE_SETTINGS") != "1":
            return jsonify({"error": "Settings सिर्फ़ इसी फ़ोन से बदली जा सकती हैं।"}), 403
        put_settings(request.get_json(silent=True) or {})
    s, cfg = get_settings(), llm_config()
    return jsonify({"api_key_set": bool(cfg["key"]), "api_key_hint": hint(cfg["key"]), "model": cfg["model"], "base_url": cfg["base"],
                    "tavily_set": bool(tavily_key()), "voice_reply": s.get("voice_reply", True), "multi_agent": s.get("multi_agent", True), "ask_before_send": s.get("ask_before_send", True)})


@app.route("/api/settings/test", methods=["POST"])
def settings_test():
    b = request.get_json(silent=True) or {}
    cfg = llm_config({k: b[k] for k in ("api_key", "model", "base_url") if b.get(k)})
    if not cfg["key"]:
        return jsonify({"ok": False, "message": "पहले API key डालो।"})
    try:
        r = requests.post(f"{cfg['base']}/chat/completions", timeout=30, headers={"Authorization": f"Bearer {cfg['key']}"},
                          json={"model": cfg["model"], "messages": [{"role": "user", "content": "Say OK"}], "max_tokens": 5})
        r.raise_for_status()
        return jsonify({"ok": True, "message": "कनेक्शन सही है ✅ (" + cfg["model"] + ")"})
    except Exception as e:
        return jsonify({"ok": False, "message": api_error_text(e)})


@app.route("/api/memory", methods=["GET", "POST"])
def memory_api():
    init_db()
    if request.method == "POST":
        b = request.get_json(silent=True) or {}
        mid = save_memory(b.get("text") or b.get("note"), b.get("kind", "note"))
        return jsonify({"ok": True, "id": mid}) if mid else (jsonify({"error": "खाली है"}), 400)
    with db() as c:
        return jsonify([dict(r) for r in c.execute("SELECT * FROM memories ORDER BY id DESC LIMIT 200")])


@app.route("/api/memory/<int:mid>", methods=["DELETE"])
def memory_delete(mid):
    init_db()
    with db() as c:
        c.execute("DELETE FROM memories WHERE id=?", (mid,))
    return jsonify({"ok": True})


@app.route("/api/tasks", methods=["GET", "POST"])
def tasks_api():
    init_db()
    with db() as c:
        if request.method == "POST":
            t = str((request.get_json(silent=True) or {}).get("title", "")).strip()[:200]
            if not t:
                return jsonify({"error": "खाली है"}), 400
            c.execute("INSERT INTO tasks(ts,title) VALUES(?,?)", (now(), t))
        return jsonify([dict(r) for r in c.execute("SELECT * FROM tasks ORDER BY done, id DESC LIMIT 100")])


@app.route("/api/tasks/<int:tid>/toggle", methods=["POST"])
def task_toggle(tid):
    init_db()
    with db() as c:
        c.execute("UPDATE tasks SET done=1-done WHERE id=?", (tid,))
    return jsonify({"ok": True})


@app.route("/api/skills", methods=["GET", "POST"])
def skills_api():
    init_db()
    with db() as c:
        if request.method == "POST":
            b = request.get_json(silent=True) or {}
            name, prompt = str(b.get("name", "")).strip()[:60], str(b.get("prompt", "")).strip()[:1000]
            if not name or not prompt:
                return jsonify({"error": "नाम और निर्देश दोनों चाहिए"}), 400
            c.execute("INSERT INTO skills(name,prompt) VALUES(?,?)", (name, prompt))
        return jsonify([dict(r) for r in c.execute("SELECT * FROM skills ORDER BY id")])


@app.route("/api/skills/<int:sid>", methods=["DELETE"])
def skill_delete(sid):
    init_db()
    with db() as c:
        c.execute("DELETE FROM skills WHERE id=?", (sid,))
    return jsonify({"ok": True})


@app.route("/api/tools")
def tools_api():
    out = []
    for t in TOOLS:
        n = t["function"]["name"]
        out.append({"name": n, "label": TOOL_LABELS.get(n, ""), "desc": t["function"]["description"],
                    "agents": [a["name"] for a in AGENTS if n in a["tools"]] or ["सभी एजेंट"]})
    return jsonify(out)


@app.route("/api/backups", methods=["GET", "POST"])
def backups_api():
    if request.method == "POST":
        label = str((request.get_json(silent=True) or {}).get("label", "")).strip()[:120] or "हाथ से लिया बैकअप"
        return jsonify({"ok": True, "id": make_backup(label)})
    return jsonify(list_backups()[:30])


@app.route("/api/backups/<bid>/restore", methods=["POST"])
def backup_restore(bid):
    try:
        return jsonify(restore_backup(bid))
    except ValueError as e:
        return jsonify({"error": str(e)}), 404


@app.route("/api/proposals")
def proposals_api():
    init_db()
    with db() as c:
        return jsonify([dict(r) for r in c.execute("SELECT * FROM proposals ORDER BY id DESC LIMIT 50")])


@app.route("/api/proposals/<int:pid>/<decision>", methods=["POST"])
def proposal_decide(pid, decision):
    if decision not in ("approve", "reject"):
        return jsonify({"error": "bad decision"}), 400
    init_db()
    with db() as c:
        c.execute("UPDATE proposals SET status=? WHERE id=?", ("approved" if decision == "approve" else "rejected", pid))
    return jsonify({"ok": True, "note": "मंज़ूरी सिर्फ़ दर्ज होती है; बदलाव तुम खुद (या किसी डेवलपर की मदद से) कोड में करते हो।"})


@app.route("/api/files", methods=["GET", "POST"])
def files_api():
    try:
        if request.method == "POST":
            b = request.get_json(silent=True) or {}
            return jsonify({"ok": True, "name": write_file(b.get("name"), b.get("content", ""))})
        return jsonify(list_files())
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/files/<path:name>")
def file_read(name):
    try:
        return jsonify({"name": name, "content": read_file(name)})
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


def run_inproc(code):
    import contextlib, io, traceback
    out, err, res = io.StringIO(), io.StringIO(), {"code": 0}

    def target():
        try:
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                exec(compile(code, "<studio>", "exec"), {"__name__": "__main__"})
        except BaseException:
            err.write(traceback.format_exc())
            res["code"] = 1
    t = threading.Thread(target=target, daemon=True)
    t.start()
    t.join(10)
    if t.is_alive():
        return {"stdout": out.getvalue()[-4000:], "stderr": "10 सेकंड में खत्म नहीं हुआ।", "code": -1}
    return {"stdout": out.getvalue()[-4000:], "stderr": err.getvalue()[-4000:], "code": res["code"]}


@app.route("/api/run", methods=["POST"])
def run_code():
    if not code_allowed():
        return jsonify({"error": "कोड चलाना यहाँ बंद है (सुरक्षा के लिए सिर्फ़ इसी फ़ोन पर चलता है)।"}), 403
    code = str((request.get_json(silent=True) or {}).get("code", ""))
    if not code.strip() or len(code) > 20000:
        return jsonify({"error": "कोड खाली है या बहुत बड़ा है"}), 400
    if os.getenv("AKASH_ANDROID") == "1":
        return jsonify(run_inproc(code))
    p = workspace() / "_run.py"
    p.write_text(code, encoding="utf-8")
    try:
        r = subprocess.run([sys.executable, str(p)], cwd=workspace(), capture_output=True, text=True, timeout=10)
        return jsonify({"stdout": r.stdout[-4000:], "stderr": r.stderr[-4000:], "code": r.returncode})
    except subprocess.TimeoutExpired:
        return jsonify({"stdout": "", "stderr": "10 सेकंड में खत्म नहीं हुआ, रोक दिया।", "code": -1})
    except OSError as e:
        return jsonify({"stdout": "", "stderr": f"इस डिवाइस पर कोड नहीं चल पाया: {e}", "code": -1})


@app.route("/api/shutdown", methods=["POST"])
def shutdown():
    if not local_only():
        return jsonify({"error": "सिर्फ़ इसी फ़ोन से"}), 403
    threading.Timer(0.6, lambda: os._exit(0)).start()
    return jsonify({"ok": True})


@app.route("/health")
def health():
    return jsonify({"ok": True, "app": "AKASH AI v3"})


if __name__ == "__main__":
    init_db()
    app.run(host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "5000")), debug=False, threaded=True)
