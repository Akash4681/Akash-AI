"""Starts the AKASH Flask server inside the Android app (called from Kotlin ServerHost).

app.py lives in <data>/code so AKASH can edit it (with backups). If an edit ever breaks
app.py so badly that it cannot even be imported, the newest backup (or the original)
is put back automatically before the server starts.
"""
import json
import os
import shutil
import sys
import time


def _read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def _prepare_code(web_dir, data_dir, code):
    os.makedirs(code, exist_ok=True)
    src = os.path.join(web_dir, "code", "app.py")
    dst = os.path.join(code, "app.py")
    stamp = os.path.join(code, ".version")
    ver = _read(os.path.join(os.path.dirname(web_dir), "web.version")) or ""
    if not os.path.exists(dst) or _read(stamp) != ver:
        if os.path.exists(dst):  # new APK: keep the old (self-edited) code as a backup
            bid = time.strftime("%Y%m%d-%H%M%S") + "-apk"
            d = os.path.join(data_dir, "backups", bid)
            os.makedirs(d, exist_ok=True)
            shutil.copy2(dst, os.path.join(d, "app.py"))
            with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as f:
                json.dump({"id": bid, "ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "label": "ऐप अपडेट से पहले का कोड", "files": ["app.py"]}, f, ensure_ascii=False)
        shutil.copy2(src, dst)
        with open(stamp, "w", encoding="utf-8") as f:
            f.write(ver)


def _newest_backup_with_app(data_dir):
    root = os.path.join(data_dir, "backups")
    for bid in sorted(os.listdir(root) if os.path.isdir(root) else [], reverse=True):
        p = os.path.join(root, bid, "app.py")
        if os.path.isfile(p):
            return p
    return None


def run(web_dir, data_dir, port):
    code = os.path.join(data_dir, "code")
    os.environ.update(AKASH_WEB=web_dir, AKASH_DATA=data_dir, AKASH_CODE=code, AKASH_ANDROID="1", HOST="127.0.0.1")
    _prepare_code(web_dir, data_dir, code)
    sys.path.insert(0, code)
    dst = os.path.join(code, "app.py")
    app = None
    for attempt in ("current", "backup", "original"):
        try:
            import app  # noqa: F811
            break
        except Exception as e:
            print("AKASH: app.py would not start (%s: %s); trying %s" % (type(e).__name__, e, attempt), flush=True)
            sys.modules.pop("app", None)
            fix = _newest_backup_with_app(data_dir) if attempt == "current" else os.path.join(web_dir, "code", "app.py")
            shutil.copy2(fix or os.path.join(web_dir, "code", "app.py"), dst)
    import app
    app.init_db()
    app.start_background()
    app.app.run(host="127.0.0.1", port=int(port), debug=False, threaded=True, use_reloader=False)
